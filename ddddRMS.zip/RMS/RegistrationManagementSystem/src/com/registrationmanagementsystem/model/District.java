package com.registrationmanagementsystem.model;

public class District {
	String district_name;
	String district_value;

	public void setDistrictName(String district_name) {
		this.district_name = district_name;
	}

	public String getDistrictName() {
		return district_name;
	}

	public void setDistrictValue(String district_value) {
		this.district_value = district_value;
	}

	public String getDistrictValue() {
		return district_value;
	}
}