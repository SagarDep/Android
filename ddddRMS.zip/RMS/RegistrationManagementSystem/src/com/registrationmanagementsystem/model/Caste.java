package com.registrationmanagementsystem.model;

public class Caste {
	String caste_name;
	String caste_value;

	public void setCasteName(String caste_name) {
		this.caste_name = caste_name;
	}

	public String getCasterName() {
		return caste_name;
	}

	public void setCasteValue(String caste_value) {
		this.caste_value = caste_value;
	}

	public String getCasteValue() {
		return caste_value;
	}
}