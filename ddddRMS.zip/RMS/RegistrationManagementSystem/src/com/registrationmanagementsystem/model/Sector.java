package com.registrationmanagementsystem.model;

public class Sector {
	String sector_name;
	String sector_values;
	
	public String getSector_name() {
		return sector_name;
	}
	public void setSector_name(String sector_name) {
		this.sector_name = sector_name;
	}
	public String getSector_values() {
		return sector_values;
	}
	public void setSector_values(String sector_values) {
		this.sector_values = sector_values;
	}
	

}
