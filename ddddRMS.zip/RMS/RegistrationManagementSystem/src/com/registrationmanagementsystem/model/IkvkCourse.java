package com.registrationmanagementsystem.model;

public class IkvkCourse {
	String COURSE_CODE;
	String COURSE_NAME;
	
	public String getCOURSE_CODE() {
		return COURSE_CODE;
	}
	public void setCOURSE_CODE(String cOURSE_CODE) {
		COURSE_CODE = cOURSE_CODE;
	}
	public String getCOURSE_NAME() {
		return COURSE_NAME;
	}
	public void setCOURSE_NAME(String cOURSE_NAME) {
		COURSE_NAME = cOURSE_NAME;
	}
	
}
