package com.registrationmanagementsystem.adapter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.registrationmanagementsystem.CandidateUpdateActivity;
import com.registrationmanagementsystem.GPSLocationActivity;
import com.registrationmanagementsystem.GPSTracker;
import com.registrationmanagementsystem.R;
import com.registrationmanagementsystem.UpdateDetailActivity;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.lazyloading.ImageLoader;
import com.registrationmanagementsystem.model.UserDetails;

public class UserAdapter extends BaseAdapter {
	// private static ArrayList<ItemDetailScreen> userArrayList;
	private ArrayList<UserDetails> userArrayList = new ArrayList<UserDetails>();
	private LayoutInflater mInflater;
	private Context m_context;
	private Context mActivity;
	GPSTracker gps;
	public ImageLoader imageLoader; 


	public UserAdapter(Context context, ArrayList<UserDetails> results) {
		m_context = context.getApplicationContext();
		mActivity = (Activity) context;
		userArrayList = results;
		mInflater = LayoutInflater.from(context);
		gps = new GPSTracker(context);
		imageLoader=new ImageLoader(context.getApplicationContext());

	}

	// add new
	public UserAdapter(Context context) {
		m_context = context.getApplicationContext();
		mInflater = LayoutInflater.from(context);
		gps = new GPSTracker(context);
	}

	public int getCount() {
		return userArrayList.size();
	}

	public Object getItem(int position) {
		return userArrayList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	// add new
	/*
	 * public void appendData(ItemDetailScreen itemDetailScreen) {
	 * this.userArrayList.add(itemDetailScreen); }
	 */

	public View getView(final int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.user_item, null);
			holder = new ViewHolder();
			holder.txtFirstName = (TextView) convertView
					.findViewById(R.id.fname);
			holder.txtCandidateCategory = (TextView) convertView
					.findViewById(R.id.txtCategoryName);
			
			/*holder.txtLastName = (TextView) convertView
					.findViewById(R.id.lname);
			holder.txtMiddleName= (TextView) convertView
					.findViewById(R.id.Mname);*/
			
			holder.imgUserPic = (ImageView) convertView
					.findViewById(R.id.imgUser);
			
			
			holder.btnMap = (Button) convertView.findViewById(R.id.btnMap);
			holder.btnDetail = (Button) convertView.findViewById(R.id.btnDetail);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.txtFirstName.setText(userArrayList.get(position).getFirst_name() +" "+userArrayList.get(position).getMiddle_name() +" "+userArrayList.get(position).getLast_name());
		String category = String.valueOf(userArrayList.get(position).getCandidate_category());
		
		if(category.equalsIgnoreCase("49") )
		{
			holder.txtCandidateCategory.setText("iKVK");	
		}
		else if(category.equalsIgnoreCase("50") )
		{
			holder.txtCandidateCategory.setText("Skill Certification");	
		}
		else if(category.equalsIgnoreCase("51") )
		{
			holder.txtCandidateCategory.setText("Apprentice");	
		}
		
		/*holder.txtMiddleName.setText(userArrayList.get(position).getMiddle_name());
		holder.txtLastName.setText(userArrayList.get(position).getLast_name());
		*/
		String mfile = userArrayList.get(position).getImage_path();
		if (mfile != null) {
			if (mfile.equalsIgnoreCase("")) {
			} else {
				File mFileTemp = new java.io.File(mfile).getAbsoluteFile();
				Bitmap bitmap = decodeFile(mFileTemp, 200, 200);
				holder.imgUserPic.setImageBitmap(bitmap);
//				System.out.println("mFileTemp.getPath()"+mFileTemp.getPath());
				
//				imageLoader.DisplayImage(mFileTemp.getPath(),holder.imgUserPic);
				
//				bitmap.recycle();
			}
		}
		
		
		

		holder.btnMap.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				
				
				if(gps.canGetLocation())
				{	
					Bundle bundle = new Bundle();
					bundle.putString(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID,userArrayList.get(position).getId().toString());
					bundle.putString("pos",String.valueOf(position));         
					
					System.out.println("IDAdapter"+userArrayList.get(position).getId().toString());
					Intent intent = new Intent(m_context, GPSLocationActivity.class);
					/*intent.putExtra(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID, userArrayList.get(position).getId().toString());*/
					intent.putExtras(bundle);
					mActivity.startActivity(intent);
				}
				else
				{
					gps.showSettingsAlert();
				}
			}
		});
		
		
		holder.btnDetail.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

					
//				Intent intent = new Intent(m_context,UpdateDetailActivity.class);
				Intent intent = new Intent(m_context,CandidateUpdateActivity.class);
				intent.putExtra(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID, userArrayList.get(position).getId().toString());
				intent.putExtra(DataBaseHelper.KEY_APPLICANT_CATEGORY_ID, userArrayList.get(position).getCandidate_category());
				mActivity.startActivity(intent);
				
			}
		});

		return convertView;
	}

	
	//** OOM DECODING 
	
	public static Bitmap decodeFile(File f,int WIDTH,int HIGHT){
		 try {
		     //Decode image size
		     BitmapFactory.Options o = new BitmapFactory.Options();
		     o.inJustDecodeBounds = true;
		     BitmapFactory.decodeStream(new FileInputStream(f),null,o);

		     //The new size we want to scale to
		     final int REQUIRED_WIDTH=WIDTH;
		     final int REQUIRED_HIGHT=HIGHT;
		     //Find the correct scale value. It should be the power of 2.
		     int scale=1;
		     while(o.outWidth/scale/2>=REQUIRED_WIDTH && o.outHeight/scale/2>=REQUIRED_HIGHT)
		         scale*=2;

		     //Decode with inSampleSize
		     BitmapFactory.Options o2 = new BitmapFactory.Options();
		     o2.inSampleSize=scale;
		     return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
		 } catch (FileNotFoundException e) {}
		 return null;
		}
	class ViewHolder {
		public TextView txtFirstName,txtMiddleName, txtLastName,txtCandidateCategory;
		public Button btnDetail;
		public ImageView imgUserPic;
		public Button btnMap;
	}
}