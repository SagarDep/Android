package com.registrationmanagementsystem.model;

public class CandidateCategory {
	String category_name;
	String category_value;

	public void setCategoryName(String category_name) {
		this.category_name = category_name;
	}

	public String getClassdetailcategoryName() {
		return category_name;
	}

	public void setCategoryValue(String category_value) {
		this.category_value = category_value;
	}

	public String getCategoryValue() {
		return category_value;
	}
}