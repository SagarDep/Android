package com.registrationmanagementsystem;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.location.Location;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.APDesTrade;
import com.registrationmanagementsystem.model.APInstitute;
import com.registrationmanagementsystem.model.CandidateCategory;
import com.registrationmanagementsystem.model.Caste;
import com.registrationmanagementsystem.model.Designation;
import com.registrationmanagementsystem.model.District;
import com.registrationmanagementsystem.model.Genders;
import com.registrationmanagementsystem.model.IkvkBatch;
import com.registrationmanagementsystem.model.IkvkCenter;
import com.registrationmanagementsystem.model.IkvkCourse;
import com.registrationmanagementsystem.model.IkvkShift;
import com.registrationmanagementsystem.model.Moduleskill;
import com.registrationmanagementsystem.model.Region;
import com.registrationmanagementsystem.model.ReleventSector;
import com.registrationmanagementsystem.model.States;
import com.registrationmanagementsystem.model.Taluka;

public class RegistrationDetailFragment   extends Fragment {


	public static String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
	public static final int REQUEST_CODE_GALLERY = 0x1;
	public static final int REQUEST_CODE_TAKE_PICTURE = 0x2;
	public static final int REQUEST_CODE_CROP_IMAGE = 0x3;
	public static final int CROP_PIC = 0x4;
	private static final String TAG = RegistrationDetailFragment.class.getName();
	private File mFileTemp;
	private ArrayList<String> m_CandidateCategoryDisplay = new ArrayList<String>();
	private ArrayList<CandidateCategory> m_CandidateCategory = new ArrayList<CandidateCategory>();
	private ArrayList<String> m_StateDisplay = new ArrayList<String>();
	private ArrayList<States> m_State = new ArrayList<States>();
	private ArrayList<String> m_DistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_District = new ArrayList<District>();
	private ArrayList<String> m_TalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_Taluka = new ArrayList<Taluka>();
	private ArrayList<String> m_GenderDisplay = new ArrayList<String>();
	private ArrayList<Genders> m_Gender = new ArrayList<Genders>();
	private ArrayList<String> m_CasteDisplay = new ArrayList<String>();
	private ArrayList<Caste> m_Caste = new ArrayList<Caste>();
	private ArrayList<String> m_DesignationDisplay = new ArrayList<String>();
	private ArrayList<Designation> m_Designation = new ArrayList<Designation>();
	
	private ArrayList<String> m_BatchesDisplay = new ArrayList<String>();
	private ArrayList<IkvkBatch> m_Batches = new ArrayList<IkvkBatch>();
	
	

	private boolean doSavePicUri = false;

	RelativeLayout rlvIkvk, rlvSkill, rlvApprentice;
	ImageView imgUserPic;
	GPSTracker gps;
	EditText etxFirstName, etxMiddleName, etxLastName, etxFmhName, etxAddress,etxCity, etxPincode, etxMobile, etxLline, etxPhysical, etxEmail,etxBday;
	CheckBox chkPhysical, chkExArmy, chkWidow, chkDivorcee, chkMinority,chkBpl;
	Button btnSubmit;
	Spinner spCandidateCategory, spCaste, spGender, spState, spDistrict, spTaluka, spDesignation;
	DataBaseHelper mDbHelper;
	Context context;
	CompressImage compressImage;
	Location location;
	//	double ImcLat;
	//	double ImcLon;
	ActionBar actionBar;

	TextView tvDesignatedTradecolorasterisk,tvDesignatedTrade;
	String designationValue;

	private Uri picUri;
	Uri mImageCaptureUri = null;
	int spinnerSetGuj;

	View m_rootView;

	String datePicker = "";

	/***
	 * New Parameters IKVK Category
	 */
	Switch ch_ikvk_ApplicantType; 
	Spinner spikvk_Course,spiKVKCenter,spPreferredShift,spBatch;
	EditText txtTraining_StartDate,txtTraining_EndDate;

	private ArrayList<String> m_IkvkCourseDisplay = new ArrayList<String>();
	private ArrayList<IkvkCourse> m_IkvkCourse = new ArrayList<IkvkCourse>();
	private ArrayList<String> m_IkvkCentreDisplay = new ArrayList<String>();
	private ArrayList<IkvkCenter> m_IkvkCentre = new ArrayList<IkvkCenter>();
	private ArrayList<String> m_IkvkShiftDisplay = new ArrayList<String>();
	private ArrayList<IkvkShift> m_IKvkShift = new ArrayList<IkvkShift>();

	/***
	 * New Parameters Industry Category
	 */
	EditText txtind_Name,txtadname,txtcontact,txtSCEmail,txtPhone;
	Spinner spSCRegion,spSCDistrict,spSCTaluka,spSCRelevantSector,spSCModuleSkill;

	private ArrayList<String> m_SCRegionDisplay = new ArrayList<String>();
	private ArrayList<Region> m_SCRegion = new ArrayList<Region>();
	private ArrayList<String> m_SCDistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_SCDistricts = new ArrayList<District>();	
	private ArrayList<String> m_SCTalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_SCTaluka = new ArrayList<Taluka>();
	private ArrayList<String> m_SCRelevantSectorDisplay = new ArrayList<String>();
	private ArrayList<ReleventSector> m_SCRelevantSector = new ArrayList<ReleventSector>();	
	private ArrayList<String> m_SCModuleSkillDisplay = new ArrayList<String>();
	private ArrayList<Moduleskill> m_SCModuleskill= new ArrayList<Moduleskill>();

	/***
	 * New Parameters Apprentice
	 */


	Switch ch_app_ApplicantType;
	EditText txtappSeatNumber,txtJoiningDate,txtCompletionDate,txtRegistrationNumber,txtDateofRegistration;
	Spinner spAPDesignatedTrade, spAPInstitute;

	private ArrayList<String> m_APDesignatedTradeDisplay = new ArrayList<String>();
	private ArrayList<APDesTrade> m_APDesignatedTrade = new ArrayList<APDesTrade>();
	private ArrayList<String> m_APInstituteDisplay = new ArrayList<String>();
	private ArrayList<APInstitute> m_APInstitute = new ArrayList<APInstitute>();

	private int positionCandidateCategory = 0;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		m_rootView = inflater.inflate(R.layout.activity_registration,
				container, false);

		doSavePicUri = false;

		context = getActivity();
		gps = new GPSTracker(getActivity());
		mDbHelper = DataBaseHelper.getInstance(getActivity());
		etxFirstName = (EditText)m_rootView. findViewById(R.id.txtFname);
		etxMiddleName = (EditText)m_rootView.findViewById(R.id.txtMname);
		etxLastName = (EditText)m_rootView.findViewById(R.id.txtLname);
		etxFmhName = (EditText) m_rootView.findViewById(R.id.txtfhname);
		etxAddress = (EditText) m_rootView.findViewById(R.id.txtadname);

		spDesignation = (Spinner) m_rootView. findViewById(R.id.spDesignation);


		/**
		 * New Initialization
		 */
		/*
		 * IKVK
		 */
		ch_ikvk_ApplicantType  = (Switch)m_rootView. findViewById(R.id.ch_ikvk_ApplicantType);
		spikvk_Course= (Spinner)m_rootView. findViewById(R.id.spikvk_Course);
		spiKVKCenter = (Spinner)m_rootView. findViewById(R.id.spiKVKCenter);
		spPreferredShift = (Spinner)m_rootView. findViewById(R.id.spPreferredShift);
		spBatch = (Spinner)m_rootView. findViewById(R.id.spBatch);
		txtTraining_StartDate= (EditText)m_rootView. findViewById(R.id.txtTraining_StartDate);
		txtTraining_EndDate= (EditText)m_rootView. findViewById(R.id.txtTraining_EndDate);

		/*
		 * Skill Certification
		 */
		txtind_Name= (EditText)m_rootView. findViewById(R.id.txtind_Name);
		txtadname= (EditText)m_rootView. findViewById(R.id.txtadname_sc);
		txtcontact= (EditText)m_rootView. findViewById(R.id.txtcontact);
		txtSCEmail= (EditText)m_rootView. findViewById(R.id.txtSCEmail);
		txtPhone = (EditText)m_rootView. findViewById(R.id.txtPhone);
		spSCRegion = (Spinner)m_rootView. findViewById(R.id.sprname);
		spSCDistrict = (Spinner)m_rootView. findViewById(R.id.spsdname);
		spSCTaluka = (Spinner)m_rootView. findViewById(R.id.spSCtalukaname);
		spSCRelevantSector = (Spinner)m_rootView. findViewById(R.id.spRelevantSector);
		spSCModuleSkill = (Spinner)m_rootView. findViewById(R.id.spModuleSkill);

		/*
		 * Apprentice
		 */
		ch_app_ApplicantType = (Switch)m_rootView. findViewById(R.id.ch_app_ApplicantType);
		txtappSeatNumber= (EditText)m_rootView. findViewById(R.id.txtappSeatNumber);
		txtJoiningDate= (EditText)m_rootView. findViewById(R.id.txtJoiningDate);
		txtCompletionDate= (EditText)m_rootView. findViewById(R.id.txtCompletionDate);
		txtRegistrationNumber= (EditText)m_rootView. findViewById(R.id.txtRegistrationNumber);
		txtDateofRegistration= (EditText)m_rootView. findViewById(R.id.txtDateofRegistration);
		spAPInstitute= (Spinner)m_rootView. findViewById(R.id.spapp_Institute);
		spAPDesignatedTrade  = (Spinner)m_rootView. findViewById(R.id.spDesignatedTrade);
		tvDesignatedTradecolorasterisk  = (TextView)m_rootView. findViewById(R.id.tvDesignatedTradecolorasterisk);
		tvDesignatedTrade  = (TextView)m_rootView. findViewById(R.id.tvDesignatedTrade);


		etxAddress.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (v.getId() == R.id.txtadname) {
					v.getParent().requestDisallowInterceptTouchEvent(true);
					switch (event.getAction() & MotionEvent.ACTION_MASK) {
					case MotionEvent.ACTION_UP:
						v.getParent().requestDisallowInterceptTouchEvent(false);
						break;
					}
				}
				return false;
			}
		});

		etxCity = (EditText) m_rootView.findViewById(R.id.txtcityname);
		etxPincode = (EditText) m_rootView.findViewById(R.id.txtpincodename);
		etxMobile = (EditText) m_rootView.findViewById(R.id.txtMobname);
		etxLline = (EditText)m_rootView. findViewById(R.id.txtlandlinename);
		etxPhysical = (EditText)m_rootView. findViewById(R.id.txtPhysicalname);
		etxEmail = (EditText)m_rootView. findViewById(R.id.txtEmail);
		etxBday = (EditText)m_rootView.findViewById(R.id.txtBirthdate);

		chkPhysical = (CheckBox) m_rootView.findViewById(R.id.chPhysicalname);
		chkExArmy = (CheckBox) m_rootView.findViewById(R.id.chExarmy);
		chkWidow = (CheckBox)m_rootView. findViewById(R.id.chWidow);
		chkDivorcee = (CheckBox) m_rootView.findViewById(R.id.chDivorcee);
		chkMinority = (CheckBox) m_rootView.findViewById(R.id.chMinority);
		chkBpl = (CheckBox)m_rootView. findViewById(R.id.chBpl);

		spCandidateCategory = (Spinner)m_rootView. findViewById(R.id.spCandidateCategory);
		spDistrict = (Spinner)m_rootView. findViewById(R.id.spdname);
		spState = (Spinner) m_rootView.findViewById(R.id.spsname);
		spGender = (Spinner)m_rootView. findViewById(R.id.spGendername);
		spCaste = (Spinner) m_rootView.findViewById(R.id.spCastename);
		spTaluka = (Spinner) m_rootView.findViewById(R.id.sptalukaname);

		rlvIkvk = (RelativeLayout) m_rootView.findViewById(R.id.ikvk);
		rlvSkill = (RelativeLayout) m_rootView.findViewById(R.id.skillcertification);
		rlvApprentice = (RelativeLayout) m_rootView.findViewById(R.id.apprentice);

		new CandidateCategoryAsyncTask().execute();
		new GenderAsyncTask().execute();
		new CasteAsyncTask().execute();
		new StateAsyncTask().execute();
		new DesignationAsyncTask().execute();

		imgUserPic = (ImageView)m_rootView. findViewById(R.id.list_image);
		imgUserPic.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				/*				if(gps.canGetLocation())
				{
					Log.e(TAG, "testgps: imgUserPic if gps.canGetLocation()" + gps.canGetLocation());
					selectImage();
				}
				else
				{
					Log.e(TAG, "testgps: imgUserPic else gps.canGetLocation()" + gps.canGetLocation());
					gps.showSettingsAlert();
				}*/
				selectImage();
			}
		});

		btnSubmit = (Button)m_rootView. findViewById(R.id.btnSubmit);
		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//				insertUserData();
				newInsertUserData();
			}
		});



		spCandidateCategory.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Log.i("check", "position == " + position);
				positionCandidateCategory = position;
				if(position==1) {
					rlvIkvk.setVisibility(View.VISIBLE);
					rlvSkill.setVisibility(View.GONE);
					rlvApprentice.setVisibility(View.GONE);

					tvDesignatedTradecolorasterisk.setVisibility(View.GONE);
					tvDesignatedTrade.setVisibility(View.GONE);
					spAPDesignatedTrade.setVisibility(View.GONE);

					viewInitIkvk();
				} else if(position == 2) {
					rlvIkvk.setVisibility(View.GONE);
					rlvSkill.setVisibility(View.VISIBLE);
					rlvApprentice.setVisibility(View.GONE);			

					tvDesignatedTradecolorasterisk.setVisibility(View.GONE);
					tvDesignatedTrade.setVisibility(View.GONE);
					spAPDesignatedTrade.setVisibility(View.GONE);
					viewInitSC();
				} else if (position == 3) {
					rlvIkvk.setVisibility(View.GONE);
					rlvSkill.setVisibility(View.GONE);
					rlvApprentice.setVisibility(View.VISIBLE);

					tvDesignatedTradecolorasterisk.setVisibility(View.VISIBLE);
					tvDesignatedTrade.setVisibility(View.VISIBLE);
					spAPDesignatedTrade.setVisibility(View.VISIBLE);
					viewInitAP();
				} else {
					rlvIkvk.setVisibility(View.GONE);
					rlvSkill.setVisibility(View.GONE);
					rlvApprentice.setVisibility(View.GONE);

					tvDesignatedTradecolorasterisk.setVisibility(View.GONE);
					tvDesignatedTrade.setVisibility(View.GONE);
					spAPDesignatedTrade.setVisibility(View.GONE);
				}
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});


		spState.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spDistrict onItemSelected");
				setTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		etxBday.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "etxBday";
				datePicker();
			}
		});

		txtTraining_StartDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtTraining_StartDate";
				datePicker_other();
			}
		});

		txtTraining_EndDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtTraining_EndDate";
				datePicker_other();
			}
		});

		txtJoiningDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtJoiningDate";
				datePicker_other();
			}
		});

		txtCompletionDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtCompletionDate";
				datePicker_other();
			}
		});

		txtDateofRegistration.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtDateofRegistration";
				datePicker_other();
			}
		});



		//		 skill certification
		spSCRegion.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setSCDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spSCDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setSCTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spSCRelevantSector.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setSCModuleSkill();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		return m_rootView;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			getActivity().finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public void datePicker() {
		DialogFragment newFragment = new SelectDateFragment();
		newFragment.show(getFragmentManager().beginTransaction(), "DatePicker");
	}

	public class SelectDateFragment extends DialogFragment implements
	DatePickerDialog.OnDateSetListener {
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			Calendar calendar = Calendar.getInstance();
			int yy = calendar.get(Calendar.YEAR);
			int mm = calendar.get(Calendar.MONTH);
			int dd = calendar.get(Calendar.DAY_OF_MONTH);
			DatePickerDialog d = new DatePickerDialog(getActivity(), this, yy,
					mm, dd);
			calendar.set(yy, mm, dd - 1);
			d.getDatePicker().setMaxDate(calendar.getTimeInMillis());
			return d;
		}

		public void onDateSet(DatePicker view, int yy, int mm, int dd) {
			populateSetDate(yy, mm + 1, dd);
		}
	}
	
	
	/**
	 * dATE PICKER OTHER
	 */
	
	public void datePicker_other() {
		DialogFragment newFragment = new SelectDateFragmentOther();
		newFragment.show(getFragmentManager().beginTransaction(), "DatePicker");
	}

	public class SelectDateFragmentOther extends DialogFragment implements
	DatePickerDialog.OnDateSetListener {
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			Calendar calendar = Calendar.getInstance();
			int yy = calendar.get(Calendar.YEAR);
			int mm = calendar.get(Calendar.MONTH);
			int dd = calendar.get(Calendar.DAY_OF_MONTH);
			DatePickerDialog d = new DatePickerDialog(getActivity(), this, yy,
					mm, dd);
			calendar.set(yy, mm, dd - 1);
//			d.getDatePicker().setMaxDate(calendar.getTimeInMillis());
			return d;
		}

		public void onDateSet(DatePicker view, int yy, int mm, int dd) {
			populateSetDate(yy, mm + 1, dd);
		}
	}

	public void populateSetDate(int year, int month, int day) {
		Log.i(TAG, "datePicker = " + datePicker);
		if(datePicker.equalsIgnoreCase("etxBday")) {
			etxBday.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtTraining_StartDate")) {
			txtTraining_StartDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtTraining_EndDate")) {
			txtTraining_EndDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtJoiningDate")) {
			txtJoiningDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtCompletionDate")) {
			txtCompletionDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtDateofRegistration")) {
			txtDateofRegistration.setText(month + "/" + day + "/" + year);
		}
	}

	/*
	 * For image
	 */

	private void selectImage() {

		doSavePicUri = false;
		setImageFile();

		//		final CharSequence[] options = { "Take Photo",
		//				"Choose from Gallery","Cancel" };
		final CharSequence[] options = { "Take Photo", "Cancel" };
		final String dir = Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)+ "/picFolder/";
		File newdir = new File(dir);
		newdir.mkdirs();
		AlertDialog.Builder builder = new AlertDialog.Builder(
				getActivity());
		if(builder !=null)
		{

			builder.setTitle("Add Photo!");
			builder.setItems(options, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int item) {
					if (options[item].equals("Take Photo")) {
						takePicture();
					} else if (options[item].equals("Choose from Gallery")) {
						openGallery();
					} else if (options[item].equals("Cancel")) {
						mFileTemp = null;
						dialog.dismiss();
					}
				}
			});

			builder.show();
		}
		else
		{
			builder =  null;
		}
	}

	private void takePicture() {

		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		try {
			//			Uri mImageCaptureUri = null;
			String state = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				mImageCaptureUri = Uri.fromFile(mFileTemp);
			} else {
				/*
				 * The solution is taken from here:
				 * http://stackoverflow.com/questions
				 * /10042695/how-to-get-camera-result-as-a-uri-in-data-folder
				 */
				mImageCaptureUri = InternalStorageContentProvider.CONTENT_URI;
			}
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			intent.putExtra("return-data", true);
			startActivityForResult(intent, REQUEST_CODE_TAKE_PICTURE);
		} catch (ActivityNotFoundException e) {

		}
	}

	private void openGallery() {

		Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
		photoPickerIntent.setType("image/*");
		startActivityForResult(photoPickerIntent, REQUEST_CODE_GALLERY);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != getActivity().RESULT_OK) {
			return;
		}
		Bitmap bitmap;
		doSavePicUri = true;
		switch (requestCode) {

		case REQUEST_CODE_GALLERY:
			try {
				picUri = data.getData();
				//				InputStream inputStream = getContentResolver().openInputStream(
				//						data.getData());
				//				FileOutputStream fileOutputStream = new FileOutputStream(
				//						mFileTemp);
				//				copyStream(inputStream, fileOutputStream);
				//				fileOutputStream.close();
				//				inputStream.close();

				// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
				//				compressImage = new CompressImage(context, mFileTemp);
				//				bitmap = compressImage.compressImage(mFileTemp.getPath());
				//				imgUserPic.setImageBitmap(bitmap);

				performCrop();
				/*	// Getting LocationManager object from System Service LOCATION_SERVICE
				LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

				// Creating a criteria object to retrieve provider
				Criteria criteria = new Criteria();

				// Getting the name of the best provider
				String provider = locationManager.getBestProvider(criteria, true);

				// Getting Current Location
				location = locationManager.getLastKnownLocation(provider);

				if(location!=null){
					if(gps.canGetLocation()){
				if(location!=null)
				{
					if(gps.canGetLocation())
					{
						getExif();
					}
					else
					{
						gps.showSettingsAlert();
					}
				}
				 */


			} catch (Exception e) {

				//				Log.e(TAG, "Error while creating temp file", e);
			}

			break;
		case REQUEST_CODE_TAKE_PICTURE:
			// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
			picUri = Uri.fromFile(mFileTemp);
			getExif();
			performCrop();
			//			 picUri = data.getData();

			/**
			 * Commented of compress image
			 */
			/*compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(bitmap);
			 */
			break;
		case REQUEST_CODE_CROP_IMAGE:

			/*
			 * String path = data.getStringExtra(CropImage.IMAGE_PATH); if (path
			 * == null) {
			 * 
			 * return; }
			 */
			// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());

			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(bitmap);
			break;

		case CROP_PIC:
			// get the returned data
			// get the cropped bitmap
			Bundle extras = data.getExtras();
			// get the cropped bitmap
			Bitmap thePic = extras.getParcelable("data");
			/*	compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());*/
			imgUserPic.setImageBitmap(thePic);
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}


	/**
	 * this function does the crop operation.
	 */
	private void performCrop() {
		// take care of exceptions
		try {
			// call the standard crop action intent (the user device may not
			// support it)
			Intent cropIntent = new Intent("com.android.camera.action.CROP");
			// indicate image type and Uri
			cropIntent.setDataAndType(picUri, "image/*");
			// set crop properties
			cropIntent.putExtra("crop", "true");
			// indicate aspect of desired crop
			/*	cropIntent.putExtra("aspectX", 2);
			cropIntent.putExtra("aspectY", 1);*/
			// indicate output X and Y
			cropIntent.putExtra("outputX", 200);
			cropIntent.putExtra("outputY", 150);
			// retrieve data on return
			cropIntent.putExtra("return-data", true);
			// start the activity - we handle returning in onActivityResult

			cropIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			cropIntent.putExtra("return-data", true);

			startActivityForResult(cropIntent, CROP_PIC);
		}

		// respond to users whose devices do not support the crop action
		catch (ActivityNotFoundException anfe) {
			Toast toast = Toast
					.makeText(getActivity(), "This device doesn't support the crop action!", Toast.LENGTH_SHORT);
			toast.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void copyStream(InputStream input, OutputStream output)
			throws IOException {

		byte[] buffer = new byte[1024];
		int bytesRead;
		while ((bytesRead = input.read(buffer)) != -1) {
			output.write(buffer, 0, bytesRead);
		}
	}

	public void getExif() {
		try {

			location = gps.location;
			//			Log.e(TAG, "testgps: location = " + location);
			loc2Exif(mFileTemp.getPath().toString(),location);

			/*ExifInterface mExif = new ExifInterface(mFileTemp.getPath().toString());
			String lat = ExifInterface.TAG_GPS_LATITUDE;
			String lat_data = mExif.getAttribute(lat);

			System.out.println("Exif file path"+mExif+lat_data);
			ShowExif(mExif);
			 */

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void loc2Exif(String flNm, Location loc) {
		try {
			ExifInterface ef = new ExifInterface(flNm);
			ef.setAttribute(ExifInterface.TAG_GPS_LATITUDE, dec2DMS(loc.getLatitude()));
			ef.setAttribute(ExifInterface.TAG_GPS_LONGITUDE,dec2DMS(loc.getLongitude()));

			//			ImcLat = loc.getLatitude();
			//			ImcLon= loc.getLongitude();
			//
			//
			//			System.out.println("lattitude"+ImcLat);
			//			System.out.println("longitude"+ImcLon);


			/*			To get the gps coordinates of this you need to do some math, here it comes:

				Calculate the total number of seconds:
				58′32″ = (58*60 + 32) = 3512 seconds.
				The fractional part is total number of seconds divided by 3600:
				3512 / 3600 = ~0.975556
				Add fractional degrees to whole degrees to produce the final result:
				51 + 0.975556 = 51.975556
				If it is a West longitude coordinate, negate the result. (it isn't this time)
				answer: 51.975556*/
			//			ShowExif(ef);
			if (loc.getLatitude() > 0) 
				ef.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, "N"); 

			else              
				ef.setAttribute(ExifInterface.TAG_GPS_LATITUDE_REF, "S");
			if (loc.getLongitude()>0) 
				ef.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, "E");    
			else             
				ef.setAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF, "W");
			ef.saveAttributes();
			//			exif2Loc(flNm);
		} catch (IOException e) {
			e.printStackTrace();
		}         
	}


	//-----------------------------------------------------------------------------------
	String dec2DMS(double coord) 
	{  
		coord = coord > 0 ? coord : -coord;  // -105.9876543 -> 105.9876543
		String sOut = Integer.toString((int)coord) + "/1,";   // 105/1,
		coord = (coord % 1) * 60;         // .987654321 * 60 = 59.259258
		sOut = sOut + Integer.toString((int)coord) + "/1,";   // 105/1,59/1,
		coord = (coord % 1) * 60000;             // .259258 * 60000 = 15555
		sOut = sOut + Integer.toString((int)coord) + "/1000";   // 105/1,59/1,15555/1000

		return sOut;


	}

	public void setImageFile() {
		/*
		 * // Store image in dcim // File file = new
		 * File(Environment.getExternalStorageDirectory() + "/DCIM/", "image" +
		 * new Date().getTime() + ".jpg"); File file = new
		 * File(Environment.getExternalStoragePublicDirectory
		 * (Environment.DIRECTORY_DCIM) + "/picFolder/"+ new Date().getTime() +
		 * ".jpg"); Uri imgUri = Uri.fromFile(file); this.ImagePath =
		 * file.getAbsolutePath();
		 * 
		 * System.out.println("ImagePath"+ImagePath); return imgUri;
		 */

		this.mFileTemp = new File(
				Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)	+ "/picFolder/" + new Date().getTime() + ".jpg");
		System.out.println("mFileTemp = " + mFileTemp);
	}

	/*
	 * To get data from database
	 */

	public class CandidateCategoryAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_CandidateCategoryDisplay!=null) {
				m_CandidateCategoryDisplay.clear();
			}
			if(m_CandidateCategory!=null) {
				m_CandidateCategory.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_candidate_category);
			if (table_length > 0) {
				System.out
				.println("TESTDB: CandidateCategoryAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_candidate_category, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					CandidateCategory candidateCategory = new CandidateCategory();
					candidateCategory.setCategoryName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_category_name)));
					candidateCategory
					.setCategoryValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_category_value)));
					m_CandidateCategoryDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_category_name)));
					m_CandidateCategory.add(candidateCategory);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> candidateCategoryAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item,
					m_CandidateCategoryDisplay);
			// set the view for the Drop down list
			candidateCategoryAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spCandidateCategory.setAdapter(candidateCategoryAdapter);
		}
	}

	public class StateAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_StateDisplay!=null) {
				m_StateDisplay.clear();
			}
			if(m_State!=null) {
				m_State.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_State);
			if (table_length > 0) {
				System.out
				.println("TESTDB: StateAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_State, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					States states = new States();
					states.setStateName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					states.setStateValues(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_value)));
					m_StateDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					m_State.add(states);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}
			//
			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> stateAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_StateDisplay);
			// set the view for the Drop down list
			stateAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spState.setAdapter(stateAdapter);

			spinnerSetGuj = stateAdapter.getPosition("Gujarat");
			spState.setSelection(spinnerSetGuj);
		}
	}

	public class DistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_DistrictDisplay!=null) {
				m_DistrictDisplay.clear();
			}
			if(m_District!=null) {
				m_District.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DistrictAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_state_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_state_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_DistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_District.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_DistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDistrict.setAdapter(districtAdapter);
		}
	}

	public class TalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_TalukaDisplay!=null) {
				m_TalukaDisplay.clear();
			}
			if(m_Taluka!=null) {
				m_Taluka.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: TalukaAsyncTask if - read from table table_length = "
						+ table_length);

				//				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_TalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_Taluka.add(taluka);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_TalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spTaluka.setAdapter(talukaAdapter);
		}
	}

	public class GenderAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_GenderDisplay!=null) {
				m_GenderDisplay.clear();
			}
			if(m_Gender!=null) {
				m_Gender.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Gender);
			if (table_length > 0) {
				System.out
				.println("TESTDB: GenderAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Gender, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Genders genders = new Genders();
					genders.setGenderName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_gender_name)));
					genders.setGenderValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_gender_value)));
					m_GenderDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_gender_name)));
					m_Gender.add(genders);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> genderAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_GenderDisplay);
			// set the view for the Drop down list
			genderAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spGender.setAdapter(genderAdapter);
		}
	}

	public class CasteAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_CasteDisplay!=null) {
				m_CasteDisplay.clear();
			}
			if(m_Caste!=null) {
				m_Caste.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Caste);
			if (table_length > 0) {
				System.out
				.println("TESTDB: CasteAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Caste, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Caste caste = new Caste();
					caste.setCasteName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_caste_name)));
					caste.setCasteValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_caste_value)));
					m_CasteDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_caste_name)));
					m_Caste.add(caste);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> casteAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_CasteDisplay);
			// set the view for the Drop down list
			casteAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spCaste.setAdapter(casteAdapter);
		}
	}


	public class DesignationAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_DesignationDisplay!=null) {
				m_DesignationDisplay.clear();
			}
			if(m_Designation!=null) {
				m_Designation.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Designation);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DesignationAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Designation, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Designation designation = new Designation();
					designation.setDesignation_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_value)));
					designation.setDesignation_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_DesignationDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_Designation.add(designation);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> designationAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_DesignationDisplay);
			// set the view for the Drop down list
			designationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDesignation.setAdapter(designationAdapter);

		}
	}

	/**
	 * 
	 * Newly Added Batches Asynctask
	 *
	 */
	
	public class BatchesAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_BatchesDisplay!=null) {
				m_BatchesDisplay.clear();
			}
			if(m_Batches!=null) {
				m_Batches.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_BATCH);
			if (table_length > 0) {
				System.out
				.println("TESTDB: BatchAsynctask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_BATCH, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkBatch ikvkbatch = new IkvkBatch();
					ikvkbatch.setBatch_value(result.getString(result.getColumnIndex(DataBaseHelper.KEY_BATCH_VALUES)));
					ikvkbatch.setBatch_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_BATCH_NAME)));
					m_BatchesDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_BATCH_NAME)));
					m_Batches.add(ikvkbatch);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> designationAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_BatchesDisplay);
			// set the view for the Drop down list
			designationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spBatch.setAdapter(designationAdapter);

		}
	}

	
	private void insertUserData() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		/*
		 * mandatory fields
		 */
		if (doSavePicUri == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_user_pic);
			isInsertInDb = false;
		}
		if (spCandidateCategory.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_client_cat);
			isInsertInDb = false;
		}
		if (etxFirstName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_fname);
			isInsertInDb = false;
		}
		/*if (etxMiddleName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mname);
			isInsertInDb = false;
		}*/
		if (etxLastName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_lname);
			isInsertInDb = false;
		}
		if (etxFmhName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_fmhname);
			isInsertInDb = false;
		}
		if (etxAddress.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_address);
			isInsertInDb = false;
		}
		if (spState.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_state);
			isInsertInDb = false;
		}
		if (spDistrict.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_district);
			isInsertInDb = false;
		}
		if (spTaluka.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_taluka);
			isInsertInDb = false;
		}
		if (etxCity.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_city);
			isInsertInDb = false;
		}
		if (etxMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mobno);
			isInsertInDb = false;
		} else if(etxMobile.getText().toString().length()<10) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_mobno);
			isInsertInDb = false;			
		}
		if (spGender.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_gender);
			isInsertInDb = false;
		}
		if (spCaste.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_cast);
			isInsertInDb = false;
		}
		if (etxBday.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_bdy);
			isInsertInDb = false;
		}
		if (etxPincode.getText().toString().equalsIgnoreCase("") == false && etxPincode.getText().toString().length()<6) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_pinno);
			isInsertInDb = false;			
		}		
		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_email);
			isInsertInDb = false;			
		}

		if (spDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_designation);
			isInsertInDb = false;
		}

		int intChkPhysical = chkPhysical.isChecked() ? 1 : 0;
		if (intChkPhysical == 1
				&& etxPhysical.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_phical_perc);
			isInsertInDb = false;
		}

		int intChkExArmy = chkExArmy.isChecked() ? 1 : 0;
		int intChkWidow = chkWidow.isChecked() ? 1 : 0;
		int intChkDivorcee = chkDivorcee.isChecked() ? 1 : 0;
		int intChkMinority = chkMinority.isChecked() ? 1 : 0;
		int intChkBpl = chkBpl.isChecked() ? 1 : 0;

		/*
		 * Non-mandatory fields
		 */
		if (isInsertInDb) {
			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// db.beginTransaction();
			System.out.println("Insert in db");
			// Insert in db
			ContentValues contentValues = new ContentValues();
			contentValues.put(DataBaseHelper.KEY_rca_user_email, Global.USER_EMAIL);

			/*
			 * Mandatory fields
			 */
			contentValues.put(DataBaseHelper.KEY_rca_candidate_category,
					spCandidateCategory.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_first_name, etxFirstName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_rca_middle_name, etxMiddleName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_rca_last_name, etxLastName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_rca_fmh_name, etxFmhName.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_rca_address, etxAddress.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_rca_state, spState
					.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_district, spDistrict
					.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_taluka, spTaluka.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_city, etxCity.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_rca_mobileno, etxMobile.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_rca_gender, spGender
					.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_caste, spCaste
					.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_birthday, etxBday.getText()
					.toString());

			designationValue = m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_values();

			contentValues.put(DataBaseHelper.KEY_rca_designation_name, spDesignation.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_designation_value, designationValue);
			/*
			 * Non-mandatory fields
			 */
			contentValues.put(DataBaseHelper.KEY_rca_chk_ph, intChkPhysical);
			if (intChkPhysical == 1) {
				contentValues.put(DataBaseHelper.KEY_rca_percentage_ph, etxPhysical
						.getText().toString());
			} else {
				contentValues.put(DataBaseHelper.KEY_rca_percentage_ph, "");
			}
			contentValues.put(DataBaseHelper.KEY_rca_chk_exarmy, intChkExArmy);
			contentValues.put(DataBaseHelper.KEY_rca_chk_widow, intChkWidow);
			contentValues.put(DataBaseHelper.KEY_rca_chk_divorcee, intChkDivorcee);
			contentValues.put(DataBaseHelper.KEY_rca_chk_minority, intChkMinority);
			contentValues.put(DataBaseHelper.KEY_rca_chk_bpl, intChkBpl);

			contentValues.put(DataBaseHelper.KEY_rca_email, etxEmail.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_rca_pincode, etxPincode.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_rca_lline, etxLline.getText()
					.toString());

			if(location!=null) {
				//				Log.i(TAG, "store from current location");
				System.out.println("ImcLatDB"+location.getLatitude());
				System.out.println("ImcLonDB"+location.getLongitude());
				contentValues.put(DataBaseHelper.KEY_rca_lattitude, Double.toString(location.getLatitude()));
				contentValues.put(DataBaseHelper.KEY_rca_longitude, Double.toString(location.getLongitude()));
			} else {
				//				Log.i(TAG, "store from default value");
				contentValues.put(DataBaseHelper.KEY_rca_lattitude, Global.getLat(getActivity()));
				contentValues.put(DataBaseHelper.KEY_rca_longitude, Global.getLng(getActivity()));
			}
			if (mFileTemp != null) {
				contentValues.put(DataBaseHelper.KEY_rca_image_path,
						mFileTemp.toString());
			}

			if(positionCandidateCategory==1) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_ikvk");
				db.insert(DataBaseHelper.TABLE_register_candidate, null, contentValues);
			} else if(positionCandidateCategory == 2) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_skillcerti");
				db.insert(DataBaseHelper.TABLE_register_candidate, null, contentValues);
			} else if (positionCandidateCategory == 3) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_apprentice");
				db.insert(DataBaseHelper.TABLE_register_candidate, null, contentValues);
			}	

			etxFirstName.setText("");
			etxMiddleName.setText("");
			etxLastName.setText("");
			etxFmhName.setText("");
			etxAddress.setText("");
			etxCity.setText("");
			etxPincode.setText("");
			etxMobile.setText("");
			etxLline.setText("");
			etxPhysical.setText("");
			etxEmail.setText("");
			etxBday.setText("");

			chkPhysical.setChecked(false);
			chkExArmy.setChecked(false);
			chkWidow.setChecked(false);
			chkDivorcee.setChecked(false);
			chkMinority.setChecked(false);
			chkBpl.setChecked(false);

			spCandidateCategory.setSelection(0);
			spCaste.setSelection(0);
			spDistrict.setSelection(0);
			spGender.setSelection(0);
			spState.setSelection(0);
			spDesignation.setSelection(0);

			imgUserPic.setImageResource(R.drawable.ic_add_user_image);
			Global.showAlertDialog(context, "Profile :",
					"Inserted Successfully", false);

			spState.setSelection(spinnerSetGuj);
		} else {
			System.out.println("alert");
			Global.showAlertDialog(getActivity(),
					"Mandatory fields", errorMessage, false);
		}

	}

	private void ShowExif(ExifInterface exif) {
		String myAttribute = "Exif information ---\n";
		myAttribute += getTagString(ExifInterface.TAG_DATETIME, exif);
		myAttribute += getTagString(ExifInterface.TAG_FLASH, exif);
		myAttribute += getTagString(ExifInterface.TAG_GPS_LATITUDE, exif);
		myAttribute += getTagString(ExifInterface.TAG_GPS_LATITUDE_REF, exif);
		myAttribute += getTagString(ExifInterface.TAG_GPS_LONGITUDE, exif);
		myAttribute += getTagString(ExifInterface.TAG_GPS_LONGITUDE_REF, exif);
		myAttribute += getTagString(ExifInterface.TAG_IMAGE_LENGTH, exif);
		myAttribute += getTagString(ExifInterface.TAG_IMAGE_WIDTH, exif);
		myAttribute += getTagString(ExifInterface.TAG_MAKE, exif);
		myAttribute += getTagString(ExifInterface.TAG_MODEL, exif);
		myAttribute += getTagString(ExifInterface.TAG_ORIENTATION, exif);
		myAttribute += getTagString(ExifInterface.TAG_WHITE_BALANCE, exif);
		// myTextView.setText(myAttribute);
		System.out.println("myAttribute = " + myAttribute);

		System.out
		.println("exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE) = "
				+ exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE));
		System.out
		.println("exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF) = "
				+ exif.getAttribute(ExifInterface.TAG_GPS_LATITUDE_REF));
		System.out
		.println("exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE) = "
				+ exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE));
		System.out
		.println("exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF) = "
				+ exif.getAttribute(ExifInterface.TAG_GPS_LONGITUDE_REF));
	}

	private String getTagString(String tag, ExifInterface exif) {
		return (tag + " : " + exif.getAttribute(tag) + "\n");
	}

	private void setDistrict() {
		String tmpSataeName = spState.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_State + " where " + DataBaseHelper.KEY_state_name + " = '" + tmpSataeName +"'" , null);
		result.moveToFirst();
		String tmpStateId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_state_value));

		if(!result.isClosed()) {
			result.close();				
		}
		new DistrictAsyncTask().execute(tmpStateId); 			
	}

	private void setTaluka() {
		String tmpDistrictName = spDistrict.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
		result.moveToFirst();
		String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));

		if(!result.isClosed()) {
			result.close();				
		}
		new TalukaAsyncTask().execute(tmpDistrictId); 			
	}

	/*
	 * Ikvk valus set 
	 */
	//	TODO initialization for iIKVK
	private void viewInitIkvk() {
		new IKVKCourseAsyncTask().execute();
		new IKVKCentreAsyncTask().execute();
		new IKVKShiftAsyncTask().execute();
		new BatchesAsyncTask().execute();
	}

	public class IKVKCourseAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_IkvkCourseDisplay!=null) {
				m_IkvkCourseDisplay.clear();
			}
			if(m_IkvkCourse!=null) {
				m_IkvkCourse.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_COURSE_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IKVKCourseAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_COURSE_MASTER, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkCourse ikvkCourse = new IkvkCourse();
					ikvkCourse.setCOURSE_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_CODE)));
					ikvkCourse.setCOURSE_NAME(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_NAME)));
					m_IkvkCourseDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_NAME)));
					m_IkvkCourse.add(ikvkCourse);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> ikvkCouesAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_IkvkCourseDisplay);
			// set the view for the Drop down list
			ikvkCouesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spikvk_Course.setAdapter(ikvkCouesAdapter);
		}
	}


	public class IKVKCentreAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_IkvkCentreDisplay!=null) {
				m_IkvkCentreDisplay.clear();
			}
			if(m_IkvkCentre!=null) {
				m_IkvkCentre.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_ESTABLISHMENT_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IKVKCentreAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkCenter ikvkCenter = new IkvkCenter();
					ikvkCenter.setESTABLISHMENT_NO(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_NO)));
					ikvkCenter.setESTABLISHMENT_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_CODE)));
					ikvkCenter.setESTABLISHMENT_NAME_E(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_NAME_E)));
					m_IkvkCentreDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_NAME_E)));
					m_IkvkCentre.add(ikvkCenter);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> ikvkCenterAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_IkvkCentreDisplay);
			// set the view for the Drop down list
			ikvkCenterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spiKVKCenter.setAdapter(ikvkCenterAdapter);
		}
	}

	public class IKVKShiftAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_IkvkShiftDisplay!=null) {
				m_IkvkShiftDisplay.clear();
			}
			if(m_IKvkShift!=null) {
				m_IKvkShift.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Preferredshift);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IKVKShiftAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Preferredshift, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkShift ikvkShift = new IkvkShift();
					ikvkShift.setREF_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Preferredshift)));
					ikvkShift.setPREFERRED_SHIFT(result.getString(result.getColumnIndex(DataBaseHelper.KEY_PREFERRED_SHIFT)));
					m_IkvkShiftDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_PREFERRED_SHIFT)));
					m_IKvkShift.add(ikvkShift);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> ikvkShiftAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_IkvkShiftDisplay);
			// set the view for the Drop down list
			ikvkShiftAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spPreferredShift.setAdapter(ikvkShiftAdapter);
		}
	}

	// TODO initialization for Skill Certification	
	/*
	 * Skill Certification
	 */
	private void viewInitSC() {
		new SCRegionAsyncTask().execute();
		new SCRelevantSectorAsyncTask().execute();
	}
	public class SCRegionAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCRegionDisplay!=null) {
				m_SCRegionDisplay.clear();
			}
			if(m_SCRegion!=null) {
				m_SCRegion.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Region);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCRegionAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Region, null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Region region = new Region();
					region.setRegion_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value)));
					region.setRegion_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_SCRegionDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_SCRegion.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> regionAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_SCRegionDisplay);
			// set the view for the Drop down list
			regionAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCRegion.setAdapter(regionAdapter);
		}
	}

	/**
	 * 
	 * District Skill Certification
	 *
	 */
	public class SCDistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCDistrictDisplay !=null) {
				m_SCDistrictDisplay .clear();
			}
			if(m_SCDistricts !=null) {
				m_SCDistricts.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCDistrictAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_region_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_region_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_SCDistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_SCDistricts.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;	
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_SCDistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCDistrict.setAdapter(districtAdapter);
		}
	}	

	/**
	 * 
	 * Taluka Skill Certification
	 *
	 */
	public class SCTalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCTalukaDisplay!=null) {
				m_SCTalukaDisplay.clear();
			}
			if(m_SCTaluka!=null) {
				m_SCTaluka.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCTalukaAsyncTask if - read from table table_length = "
						+ table_length);

				//				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_SCTalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_SCTaluka.add(taluka);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_SCTalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCTaluka.setAdapter(talukaAdapter);
		}
	}

	public class SCRelevantSectorAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCRelevantSectorDisplay!=null) {
				m_SCRelevantSectorDisplay.clear();
			}
			if(m_SCRelevantSector!=null) {
				m_SCRelevantSector.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Sector_Master);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCRelevantSectorAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Sector_Master, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					ReleventSector releventSector = new ReleventSector();
					releventSector.setREF_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Sector_Master)));
					releventSector.setCOURSE_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_CODE_Sector_Master)));
					releventSector.setSECTOR_NAME(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SECTOR_NAME)));

					m_SCRelevantSectorDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SECTOR_NAME)));
					m_SCRelevantSector.add(releventSector);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> relevantSectorAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_SCRelevantSectorDisplay);
			// set the view for the Drop down list
			relevantSectorAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCRelevantSector.setAdapter(relevantSectorAdapter);
		}
	}

	public class SCModuleSkillAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCModuleSkillDisplay!=null) {
				m_SCModuleSkillDisplay.clear();
			}
			if(m_SCModuleskill!=null) {
				m_SCModuleskill.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Skill_Master);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCModuleSkillAsyncTask if - read from table table_length = "
						+ table_length);

				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Skill_Master + " where " + DataBaseHelper.KEY_SECTOR_ID + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_SECTOR_ID + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Moduleskill moduleskill = new Moduleskill();
					moduleskill.setSECTOR_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SECTOR_ID)));
					moduleskill.setSKILL_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SKILL_CODE)));
					moduleskill.setSKILL_NAME(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SKILL_NAME)));	
					moduleskill.setSKILL_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Skill_Master)));
					m_SCModuleSkillDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SKILL_NAME)));
					m_SCModuleskill.add(moduleskill);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> moduleAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_SCModuleSkillDisplay);
			// set the view for the Drop down list
			moduleAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCModuleSkill.setAdapter(moduleAdapter);
		}
	}


	private void setSCDistrict() {
		try
		{
			String tmpRegionName = spSCRegion.getSelectedItem().toString();

			SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

			Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_name + " = '" + tmpRegionName +"'" , null);
			result.moveToFirst();
			String tmpRegionId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value));

			if(!result.isClosed()) {
				result.close();				
			}
			new SCDistrictAsyncTask().execute(tmpRegionId); 		
		}
		catch(Exception e)
		{

		}
	}

	private void setSCTaluka() {
		try
		{
			String tmpDistrictName = spSCDistrict.getSelectedItem().toString();

			SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

			Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
			result.moveToFirst();
			String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));

			if(!result.isClosed()) {
				result.close();				
			}
			new SCTalukaAsyncTask().execute(tmpDistrictId);
		}
		catch(Exception e)
		{

		}

	}

	private void setSCModuleSkill() {
		try
		{
		String tmpRelvantSectorName = spSCRelevantSector.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_Sector_Master + " where " + DataBaseHelper.KEY_SECTOR_NAME + " = '" + tmpRelvantSectorName +"'" , null);
		result.moveToFirst();
		String tmpRelevantSectorId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Sector_Master));

		if(!result.isClosed()) {
			result.close();				
		}
		new SCModuleSkillAsyncTask().execute(tmpRelevantSectorId);
		}
		catch(Exception e)
		{
			
		}
	}

	//	TODO initialization for Apprentice
	private void viewInitAP() {
		new APDesignatedAsyncTask().execute();
		new APInstituteAsyncTask().execute();
	}

	public class APDesignatedAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_APDesignatedTradeDisplay!=null) {
				m_APDesignatedTradeDisplay.clear();
			}
			if(m_APDesignatedTrade!=null) {
				m_APDesignatedTrade.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_TRADE_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: APDesignatedAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_TRADE_MASTER, null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					APDesTrade apDesTrade = new APDesTrade();
					apDesTrade.setTRADE_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_TRADE_ID_TRADE_MASTER)));
					apDesTrade.setTRADE_NAME_E(result.getString(result.getColumnIndex(DataBaseHelper.KEY_TRADE_NAME_E)));
					m_APDesignatedTradeDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_TRADE_NAME_E)));
					m_APDesignatedTrade.add(apDesTrade);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> apDesginatedAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_APDesignatedTradeDisplay);
			// set the view for the Drop down list
			apDesginatedAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spAPDesignatedTrade.setAdapter(apDesginatedAdapter);
		}
	}

	public class APInstituteAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_APInstituteDisplay!=null) {
				m_APInstituteDisplay.clear();
			}
			if(m_APInstitute!=null) {
				m_APInstitute.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_ITI_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: APInstituteAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_ITI_MASTER, null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					APInstitute apInstitute = new APInstitute();
					apInstitute.setITI_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_ID_ITI_MASTER)));
					apInstitute.setITI_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_CODE)));
					apInstitute.setITI_NAME_E(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_NAME_E)));
					m_APInstituteDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_NAME_E)));
					m_APInstitute.add(apInstitute);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> apInstituteAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_APInstituteDisplay);
			// set the view for the Drop down list
			apInstituteAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spAPInstitute.setAdapter(apInstituteAdapter);
		}
	}

	// TODO insertation of data in new table
	private void newInsertUserData() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		/*
		 * mandatory fields
		 */

		if (doSavePicUri == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_user_pic);
			isInsertInDb = false;
		}
		if (spCandidateCategory.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_client_cat);
			isInsertInDb = false;
		}
		if (etxFirstName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_fname);
			isInsertInDb = false;
		}
		/*if (etxMiddleName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mname);
			isInsertInDb = false;
		}*/
		if (etxLastName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_lname);
			isInsertInDb = false;
		}
		if (etxFmhName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_fmhname);
			isInsertInDb = false;
		}
		if (etxAddress.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_address);
			isInsertInDb = false;
		}
		if (spState.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_state);
			isInsertInDb = false;
		}
		if (spDistrict.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_district);
			isInsertInDb = false;
		}
		if (spTaluka.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_taluka);
			isInsertInDb = false;
		}
		if (etxCity.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_city);
			isInsertInDb = false;
		}
		if (etxMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mobno);
			isInsertInDb = false;
		} else if(etxMobile.getText().toString().length()<10) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_mobno);
			isInsertInDb = false;			
		}
		if (spGender.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_gender);
			isInsertInDb = false;
		}
		if (spCaste.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_cast);
			isInsertInDb = false;
		}
		if (etxBday.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_bdy);
			isInsertInDb = false;
		}
		if (etxPincode.getText().toString().equalsIgnoreCase("") == false && etxPincode.getText().toString().length()<6) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_pinno);
			isInsertInDb = false;			
		}		
		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_email);
			isInsertInDb = false;			
		}

		if (spDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_designation);
			isInsertInDb = false;
		}

		int intChkPhysical = chkPhysical.isChecked() ? 1 : 0;
		if (intChkPhysical == 1
				&& etxPhysical.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_phical_perc);
			isInsertInDb = false;
		}

		int intChkExArmy = chkExArmy.isChecked() ? 1 : 0;
		int intChkWidow = chkWidow.isChecked() ? 1 : 0;
		int intChkDivorcee = chkDivorcee.isChecked() ? 1 : 0;
		int intChkMinority = chkMinority.isChecked() ? 1 : 0;
		int intChkBpl = chkBpl.isChecked() ? 1 : 0;

		// TODO validations for other details		
		if(positionCandidateCategory==1) {

			/*			ch_ikvk_ApplicantType  = (Switch)m_rootView. findViewById(R.id.ch_ikvk_ApplicantType);
						What to do ?
			 */

			if (spikvk_Course.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_courseikvkdetails);
				isInsertInDb = false;
			}
			if (spiKVKCenter.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_ikvkdetails);
				isInsertInDb = false;
			}
			if (spPreferredShift.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_shiftikvkdetails);
				isInsertInDb = false;
			}
			/*	
			 * Commented as no data in it
			 * if (spBatch.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_batchesikvkdetails);
				isInsertInDb = false;
			}*/
			if (txtTraining_StartDate.getText().toString().equalsIgnoreCase(""))  {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_trainingstartdateikvkdetails);
				isInsertInDb = false;
			}
			if (txtTraining_EndDate.getText().toString().equalsIgnoreCase(""))  {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_trainingenddateikvkdetails);
				isInsertInDb = false;
			}

		} else if(positionCandidateCategory==2) {

			if (txtind_Name.getText().toString().equalsIgnoreCase(""))  {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_name);
				isInsertInDb = false;
			}

			if (txtSCEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(txtSCEmail.getText().toString()) == false) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_email);
				isInsertInDb = false;			
			}

			/*if(txtPhone.getText().toString().length()<10) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_phone);
				isInsertInDb = false;			
			}*/

			if (spSCRegion.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_region);
				isInsertInDb = false;
			}
			if (spSCDistrict.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_district);
				isInsertInDb = false;
			}
			if (spSCTaluka.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_taluka);
				isInsertInDb = false;
			}
			if (spSCRelevantSector.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_sector);
				isInsertInDb = false;
			}
			if (spSCModuleSkill.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_moduleskill);
				isInsertInDb = false;
			}

		} else if(positionCandidateCategory==3) {
			/*			ch_app_ApplicantType = (Switch)m_rootView. findViewById(R.id.ch_app_ApplicantType);
			 */

			if (spAPDesignatedTrade.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_apprentice_designationtrade);
				isInsertInDb = false;
			}

		}

		/*
		 * Non-mandatory fields
		 */
		if (isInsertInDb) {
			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// db.beginTransaction();
			System.out.println("Insert in TABLE_APPLICANT_MASTER");
			// Insert in db
			ContentValues contentValues = new ContentValues();
			//			TODO
			contentValues.put(DataBaseHelper.KEY_APPLICANT_MASTER_user_email, Global.USER_EMAIL);

			/*
			 * Mandatory fields
			 */
			contentValues.put(DataBaseHelper.KEY_APPLICANT_CATEGORY_ID,
					m_CandidateCategory.get(spCandidateCategory.getSelectedItemPosition()).getCategoryValue());

			if (mFileTemp != null) {
				contentValues.put(DataBaseHelper.KEY_APPLICANT_PHOTO,
						mFileTemp.toString());
			}

			contentValues.put(DataBaseHelper.KEY_APPLICANT_FNAME_E, etxFirstName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_APPLICANT_MNAME_E, etxMiddleName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_APPLICANT_LNAME_E, etxLastName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_APPLICANT_FATHER_NAME_E, etxFmhName.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ADDRESS_E, etxAddress.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_STATE_ID, 
					m_State.get(spState.getSelectedItemPosition()).getStateValues());
			contentValues.put(DataBaseHelper.KEY_STATE_ID_DISPLAY, 
					m_State.get(spState.getSelectedItemPosition()).getStateName());

			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID_APPLCANT_MASTER,
					m_District.get(spDistrict.getSelectedItemPosition()).getDistrictValue());
			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID_APPLCANT_MASTER_DISPLAY,
					m_District.get(spDistrict.getSelectedItemPosition()).getDistrictName());			

			contentValues.put(DataBaseHelper.KEY_TALUKA_ID_APPLCANT_MASTER,
					m_Taluka.get(spTaluka.getSelectedItemPosition()).getTaluka_values());
			contentValues.put(DataBaseHelper.KEY_TALUKA_ID_APPLCANT_MASTER_DISPLAY,
					m_Taluka.get(spTaluka.getSelectedItemPosition()).getTaluka_name());			

			contentValues.put(DataBaseHelper.KEY_CITY, etxCity.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_PINCODE, etxPincode.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_MOBILE_NO, etxMobile.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_LANDLINE_NO, etxLline.getText()
					.toString());
			
			contentValues.put(DataBaseHelper.KEY_GENDER, 
					m_Gender.get(spGender.getSelectedItemPosition()).getGenderValue());
			contentValues.put(DataBaseHelper.KEY_GENDER_DISPLAY, 
					m_Gender.get(spGender.getSelectedItemPosition()).getGenderName());

			contentValues.put(DataBaseHelper.KEY_CASTE,
					m_Caste.get(spCaste.getSelectedItemPosition()).getCasteValue());
			contentValues.put(DataBaseHelper.KEY_CASTE_DISPLAY,
					m_Caste.get(spCaste.getSelectedItemPosition()).getCasterName());

			contentValues.put(DataBaseHelper.KEY_PHYSICAL_HANDICAP, intChkPhysical);
			if (intChkPhysical == 1) {
				contentValues.put(DataBaseHelper.KEY_PH_VALUE, etxPhysical
						.getText().toString());
			} else {
				contentValues.put(DataBaseHelper.KEY_PH_VALUE, "");
			}

			contentValues.put(DataBaseHelper.KEY_EX_ARMY, intChkExArmy);
			contentValues.put(DataBaseHelper.KEY_WIDOW, intChkWidow);
			contentValues.put(DataBaseHelper.KEY_DIVORCEE, intChkDivorcee);
			contentValues.put(DataBaseHelper.KEY_MINORITY, intChkMinority);
			contentValues.put(DataBaseHelper.KEY_BPL, intChkBpl);

			contentValues.put(DataBaseHelper.KEY_EMAIL_ADDRESS, etxEmail.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_BIRTH_DATE, etxBday.getText()
					.toString());



			if(location!=null) {
				//				Log.i(TAG, "store from current location");
				System.out.println("ImcLatDB"+location.getLatitude());
				System.out.println("ImcLonDB"+location.getLongitude());
				contentValues.put(DataBaseHelper.KEY_LATTITUDE, Double.toString(location.getLatitude()));
				contentValues.put(DataBaseHelper.KEY_LONGITUDE, Double.toString(location.getLongitude()));
			} else {
				//				Log.i(TAG, "store from default value");
				contentValues.put(DataBaseHelper.KEY_LATTITUDE, Global.getLat(getActivity()));
				contentValues.put(DataBaseHelper.KEY_LONGITUDE, Global.getLng(getActivity()));
			}

			/*if(positionCandidateCategory==1) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_ikvk");
				db.insert(DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null, contentValues);
				insertInIkvk();
			} else if(positionCandidateCategory == 2) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_skillcerti");
				db.insert(DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null, contentValues);
				insertInSkill();
			} else if (positionCandidateCategory == 3) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_apprentice");
				db.insert(DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null, contentValues);
				insertInApprentice();
			}	*/

			db.insert(DataBaseHelper.TABLE_APPLICANT_MASTER, null, contentValues);

			insertOtherDetails();

			etxFirstName.setText("");
			etxMiddleName.setText("");
			etxLastName.setText("");
			etxFmhName.setText("");
			etxAddress.setText("");
			etxCity.setText("");
			etxPincode.setText("");
			etxMobile.setText("");
			etxLline.setText("");
			etxPhysical.setText("");
			etxEmail.setText("");
			etxBday.setText("");

			/***
			 * Newly added parameters
			 */
			txtTraining_StartDate.setText("");
			txtTraining_EndDate.setText("");
			txtind_Name.setText("");
			txtadname.setText("");
			txtcontact.setText("");
			txtSCEmail.setText("");
			txtPhone.setText("");
			txtappSeatNumber.setText("");
			txtJoiningDate.setText("");
			txtCompletionDate.setText("");
			txtRegistrationNumber.setText("");
			txtDateofRegistration.setText("");

			chkPhysical.setChecked(false);
			chkExArmy.setChecked(false);
			chkWidow.setChecked(false);
			chkDivorcee.setChecked(false);
			chkMinority.setChecked(false);
			chkBpl.setChecked(false);

			spCandidateCategory.setSelection(0);
			spCaste.setSelection(0);
			spDistrict.setSelection(0);
			spGender.setSelection(0);
			spState.setSelection(0);
			spDesignation.setSelection(0);

			/***
			 * Newly added parameters
			 */
			spikvk_Course.setSelection(0);
			spiKVKCenter.setSelection(0);
			spPreferredShift.setSelection(0);
			spBatch.setSelection(0);
			spSCRegion.setSelection(0);
			spSCDistrict.setSelection(0);
			spSCTaluka.setSelection(0);
			spSCRelevantSector.setSelection(0);
			spSCModuleSkill.setSelection(0);
			spAPInstitute.setSelection(0);
			spAPDesignatedTrade.setSelection(0);
			spBatch.setSelection(0);


			imgUserPic.setImageResource(R.drawable.ic_add_user_image);
			Global.showAlertDialog(context, "Profile :",
					"Inserted Successfully", false);

			spState.setSelection(spinnerSetGuj);
		} else {
			System.out.println("alert");
			Global.showAlertDialog(getActivity(),
					"Mandatory fields", errorMessage, false);
		}

	}

	//	TODO Insertation for other deatails

	private void insertOtherDetails() {
		SQLiteDatabase db = mDbHelper.getWritableDatabase();
		// db.beginTransaction();
		System.out.println("Insert in TABLE_APPLICANT_REGS_OTHER_DETAILS");

		int lastEntered_Id = -1;
		long table_length = DatabaseUtils.queryNumEntries(db,DataBaseHelper.TABLE_APPLICANT_MASTER);
		if (table_length > 0) {
			System.out
			.println("TESTDB: insertInIkvk if - read from table table_length = "
					+ table_length);
			Cursor result = db.rawQuery("select REF_ID from "+ DataBaseHelper.TABLE_APPLICANT_MASTER, null);
			if(result!=null) {
				result.moveToLast();
				lastEntered_Id = result.getInt(result.getColumnIndex(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID));
				Log.e(TAG, "lastEntered_Id = " + lastEntered_Id);
			}
			if (!result.isClosed()) {
				result.close();
			}
		}

		ContentValues contentValues = new ContentValues();
		contentValues.put(DataBaseHelper.KEY_APPLICANT_ID, lastEntered_Id);

		if(positionCandidateCategory==1) {
			//			Switch ch_ikvk_ApplicantType; 
			//			Spinner spikvk_Course,spiKVKCenter,spPreferredShift,spBatch;
			//			EditText txtTraining_StartDate,txtTraining_EndDate;
			//
			//			private ArrayList<String> m_IkvkCourseDisplay = new ArrayList<String>();
			//			private ArrayList<IkvkCourse> m_IkvkCourse = new ArrayList<IkvkCourse>();
			//			private ArrayList<String> m_IkvkCentreDisplay = new ArrayList<String>();
			//			private ArrayList<IkvkCenter> m_IkvkCentre = new ArrayList<IkvkCenter>();
			//			private ArrayList<String> m_IkvkShiftDisplay = new ArrayList<String>();
			//			private ArrayList<IkvkShift> m_IKvkShift = new ArrayList<IkvkShift>();

			contentValues.put(DataBaseHelper.KEY_DESIGNATION, 
					m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_name());

			String str_ikvk_ApplicantType = ch_ikvk_ApplicantType.isChecked() ? getResources().getString(R.string.ikvk_fresher) : getResources().getString(R.string.ikvk_InHouse);
			contentValues.put(DataBaseHelper.KEY_APP_TYPE, str_ikvk_ApplicantType);

			contentValues.put(DataBaseHelper.KEY_COURSE_ID, 
					m_IkvkCourse.get(spikvk_Course.getSelectedItemPosition()).getCOURSE_CODE());
			contentValues.put(DataBaseHelper.KEY_COURSE_ID_DISPLAY, 
					m_IkvkCourse.get(spikvk_Course.getSelectedItemPosition()).getCOURSE_NAME());

			contentValues.put(DataBaseHelper.KEY_IKVK_CENTER_ID, 
					m_IkvkCentre.get(spiKVKCenter.getSelectedItemPosition()).getESTABLISHMENT_CODE());
			contentValues.put(DataBaseHelper.KEY_IKVK_CENTER_ID_DISPLAY, 
					m_IkvkCentre.get(spiKVKCenter.getSelectedItemPosition()).getESTABLISHMENT_NAME_E());

			contentValues.put(DataBaseHelper.KEY_SHIFT, 
					m_IKvkShift.get(spPreferredShift.getSelectedItemPosition()).getREF_ID());
			contentValues.put(DataBaseHelper.KEY_SHIFT_DISPLAY, 
					m_IKvkShift.get(spPreferredShift.getSelectedItemPosition()).getPREFERRED_SHIFT());

			contentValues.put(DataBaseHelper.KEY_BATCH_ID, 
					m_Batches.get(spBatch.getSelectedItemPosition()).getBatch_value());
						
			contentValues.put(DataBaseHelper.KEY_BATCH_ID_DISPLAY, 
					m_Batches.get(spBatch.getSelectedItemPosition()).getBatch_name());

			contentValues.put(DataBaseHelper.KEY_JOINING_DATE, txtTraining_StartDate
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_COMPLETION_DATE, txtTraining_EndDate.getText()
					.toString());
			
			db.insert(DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS, null, contentValues);

		} else if(positionCandidateCategory==2) {

			/***
			 * New Parameters Industry Category
			 */
			//			EditText txtind_Name,txtadname,txtcontact,txtSCEmail,txtPhone;
			//			Spinner spSCRegion,spSCDistrict,spSCTaluka,spSCRelevantSector,spSCModuleSkill;
			//
			//			private ArrayList<String> m_SCRegionDisplay = new ArrayList<String>();
			//			private ArrayList<Region> m_SCRegion = new ArrayList<Region>();
			//			private ArrayList<String> m_SCDistrictDisplay = new ArrayList<String>();
			//			private ArrayList<District> m_SCDistricts = new ArrayList<District>();	
			//			private ArrayList<String> m_SCTalukaDisplay = new ArrayList<String>();
			//			private ArrayList<Taluka> m_SCTaluka = new ArrayList<Taluka>();
			//			private ArrayList<String> m_SCRelevantSectorDisplay = new ArrayList<String>();
			//			private ArrayList<ReleventSector> m_SCRelevantSector = new ArrayList<ReleventSector>();	
			//			private ArrayList<String> m_SCModuleSkillDisplay = new ArrayList<String>();
			//			private ArrayList<Moduleskill> m_SCModuleskill= new ArrayList<Moduleskill>();

			contentValues.put(DataBaseHelper.KEY_DESIGNATION, 
					m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_name());

			contentValues.put(DataBaseHelper.KEY_EST_NAME, 
					txtind_Name.getText().toString());

			contentValues.put(DataBaseHelper.KEY_ADDRESS, 
					txtadname.getText().toString());

			contentValues.put(DataBaseHelper.KEY_CONTACT_PERSON, 
					txtcontact.getText().toString());

			contentValues.put(DataBaseHelper.KEY_EMAIL_ID, 
					txtSCEmail.getText().toString());

			contentValues.put(DataBaseHelper.KEY_PHONE_NO, 
					txtPhone.getText().toString());

			contentValues.put(DataBaseHelper.KEY_REGION_ID, 
					m_SCRegion.get(spSCRegion.getSelectedItemPosition()).getRegion_values());
			contentValues.put(DataBaseHelper.KEY_REGION_ID_DISPLAY, 
					m_SCRegion.get(spSCRegion.getSelectedItemPosition()).getRegion_name());

			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID, 
					m_SCDistricts.get(spSCDistrict.getSelectedItemPosition()).getDistrictValue());
			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID_DISPLAY, 
					m_SCDistricts.get(spSCDistrict.getSelectedItemPosition()).getDistrictName());

			contentValues.put(DataBaseHelper.KEY_TALUKA_ID, 
					m_SCTaluka.get(spSCTaluka.getSelectedItemPosition()).getTaluka_values());
			contentValues.put(DataBaseHelper.KEY_TALUKA_ID_DISPLAY, 
					m_SCTaluka.get(spSCTaluka.getSelectedItemPosition()).getTaluka_name());

			contentValues.put(DataBaseHelper.KEY_RELEVANT_SECTOR, 
					m_SCRelevantSector.get(spSCRelevantSector.getSelectedItemPosition()).getREF_ID());
			contentValues.put(DataBaseHelper.KEY_RELEVANT_SECTOR_DISPLAY, 
					m_SCRelevantSector.get(spSCRelevantSector.getSelectedItemPosition()).getSECTOR_NAME());

			contentValues.put(DataBaseHelper.KEY_MODULE_SKILL, 
					m_SCModuleskill.get(spSCModuleSkill.getSelectedItemPosition()).getSKILL_ID());			
			contentValues.put(DataBaseHelper.KEY_MODULE_SKILL_DISPLAY, 
					m_SCModuleskill.get(spSCModuleSkill.getSelectedItemPosition()).getSKILL_NAME());			

			db.insert(DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS, null, contentValues);

		} else if(positionCandidateCategory==3) {
			//			Switch ch_app_ApplicantType;
			//			EditText txtappSeatNumber,txtJoiningDate,txtCompletionDate,txtRegistrationNumber,txtDateofRegistration;
			//			Spinner spAPDesignatedTrade, spAPInstitute;
			//
			//			private ArrayList<String> m_APDesignatedTradeDisplay = new ArrayList<String>();
			//			private ArrayList<APDesTrade> m_APDesignatedTrade = new ArrayList<APDesTrade>();
			//			private ArrayList<String> m_APInstituteDisplay = new ArrayList<String>();
			//			private ArrayList<APInstitute> m_APInstitute = new ArrayList<APInstitute>();

			contentValues.put(DataBaseHelper.KEY_DESIGNATION, 
					m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_name());

			String str_app_ApplicantType = ch_app_ApplicantType.isChecked() ? getResources().getString(R.string.app_Fresher): getResources().getString(R.string.app_ITI_Pass);
			contentValues.put(DataBaseHelper.KEY_APP_TYPE, str_app_ApplicantType);

			contentValues.put(DataBaseHelper.KEY_SEAT_NO, 
					txtappSeatNumber.getText().toString());

			contentValues.put(DataBaseHelper.KEY_JOINING_DATE, 
					txtJoiningDate.getText().toString());

			contentValues.put(DataBaseHelper.KEY_COMPLETION_DATE, 
					txtCompletionDate.getText().toString());

			contentValues.put(DataBaseHelper.KEY_REG_NO, 
					txtRegistrationNumber.getText().toString());

			contentValues.put(DataBaseHelper.KEY_REG_DATE, 
					txtDateofRegistration.getText().toString());

			contentValues.put(DataBaseHelper.KEY_TRADE_ID_REG, 
								m_APDesignatedTrade.get(spAPDesignatedTrade.getSelectedItemPosition()).getTRADE_ID());
			contentValues.put(DataBaseHelper.KEY_TRADE_ID_DISPLAY, 
					m_APDesignatedTrade.get(spAPDesignatedTrade.getSelectedItemPosition()).getTRADE_NAME_E());
			
			

			contentValues.put(DataBaseHelper.KEY_ITI_ID, 
					m_APInstitute.get(spAPInstitute.getSelectedItemPosition()).getITI_ID());
			contentValues.put(DataBaseHelper.KEY_ITI_ID_DISPLAY, 
					m_APInstitute.get(spAPInstitute.getSelectedItemPosition()).getITI_NAME_E());

			db.insert(DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS, null, contentValues);			
		}
	}

}
