package com.registrationmanagementsystem.model;

public class IkvkCenter {
	String ESTABLISHMENT_NO;
	String ESTABLISHMENT_CODE;
	String ESTABLISHMENT_NAME_E;
	
	public String getESTABLISHMENT_NO() {
		return ESTABLISHMENT_NO;
	}
	public void setESTABLISHMENT_NO(String eSTABLISHMENT_NO) {
		ESTABLISHMENT_NO = eSTABLISHMENT_NO;
	}
	public String getESTABLISHMENT_CODE() {
		return ESTABLISHMENT_CODE;
	}
	public void setESTABLISHMENT_CODE(String eSTABLISHMENT_CODE) {
		ESTABLISHMENT_CODE = eSTABLISHMENT_CODE;
	}
	public String getESTABLISHMENT_NAME_E() {
		return ESTABLISHMENT_NAME_E;
	}
	public void setESTABLISHMENT_NAME_E(String eSTABLISHMENT_NAME_E) {
		ESTABLISHMENT_NAME_E = eSTABLISHMENT_NAME_E;
	}
}
