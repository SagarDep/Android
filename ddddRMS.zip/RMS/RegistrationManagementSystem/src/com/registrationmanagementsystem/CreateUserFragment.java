package com.registrationmanagementsystem;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;

import android.content.ContentValues;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class CreateUserFragment extends Fragment{

	String TAG = CreateUserFragment.class.getName();

	EditText etxEmail, etxnName, etxPass, etxCpass;
	Button btnSubmit;

	DataBaseHelper mDbHelper;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View m_rootView = inflater.inflate(R.layout.activity_createuser,
				container, false);

		mDbHelper = DataBaseHelper.getInstance(getActivity());

		etxEmail = (EditText) m_rootView.findViewById(R.id.txtEamil);
		etxnName = (EditText) m_rootView.findViewById(R.id.txtName);
		etxPass = (EditText) m_rootView.findViewById(R.id.txtNewPassword);
		etxCpass = (EditText) m_rootView.findViewById(R.id.txtConfirmPassword);

		btnSubmit = (Button) m_rootView.findViewById(R.id.btnChange);

		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				insertValidUser();
			}
		});

		return m_rootView;
	}

	private void insertValidUser() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage + getResources().getString(R.string.err_msg_signup_user_eamil);
			isInsertInDb = false;			
		} 
		if(etxnName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage + getResources().getString(R.string.err_msg_signup_user_name);
			isInsertInDb = false;
		}
		if(etxPass.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage + getResources().getString(R.string.err_msg_signup_user_pass);
			isInsertInDb = false;
		}
		if(etxCpass.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage + getResources().getString(R.string.err_msg_signup_user_cpass);
			isInsertInDb = false;
		} 
		if(!etxPass.getText().toString().equalsIgnoreCase(etxCpass.getText().toString())) {
			errorMessage = errorMessage + getResources().getString(R.string.err_msg_signup_user_wrong_pass);
			etxPass.setText("");
			etxCpass.setText("");
			isInsertInDb = false;
		}
		if (isInsertInDb) {
			Log.i(TAG, "Insert in DB");

			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// Insert in db
			ContentValues contentValues = new ContentValues();
			contentValues.put(DataBaseHelper.KEY_rca_user_email, Global.USER_EMAIL);

			/*
			 * Mandatory fields
			 */
			contentValues.put(DataBaseHelper.KEY_uc_user_email, etxEmail.getText().toString());
			contentValues.put(DataBaseHelper.KEY_uc_user_pass, etxPass.getText().toString());
			contentValues.put(DataBaseHelper.KEY_uc_user_name, etxnName.getText().toString());

			try {
				db.insertOrThrow(DataBaseHelper.TABLE_user_credentails, null, contentValues);

				Global.showAlertDialog(getActivity(), "Sign Up :", 
						getResources().getString(R.string.err_msg_signup_user_created), false);
			} catch (SQLiteException e) {
				// TODO: handle exception
				Log.e(TAG, "SQLException");
				Log.e(TAG, "e.getMessage(); = " + e.getMessage());
				Global.showAlertDialog(getActivity(), "Sign Up :", 
						getResources().getString(R.string.err_msg_signup_double_user), false);  
			} catch (Exception e) {
				Log.e(TAG, "Exception");
				e.printStackTrace();
			}
			etxEmail.setText("");
			etxnName.setText("");
			etxPass.setText("");
			etxCpass.setText("");
		} else {
			Global.showAlertDialog(getActivity(), "Sign Up :", errorMessage, false);
		}

	}
}
