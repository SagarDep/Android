package com.cr2cleaner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class SplashActivity extends Activity {

	protected boolean _active = true;
	protected int _splashTime = 3000; // time to display the splash screen in ms


	String android_id ;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.splash_screen);


		Thread splashTread = new Thread() {
			@Override
			public void run() {
				try {
					int waited = 0;
					while (_active && (waited < _splashTime)) {
						sleep(100);
						if (_active) {
							waited += 100;
							
						}
					}
				} catch (Exception e) {

				} finally {
					Intent m_intent = new Intent(SplashActivity.this,CleanerActivity.class);
					startActivity(m_intent); 
					finish();
						
					}
					
			};
		};
		splashTread.start();
}

}
