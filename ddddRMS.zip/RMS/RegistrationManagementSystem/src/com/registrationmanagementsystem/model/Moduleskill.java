package com.registrationmanagementsystem.model;

public class Moduleskill {

	String SECTOR_ID;
	String SKILL_ID;
	String SKILL_CODE;
	String SKILL_NAME;
	
	public String getSECTOR_ID() {
		return SECTOR_ID;
	}
	public void setSECTOR_ID(String sECTOR_ID) {
		SECTOR_ID = sECTOR_ID;
	}
	public String getSKILL_CODE() {
		return SKILL_CODE;
	}
	public void setSKILL_CODE(String sKILL_CODE) {
		SKILL_CODE = sKILL_CODE;
	}
	public String getSKILL_NAME() {
		return SKILL_NAME;
	}
	public void setSKILL_NAME(String sKILL_NAME) {
		SKILL_NAME = sKILL_NAME;
	}
	
	public String getSKILL_ID() {
		return SKILL_ID;
	}
	public void setSKILL_ID(String sKILL_ID) {
		SKILL_ID = sKILL_ID;
	}
}
