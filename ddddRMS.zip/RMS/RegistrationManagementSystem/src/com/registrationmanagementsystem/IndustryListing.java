package com.registrationmanagementsystem;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.MenuItem;
import android.widget.ListView;

import com.registrationmanagementsystem.adapter.IndustryAdapter;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.IndustryDetails;

public class IndustryListing extends ActionBarActivity {

	DataBaseHelper mDbHelper;
	
	ListView mIndustryListView;
	IndustryAdapter mIndustryAdapter;
	ArrayList<IndustryDetails> mInsutryArrayList = new ArrayList<IndustryDetails>();
	
	Context context;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.industry_listing);
		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());
		
		context = this;
		// get action bar
		ActionBar actionBar = getSupportActionBar();

		// Enabling Up / Back navigation
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		mIndustryListView = (ListView) findViewById(R.id.industrylist);
		
		new IndustryListingAsyncTask().execute();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	public class IndustryListingAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_register_industry);
			if (table_length > 0) {
				System.out
						.println("TESTDB: IndustryListingAsyncTask if - read from table table_length = "
								+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_register_industry, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IndustryDetails industryDetails = new IndustryDetails();
					industryDetails.setIndustryName(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_org_name)));
					industryDetails.setId((result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_industry_id))));
					mInsutryArrayList.add(industryDetails);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			mIndustryAdapter = new IndustryAdapter(context, mInsutryArrayList);
			mIndustryListView.setAdapter(mIndustryAdapter);
		}
	}


}
