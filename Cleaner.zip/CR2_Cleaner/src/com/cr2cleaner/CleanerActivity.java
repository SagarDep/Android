package com.cr2cleaner;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.preference.PreferenceManager;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.SearchView;
import android.text.format.Formatter;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AnimationUtils;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.settings.applications.LinearColorBar;
import com.cr2cleaner.R.color;
import com.cr2cleaner.adapter.AppsListAdapter;
import com.cr2cleaner.circularprogressbar.CircularProgressBar;
import com.cr2cleaner.circularprogressbar.CircularProgressBar.ProgressAnimationListener;
import com.cr2cleaner.helper.CacheManager;


public class CleanerActivity extends ActionBarActivity implements
SharedPreferences.OnSharedPreferenceChangeListener, CacheManager.OnActionListener {

	private LinearColorBar mColorBar;
	private TextView mUsedStorageText;
	private TextView mFreeStorageText;
	private long mLastUsedStorage, mLastFreeStorage;
	private AppsListAdapter mAppsListAdapter = null;
	private CacheManager mCacheManager = null;
	private ListView mListView;
	private TextView mEmptyView;
	private SharedPreferences mSharedPreferences;
	private SharedPreferences.Editor mSharedPreferencesEditor;
	private boolean mUpdateChart = true;
	private SearchView mSearchView;
	private ProgressDialog mProgressDialog;
	private View mProgressBar;
	private TextView mProgressBarText;

	private boolean mAlreadyScanned = false;
	private boolean mAlreadyCleaned = false;

	private TextView tvRam,tvCPU,tvInternal,tvExternal;

	private String[] mMonth = new String[] {
			"Jan", "Feb" , "Mar", "Apr", "May", "Jun",
			"Jul", "Aug" , "Sep", "Oct", "Nov", "Dec"
	};


	/** The chart view that displays the data. */
	private GraphicalView mChartView;
	Context m_context;
	ProgressBar pgbrRam,pgbrCpu,pgbrInternal,pgbrbattery;
	/** The main series that will include all the data. */
	private CategorySeries mSeries = new CategorySeries("");
	/** The main renderer for the main dataset. */
	private DefaultRenderer mRenderer = new DefaultRenderer();

	RelativeLayout layout;

	CircularProgressBar c1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.cleaner_activity);
		m_context = getApplicationContext();
		layout = (RelativeLayout) findViewById(R.id.rlMainContainer);

		/*	   if (mChartView == null) {
			   RelativeLayout layout = (RelativeLayout) findViewById(R.id.rlMainContainer);
			      mChartView = ChartFactory.getPieChartView(this, mSeries, mRenderer);
			      mRenderer.setClickEnabled(true);
			      mChartView.setOnClickListener(new View.OnClickListener() {
			        @Override
			        public void onClick(View v) {
			          SeriesSelection seriesSelection = mChartView.getCurrentSeriesAndPoint();
			          if (seriesSelection == null) {
//			            Toast.makeText(PieChartBuilder.this, "No chart element selected", Toast.LENGTH_SHORT)
//			                .show();
			          } else {
			            for (int i = 0; i < mSeries.getItemCount(); i++) {
			              mRenderer.getSeriesRendererAt(i).setHighlighted(i == seriesSelection.getPointIndex());
			            }
			            mChartView.repaint();
			            Toast.makeText(
			                PieChartBuilder.this,
			                "Chart data point index " + seriesSelection.getPointIndex() + " selected"
			                    + " point value=" + seriesSelection.getValue(), Toast.LENGTH_SHORT).show();
			          }
			        }
			      });
			      layout.addView(mChartView, new LayoutParams(LayoutParams.FILL_PARENT,
			          LayoutParams.FILL_PARENT));
			    } else {
			      mChartView.repaint();
			    }*/
		mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
		mSharedPreferencesEditor = mSharedPreferences.edit();

		mColorBar = (LinearColorBar)findViewById(R.id.storage_color_bar);
		mUsedStorageText = (TextView)findViewById(R.id.usedStorageText);
		mFreeStorageText = (TextView)findViewById(R.id.freeStorageText);

		mEmptyView = (TextView)findViewById(android.R.id.empty);

		mListView = (ListView)findViewById(android.R.id.list);
		mListView.setEmptyView(mEmptyView);
		mAppsListAdapter = new AppsListAdapter(this, mSharedPreferences);
		mListView.setAdapter(mAppsListAdapter);


		tvCPU  =(TextView)findViewById(R.id.tvCPU);
		tvRam  =(TextView)findViewById(R.id.tvRam);
		tvInternal=(TextView)findViewById(R.id.tvInternal);
		tvExternal=(TextView)findViewById(R.id.tvExternal);

		pgbrRam = (ProgressBar)findViewById(R.id.pgbr_ram);
		pgbrCpu= (ProgressBar)findViewById(R.id.pgbr_cpu);
		pgbrInternal= (ProgressBar)findViewById(R.id.pgbr_internal);
		pgbrbattery= (ProgressBar)findViewById(R.id.pgbr_battery);


		Resources res = getResources();
		Rect bounds = pgbrbattery.getProgressDrawable().getBounds();

		pgbrbattery.setProgressDrawable(res.getDrawable(R.drawable.progress));
		pgbrbattery.getProgressDrawable().setBounds(bounds);
		pgbrbattery.setProgress(getBatteryPercentage());

		//		openChart();	
		mAppsListAdapter.registerDataSetObserver(new DataSetObserver() {
			@Override
			public void onChanged() {
				if(mUpdateChart)
					updateStorageUsage();
				mUpdateChart = true;

				mListView.invalidateViews();
				mEmptyView.invalidate();
			}
		});

		updateStorageUsage();


		/*

		ActivityManager actManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
		MemoryInfo memInfo = new ActivityManager.MemoryInfo();
		actManager.getMemoryInfo(memInfo);
		long totalMemory = memInfo.totalMem / 1048576L;*/


		/*	long freeBytesInternal = new File(m_context.getFilesDir().getAbsoluteFile().toString()).getFreeSpace();*/
		//		long freeBytesExternal = new File(getExternalFilesDir(null).toString()).getFreeSpace();


		/*		tvInternal.setText("INTERNAL STORAGE :"+String.valueOf(freeBytesInternal));*/

		//		tvExternal.setText(String.valueOf(freeBytesExternal));
		//		System.out.println(">>> total memory"+totalMemory);
		//		tvRam.setText(String.valueOf(totalMemory));

		//		tvRam.setTypeface(Typeface.createFromAsset(m_context.getAssets(), "DS-DIGIB.TTF"));
		/*tvCPU.setText("CPU :"+readUsage() + "%");*/

		/*		tvRam.setText("RAM :"+getTotalMemory());*/

		mProgressBar = findViewById(R.id.progressBar);
		c1 = (CircularProgressBar) findViewById(R.id.circularprogressbar1);
		mProgressBarText = (TextView)findViewById(R.id.progressBarText);

		mProgressDialog = new ProgressDialog(this);
		mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		mProgressDialog.setCanceledOnTouchOutside(false);
		mProgressDialog.setTitle(R.string.cleaning_cache);
		mProgressDialog.setMessage(getString(R.string.cleaning_in_progress));
		mProgressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
			@Override
			public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
				return true;
			}
		});

		mCacheManager = new CacheManager(getPackageManager());
		mCacheManager.setOnActionListener(this);
		mCacheManager.scanCache();
	}

	/**
	 * getBatteryPercentage()
	 */

	private int getBatteryPercentage() {


		BroadcastReceiver batteryLevel = new BroadcastReceiver() {

			public void onReceive(Context context, Intent intent) {
				context.unregisterReceiver(this);
				int currentLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
				int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
				int level= -1;
				if (currentLevel >= 0 && scale > 0) {
					level = (currentLevel * 100) / scale;
				}
				tvExternal.setText("BATTERY : "+level + "%");
			}
		};

		IntentFilter batteryLevelFilter = new IntentFilter(
				Intent.ACTION_BATTERY_CHANGED);
		registerReceiver(batteryLevel, batteryLevelFilter);
		return 0;

	}


	private void openChart(){    	


		// Pie Chart Section Names
		String[] code = new String[] {
				"Eclair & Older", "Froyo", "Gingerbread", "Honeycomb",
				"IceCream Sandwich", "Jelly Bean" 
		};    	

		// Pie Chart Section Value
		double[] distribution = { 3.9, 12.9, 55.8, 1.9, 23.7, 1.8 } ;

		// Color of each Pie Chart Sections
		int[] colors = { Color.BLUE, Color.MAGENTA, Color.GREEN, Color.CYAN, Color.RED,
				Color.YELLOW };

		// Instantiating CategorySeries to plot Pie Chart    	
		CategorySeries distributionSeries = new CategorySeries(" Android version distribution as on October 1, 2012");
		for(int i=0 ;i < distribution.length;i++){
			// Adding a slice with its values and name to the Pie Chart
			distributionSeries.add(code[i], distribution[i]);
		}   

		// Instantiating a renderer for the Pie Chart
		DefaultRenderer defaultRenderer  = new DefaultRenderer();    	
		for(int i = 0 ;i<distribution.length;i++){    		
			SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();    	
			seriesRenderer.setColor(colors[i]);
			seriesRenderer.setDisplayChartValues(true);
			// Adding a renderer for a slice
			defaultRenderer.addSeriesRenderer(seriesRenderer);
		}

		defaultRenderer.setChartTitle("Android version distribution as on October 1, 2012 ");
		defaultRenderer.setChartTitleTextSize(20);
		defaultRenderer.setZoomButtonsVisible(false);    	    		

		// Creating an intent to plot bar chart using dataset and multipleRenderer    	
		/*	Intent intent = ChartFactory.getPieChartIntent(getBaseContext(), distributionSeries , defaultRenderer, "AChartEnginePieChartDemo");    	

	    	// Start Activity
	    	startActivity(intent);
		 */
		mSeries = 	distributionSeries ;
		mRenderer = defaultRenderer;
		mChartView = ChartFactory.getPieChartView(this, mSeries, mRenderer);
		mRenderer.setClickEnabled(true);
		layout.addView(mChartView, new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT));

	}

	/**
	 * BATTERY MANAGER
	 */

	public static String isPhonePluggedIn(Context context) {
		boolean charging = false;
		String result = "No";
		final Intent batteryIntent = context.registerReceiver(null,
				new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		int status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
		boolean batteryCharge = status == BatteryManager.BATTERY_STATUS_CHARGING;

		int chargePlug = batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
		boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
		boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;

		if (batteryCharge)
			charging = true;
		if (usbCharge)
			charging = true;
		if (acCharge)
			charging = true;

		if (charging){
			result = "Yes";

		}
		return result;
	}
	/**
	 * 
	 * Get Total Memory
	 */
	public long getTotalMemory() {  

		String str1 = "/proc/meminfo";
		String str2;        
		String[] arrayOfString;
		long initial_memory = 0;
		try {
			FileReader localFileReader = new FileReader(str1);
			BufferedReader localBufferedReader = new BufferedReader(    localFileReader, 8192);
			str2 = localBufferedReader.readLine();//meminfo
			arrayOfString = str2.split("\\s+");
			for (String num : arrayOfString) {
				//	    Log.i(str2, num + "\t");
			}
			//total Memory
			initial_memory = Integer.valueOf(arrayOfString[1]).intValue() * 1024;   
			localBufferedReader.close();
			return initial_memory;
		} 
		catch (IOException e) 
		{       
			return -1;
		}
	}  


	/**
	 * CPU Usage percentage
	 * @return
	 */
	private float readUsage() {
		try {
			RandomAccessFile reader = new RandomAccessFile("/proc/stat", "r");
			String load = reader.readLine();

			String[] toks = load.split(" ");

			long idle1 = Long.parseLong(toks[4]);
			long cpu1 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[5])
					+ Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);

			try {
				Thread.sleep(360);
			} catch (Exception e) {}

			reader.seek(0);
			load = reader.readLine();
			reader.close();

			toks = load.split(" ");

			long idle2 = Long.parseLong(toks[4]);
			long cpu2 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[5])
					+ Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);

			return (float)(cpu2 - cpu1) / ((cpu2 + idle2) - (cpu1 + idle1));

		} catch (IOException ex) {
			ex.printStackTrace();
		}

		return 0;
	} 
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_menu, menu);

		MenuItem searchItem = menu.findItem(R.id.action_search);
		mSearchView = ((SearchView)MenuItemCompat.getActionView(searchItem));
		mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			@Override
			public boolean onQueryTextSubmit(String query) {
				mSearchView.clearFocus();
				return true;
			}

			@Override
			public boolean onQueryTextChange(String newText) {
				mUpdateChart = false;
				mAppsListAdapter.filterAppsByName(newText);
				return true;
			}
		});
		MenuItemCompat.setOnActionExpandListener(searchItem, new MenuItemCompat.OnActionExpandListener() {
			@Override
			public boolean onMenuItemActionExpand(MenuItem item) {
				mEmptyView.setText(R.string.no_such_app);
				return true;
			}

			@Override
			public boolean onMenuItemActionCollapse(MenuItem item) {
				mAppsListAdapter.clearFilter();
				mEmptyView.setText(R.string.empty_cache);
				return true;
			}
		});

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.action_clean:
			if(!mCacheManager.isScanning() && !mCacheManager.isCleaning() &&
					mAppsListAdapter.getTotalCacheSize() > 0) {
				mAlreadyCleaned = false;
				mCacheManager.cleanCache(mAppsListAdapter.getTotalCacheSize());
			}
			return true;

		case R.id.action_refresh:
			if(!mCacheManager.isScanning() && !mCacheManager.isCleaning())
				mCacheManager.scanCache();
			c1.setSubTitle("");
			return true;

		case R.id.action_settings:
			startActivity(new Intent(this, SettingsActivity.class));
			return true;

		case R.id.action_sort_by_app_name:
			setSortBy(AppsListAdapter.SORT_BY_APP_NAME);
			return true;

		case R.id.action_sort_by_cache_size:
			setSortBy(AppsListAdapter.SORT_BY_CACHE_SIZE);
			return true;
		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onStart() {
		super.onStart();

		if(mCacheManager.isScanning() && !isProgressBarVisible())
			showProgressBar(true);
		else if(!mCacheManager.isScanning() && isProgressBarVisible())
			showProgressBar(false);

		if(mCacheManager.isCleaning() && !mProgressDialog.isShowing())
			mProgressDialog.show();

		mSharedPreferences.registerOnSharedPreferenceChangeListener(this);
	}

	@Override
	protected void onStop() {
		if(mProgressDialog.isShowing())
			mProgressDialog.dismiss();

		mSharedPreferences.unregisterOnSharedPreferenceChangeListener(this);

		super.onStop();
	}

	@Override
	public void onConfigurationChanged (Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	private void updateStorageUsage() {
		long freeStorage, appStorage, totalStorage;

		StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());

		totalStorage = (long)stat.getBlockCount() * (long)stat.getBlockSize();
		freeStorage = (long)stat.getAvailableBlocks() * (long)stat.getBlockSize();

		appStorage = mAppsListAdapter.getTotalCacheSize();

		if (totalStorage > 0) {
			mColorBar.setRatios((totalStorage - freeStorage - appStorage) / (float)totalStorage,
					appStorage / (float)totalStorage, freeStorage / (float) totalStorage);
			long usedStorage = totalStorage - freeStorage;
			if (mLastUsedStorage != usedStorage) {
				mLastUsedStorage = usedStorage;
				String sizeStr = Formatter.formatShortFileSize(this, usedStorage);
				mUsedStorageText.setText(getString(R.string.service_foreground_processes, sizeStr));
			}
			if (mLastFreeStorage != freeStorage) {
				mLastFreeStorage = freeStorage;
				String sizeStr = Formatter.formatShortFileSize(this, freeStorage);
				mFreeStorageText.setText(getString(R.string.service_background_processes, sizeStr));
			}
		} else {
			mColorBar.setRatios(0, 0, 0);
			if (mLastUsedStorage != -1) {
				mLastUsedStorage = -1;
				mUsedStorageText.setText("");
			}
			if (mLastFreeStorage != -1) {
				mLastFreeStorage = -1;
				mFreeStorageText.setText("");
			}
		}
	}

	private void setSortBy(int sortBy) {
		mSharedPreferencesEditor.putInt(getString(R.string.sort_by_key), sortBy);
		mSharedPreferencesEditor.commit();
		mAppsListAdapter.filterAppsByName(mSearchView.getQuery().toString());
	}

	private boolean isProgressBarVisible() {
		return mProgressBar.getVisibility() == View.VISIBLE;
	}

	private void showProgressBar(boolean show) {
		if(show) {
			mProgressBar.setVisibility(View.VISIBLE);
		}
		else {
			mProgressBar.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_out));
			mProgressBar.setVisibility(View.GONE);

		}
	}

	private void setProgressBarProgress(int current, int max) {
		mProgressBarText.setTextColor(getResources().getColor(color.color_green));
		mProgressBarText.setTypeface(null, Typeface.BOLD);
		mProgressBarText.setText(getString(R.string.scanning) + " " + current + " / " + max + " Applications");

		float fPercent = (current * 100) / max;
		int iPercent = Math.round(fPercent);
		String tmp = String.valueOf(iPercent) +"%"; 
		c1.setTitle(tmp);
		c1.setProgress(iPercent);
	}

	@Override
	public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
		if(key.equals(getString(R.string.sort_by_key))) {
			mAppsListAdapter.sort();
			if(mSearchView.isShown())
				mAppsListAdapter.filterAppsByName(mSearchView.getQuery().toString());
			mAppsListAdapter.notifyDataSetChanged();
		}
	}

	@Override
	public void onScanStarted(int appsCount) {
		if(mProgressDialog.isShowing())
			mProgressDialog.dismiss();

		setProgressBarProgress(0, appsCount);


		showProgressBar(true);

	}

	@Override
	public void onScanProgressUpdated(int current, int max) {
		setProgressBarProgress(current, max);


	}

	@Override
	public void onScanCompleted(List<AppsListItem> apps) {
		mAppsListAdapter.setItems(apps);
		if(mSearchView != null) {
			if(mSearchView.isShown()) {
				mAppsListAdapter.filterAppsByName(mSearchView.getQuery().toString());
				mUpdateChart = false;
			}
		}
		mAppsListAdapter.notifyDataSetChanged();

		showProgressBar(false);
		c1.setSubTitle("Done");

		if(!mAlreadyScanned) {
			mAlreadyScanned = true;

			if(mSharedPreferences.getBoolean(getString(R.string.clean_on_app_startup_key), false)) {
				mAlreadyCleaned = true;
				mCacheManager.cleanCache(mAppsListAdapter.getTotalCacheSize());
			}
		}
	}

	@Override
	public void onCleanStarted() {
		if(isProgressBarVisible())
			showProgressBar(false);

		c1.setSubTitle("Done");
		
		if(!isFinishing()) {
			mProgressDialog.show();
		}
	}


	@Override
	public void onCleanCompleted(long cacheSize) {
		mAppsListAdapter.setItems(new ArrayList<AppsListItem>());
		mAppsListAdapter.notifyDataSetChanged();

		if(mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}

		Toast.makeText(this, getString(R.string.cleaned) + " (" +
				Formatter.formatShortFileSize(this, cacheSize) + ")", Toast.LENGTH_LONG).show();

		if(!mAlreadyCleaned) {
			if(mSharedPreferences.getBoolean(getString(R.string.exit_after_clean_key), false)) {
				finish();
			}
		}
	}
}
