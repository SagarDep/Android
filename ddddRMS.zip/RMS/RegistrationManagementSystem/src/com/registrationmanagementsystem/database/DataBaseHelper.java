package com.registrationmanagementsystem.database;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;
import android.util.Log;

public class DataBaseHelper extends SQLiteOpenHelper {

	// The Android's default system path of your application database.
	// private static String DB_PATH =
	// "/data/data/com.webopac.tabsswipe/databases/";
	private static String DB_PATH = "/data/data/com.registrationmanagementsystem/databases/";
	// private static String DB_PATH =
	// "context.getApplicationInfo().dataDir/databases/";

	// Data Base Name.
	private static final String DATABASE_NAME = "RMS.sqlite";
	// Data Base Version.
	private static final int DATABASE_VERSION = 1;

	// Table Names candidate_category DataBase.
	public static final String TABLE_candidate_category = "candidate_category";
	public static final String KEY_category_name = "category_name";
	public static final String KEY_category_value = "category_value";

	// Table Names District DataBase.
	public static final String TABLE_District = "District";
	public static final String KEY_district_name = "district_name";
	public static final String KEY_district_value = "district_value";
	public static final String KEY_district_country_id = "country_id";
	public static final String KEY_district_state_id = "state_id";
	public static final String KEY_district_region_id = "region_id";

	// Table Names State DataBase.
	public static final String TABLE_State = "State";
	public static final String KEY_state_name = "state_name";
	public static final String KEY_state_value = "state_value";
	public static final String KEY_state_country_id = "country_id";
	public static final String KEY_state_is_deleted = "is_deleted";

	public static final String TABLE_Region = "Region";
	public static final String KEY_region_name = "region_name";
	public static final String KEY_region_value = "region_value";

	public static final String TABLE_Sector = "Sector";
	public static final String KEY_sector_name = "sector_name";
	public static final String KEY_sector_value = "sector_value";

	// Table Names State DataBase.
	public static final String TABLE_Taluka = "Taluka";
	public static final String KEY_taluka_id = "taluka_id";
	public static final String KEY_taluka_country_id = "country_id";
	public static final String KEY_taluka_state_id = "state_id";
	public static final String KEY_taluka_region_id = "region_id";
	public static final String KEY_taluka_district_id = "district_id";
	public static final String KEY_taluka_taluka_name_e = "taluka_name_e";
	public static final String KEY_taluka_taluka_name_r = "taluka_name_r";
	public static final String KEY_taluka_is_deleted = "is_deleted";

	// Table Names Gender DataBase.
	public static final String TABLE_Gender = "Gender";
	public static final String KEY_gender_name = "gender_name";
	public static final String KEY_gender_value = "gender_value";

	// Table Names Caste DataBase.
	public static final String TABLE_Caste = "Caste";
	public static final String KEY_caste_name = "caste_name";
	public static final String KEY_caste_value = "caste_value";

	// Table Names est_type DataBase.
	public static final String TABLE_est_type = "est_type";
	public static final String KEY_est_name = "est_name";
	public static final String KEY_est_value = "est_value";


	// Table Names Designation DataBase.
	public static final String TABLE_Designation = "Designation";
	public static final String KEY_designation_name = "designation_name";
	public static final String KEY_designation_value = "designation_value";

	// Table Names candidate_category DataBase.
	public static final String TABLE_register_candidate = "register_candidate";
	public static final String KEY_rca_register_user_id = "_id";
	public static final String KEY_rca_user_email = "user_email";
	public static final String KEY_rca_candidate_category = "candidate_category";
	public static final String KEY_rca_first_name = "first_name";
	public static final String KEY_rca_middle_name = "middle_name";
	public static final String KEY_rca_last_name = "last_name";
	public static final String KEY_rca_fmh_name = "fmh_name";
	public static final String KEY_rca_address = "address";
	public static final String KEY_rca_district = "district";
	public static final String KEY_rca_state = "state";
	public static final String KEY_rca_city = "city";
	public static final String KEY_rca_taluka = "taluka";
	public static final String KEY_rca_pincode = "pincode";
	public static final String KEY_rca_mobileno = "mobileno";
	public static final String KEY_rca_lline = "lline";
	public static final String KEY_rca_gender = "gender";
	public static final String KEY_rca_caste = "caste";
	public static final String KEY_rca_chk_ph = "chk_ph";
	public static final String KEY_rca_percentage_ph = "percentage_ph";
	public static final String KEY_rca_chk_exarmy = "chk_exarmy";
	public static final String KEY_rca_chk_widow = "chk_widow";
	public static final String KEY_rca_chk_divorcee = "chk_divorcee";
	public static final String KEY_rca_chk_minority = "chk_minority";
	public static final String KEY_rca_chk_bpl = "chk_bpl";
	public static final String KEY_rca_email = "email";
	public static final String KEY_rca_birthday = "birthday";
	public static final String KEY_rca_image_path = "image_path";
	public static final String KEY_rca_lattitude = "lattitude";
	public static final String KEY_rca_longitude = "longitude";
	public static final String KEY_rca_designation_name = "designation_name";
	public static final String KEY_rca_designation_value = "designation_value";
	public static final String KEY_rca_table_name = "table_name";

	// Table Names register_industry DataBase.
	public static final String TABLE_register_industry = "register_industry";
	public static final String KEY_ri_industry_id = "id";
	public static final String KEY_ri_user_email = "user_email";
	public static final String KEY_ri_org_code = "org_code";
	public static final String KEY_ri_org_name = "org_name";
	public static final String KEY_ri_state_name = "state_name";
	public static final String KEY_ri_state_value = "state_value";
	public static final String KEY_ri_district_name = "district_name";
	public static final String KEY_ri_district_value = "district_value";
	public static final String KEY_ri_region_name = "region_name";
	public static final String KEY_ri_region_value = "region_value";
	public static final String KEY_ri_taluka_name = "taluka_name";
	public static final String KEY_ri_taluka_value = "taluka_value";
	public static final String KEY_ri_address = "address";
	public static final String KEY_ri_city = "city";
	public static final String KEY_ri_pincode = "pincode";
	public static final String KEY_ri_mobileno = "mobileno";
	public static final String KEY_ri_lline = "lline";
	public static final String KEY_ri_email = "email";
	public static final String KEY_ri_website = "website";
	public static final String KEY_ri_sector_name = "sector_name";
	public static final String KEY_ri_sector_value = "sector_value";
	public static final String KEY_ri_nature_product = "nature_product";
	public static final String KEY_ri_establishment_name = "establishment_name";
	public static final String KEY_ri_establishment_value = "establishment_value";
	public static final String KEY_ri_active = "active";
	public static final String KEY_ri_apprentice_act = "apprentice_act";
	public static final String KEY_ri_contact_name = "contact_name";
	public static final String KEY_ri_contact_mobile = "contact_mobile";
	public static final String KEY_ri_contact_des_name = "contact_des_name";
	public static final String KEY_ri_contact_des_val = "contact_des_val";
	public static final String KEY_ri_contact_email = "contact_email";
	public static final String KEY_ri_total_compHelpers = "total_cmp_helpers";
	public static final String KEY_ri_total_cmp_cntct_worker = "total_cmp_cntct_worker";
	public static final String KEY_ri_lbr_cntct_name = "lbr_cntct_name";
	public static final String KEY_ri_lbr_cntct_add= "lbr_cntct_add";
	public static final String KEY_ri_total_manager = "total_manager";
	public static final String KEY_ri_total_supervisor = "total_supervisor";
	public static final String KEY_ri_skilled_worker = "skilled_worker";
	public static final String KEY_ri_semi_skilled_worker = "semi_skilled_worker";
	public static final String KEY_ri_unskilled_worker = "unskilled_worker";
	public static final String KEY_ri_licence_lbr_cntct = "licence_lbr_cntct";
	public static final String KEY_ri_agree_skill_certi = "agree_skill_certi";
	public static final String KEY_ri_total_no_req = "total_no_req";
	public static final String KEY_ri_image_path = "image_path";
	public static final String KEY_ri_designation_name ="designation_name";
	public static final String KEY_ri_designation_value = "designation_value";



	// Table Names user_credentails DataBase.
	public static final String TABLE_user_credentails = "user_credentails";
	public static final String KEY_uc_user_email = "user_email";
	public static final String KEY_uc_user_pass = "user_pass";
	public static final String KEY_uc_user_name = "user_name";

	// Table Names admin_credentials DataBase.
	public static final String TABLE_admin_credentials = "admin_credentials";
	public static final String KEY_ac_admin_id = "admin_id";
	public static final String KEY_ac_admin_email = "admin_email";
	public static final String KEY_ac_admin_pass = "admin_pass";

	// Table Names TABLE_APPLICANT_REGS_OTHER_DETAILS DataBase.
	public static final String TABLE_APPLICANT_REGS_OTHER_DETAILS = "APPLICANT_REGS_OTHER_DETAILS";
	public static final String KEY_REF_ID                      ="REF_ID";                    
	public static final String KEY_APPLICANT_ID                ="APPLICANT_ID";               
	public static final String KEY_COURSE_ID                   ="COURSE_ID";                  
	public static final String KEY_IKVK_CENTER_ID              ="IKVK_CENTER_ID";             
	public static final String KEY_SHIFT                       ="SHIFT";                      
	public static final String KEY_EST_NAME                    ="EST_NAME";                   
	public static final String KEY_ADDRESS                     ="ADDRESS";                    
	public static final String KEY_REGION_ID                   ="REGION_ID";                  
	public static final String KEY_DISTRICT_ID                 ="REG_DISTRICT_ID";                
	public static final String KEY_TALUKA_ID                   ="REG_TALUKA_ID";                  
	public static final String KEY_CONTACT_PERSON              ="CONTACT_PERSON";             
	public static final String KEY_EMAIL_ID                    ="EMAIL_ID";                   
	public static final String KEY_PHONE_NO                    ="PHONE_NO";                   
	public static final String KEY_APP_TYPE                    ="APP_TYPE";                   
	public static final String KEY_SEAT_NO                     ="SEAT_NO";                    
	public static final String KEY_ITI_ID                      ="ITI_ID";                     
	public static final String KEY_JOINING_DATE                ="JOINING_DATE";               
	public static final String KEY_COMPLETION_DATE             ="COMPLETION_DATE";            
	public static final String KEY_REG_NO                      ="REG_NO";                     
	public static final String KEY_REG_DATE                    ="REG_DATE";                   
	public static final String KEY_SKILL_DESC                  ="SKILL_DESC";                 
	public static final String KEY_DESIGNATION                 ="DESIGNATION";               
	public static final String KEY_EXP_SERVING_INDUSTRY        ="EXP_SERVING_INDUSTRY";       
	public static final String KEY_TOTAL_EXP                   ="TOTAL_EXP";                  
	public static final String KEY_RELEVANT_SECTOR             ="RELEVANT_SECTOR";            
	public static final String KEY_MODULE_SKILL                ="MODULE_SKILL";               
	public static final String KEY_NAME_OF_ASSESSING_BODY      ="NAME_OF_ASSESSING_BODY";     
	public static final String KEY_DATE_OF_ASSESSMENT          ="DATE_OF_ASSESSMENT";         
	public static final String KEY_SKILL_ASSESSED              ="SKILL_ASSESSED";             
	public static final String KEY_RESULT                      ="RESULT";                     
	public static final String KEY_COMPETENCY_REQUIRED         ="COMPETENCY_REQUIRED";        
	public static final String KEY_ESTABLISHMENT_ID            ="ESTABLISHMENT_ID";           
	public static final String KEY_EMPLOYEE_TYPE               ="EMPLOYEE_TYPE";              
	public static final String KEY_IS_DELETED                  ="IS_DELETED";                 
	public static final String KEY_REMARKS                     ="REMARKS";                    
	public static final String KEY_EX_PASSING_MONTH            ="EX_PASSING_MONTH";           
	public static final String KEY_EX_PASSING_YEAR             ="EX_PASSING_YEAR";            
	public static final String KEY_CATEGORY                    ="CATEGORY";                   
	public static final String KEY_EX_TRADE                    ="EX_TRADE";                   
	public static final String KEY_BATCH_ID                    ="BATCH_ID";   
	public static final String KEY_TRADE_ID_REG                    ="REG_TRADE_ID";   
	

	//	NEW FIELDS
	//	For Ikvk
	public static final String KEY_COURSE_ID_DISPLAY                   ="COURSE_ID_DISPLAY";                  
	public static final String KEY_IKVK_CENTER_ID_DISPLAY              ="IKVK_CENTER_ID_DISPLAY";    
	public static final String KEY_SHIFT_DISPLAY ="SHIFT_DISPLAY";
	public static final String KEY_BATCH_ID_DISPLAY ="BATCH_ID_DISPLAY";

	//	For SC
	public static final String KEY_REGION_ID_DISPLAY                   ="REGION_ID_DISPLAY";                  
	public static final String KEY_DISTRICT_ID_DISPLAY                 ="REG_DISTRICT_ID_DISPLAY";                
	public static final String KEY_TALUKA_ID_DISPLAY                  ="REG_TALUKA_ID_DISPLAY";  	
	public static final String KEY_RELEVANT_SECTOR_DISPLAY             ="RELEVANT_SECTOR_DISPLAY";            
	public static final String KEY_MODULE_SKILL_DISPLAY                ="MODULE_SKILL_DISPLAY"; 

	// For Apprentice
	public static final String KEY_ITI_ID_DISPLAY                      ="ITI_ID_DISPLAY";
	public static final String KEY_TRADE_ID_DISPLAY                    ="REG_TRADE_ID_DISPLAY";

	// Table Names TABLE_APPLICANT_APPLICANT_MASTER DataBase.

	public static final String TABLE_APPLICANT_MASTER = "APPLICANT_MASTER";
	public static final String KEY_APPLCANT_MASTER_REF_ID     ="REF_ID";
	public static final String KEY_APPLICANT_NO               ="APPLICANT_NO";
	public static final String KEY_APPLICANT_CATEGORY_ID      ="APPLICANT_CATEGORY_ID";
	public static final String KEY_APPLICATION_FORM_NUMBER    ="APPLICATION_FORM_NUMBER";
	public static final String KEY_APPLICANT_PHOTO            ="APPLICANT_PHOTO";
	public static final String KEY_APPLICANT_FNAME_E          ="APPLICANT_FNAME_E";
	public static final String KEY_APPLICANT_FNAME_R          ="APPLICANT_FNAME_R";
	public static final String KEY_APPLICANT_MNAME_E          ="APPLICANT_MNAME_E";
	public static final String KEY_APPLICANT_MNAME_R          ="APPLICANT_MNAME_R";
	public static final String KEY_APPLICANT_LNAME_E          ="APPLICANT_LNAME_E";
	public static final String KEY_APPLICANT_LNAME_R          ="APPLICANT_LNAME_R";
	public static final String KEY_APPLICANT_FATHER_NAME_E    ="APPLICANT_FATHER_NAME_E";
	public static final String KEY_APPLICANT_FATHER_NAME_R    ="APPLICANT_FATHER_NAME_R";
	public static final String KEY_APPLICANT_MOTHER_NAME_E    ="APPLICANT_MOTHER_NAME_E";
	public static final String KEY_APPLICANT_MOTHER_NAME_R    ="APPLICANT_MOTHER_NAME_R";
	public static final String KEY_ADDRESS_E                  ="ADDRESS_E";
	public static final String KEY_ADDRESS_R                  ="ADDRESS_R";
	public static final String KEY_STATE_ID                   ="STATE_ID";
	public static final String KEY_DISTRICT_ID_APPLCANT_MASTER="DISTRICT_ID";
	public static final String KEY_TALUKA_ID_APPLCANT_MASTER  ="TALUKA_ID";
	public static final String KEY_CITY                       ="CITY";
	public static final String KEY_PINCODE                    ="PINCODE";
	public static final String KEY_MOBILE_NO                  ="MOBILE_NO";
	public static final String KEY_LANDLINE_NO   ="LANDLINE_NO";
	public static final String KEY_GENDER                     ="GENDER";
	public static final String KEY_CASTE                      ="CASTE";
	public static final String KEY_PHYSICAL_HANDICAP          ="PHYSICAL_HANDICAP";
	public static final String KEY_PH_VALUE                   ="PH_VALUE";
	public static final String KEY_EX_ARMY                    ="EX_ARMY";
	public static final String KEY_WIDOW                      ="WIDOW";
	public static final String KEY_DIVORCEE                   ="DIVORCEE";
	public static final String KEY_MINORITY                   ="MINORITY";
	public static final String KEY_BPL                        ="BPL";
	public static final String KEY_EMAIL_ADDRESS              ="EMAIL_ADDRESS";
	public static final String KEY_BIRTH_DATE                 ="BIRTH_DATE";
	public static final String KEY_TRADE_ID                   ="TRADE_ID";
	public static final String KEY_CONTRACT_DATE              ="CONTRACT_DATE";
	public static final String KEY_MIN_QUALIFICATION          ="MIN_QUALIFICATION";
	public static final String KEY_RELIgION                   ="RELIgION";
	public static final String KEY_CADIDATE_ASSESSMENT_CODE   ="CADIDATE_ASSESSMENT_CODE";
	public static final String KEY_ASSESSMENT_CODE            ="ASSESSMENT_CODE";
	public static final String KEY_IS_ACTIVE                  ="IS_ACTIVE";
	public static final String KEY_IS_DELETED_APPLCANT_MASTER ="IS_DELETED";
	public static final String KEY_CREATED_BY                 ="CREATED_BY";
	public static final String KEY_CREATED_ON                 ="CREATED_ON";
	public static final String KEY_MODIFIED_BY                ="MODIFIED_BY";
	public static final String KEY_MODIFIED_ON                ="MODIFIED_ON";
	public static final String KEY_Registration_From          ="Registration_From";
	public static final String KEY_CERTIFICATE_PRINTEGERED    ="CERTIFICATE_PRINTEGERED";
	public static final String KEY_CERTIFICATE_PRINTEGER_DATE ="CERTIFICATE_PRINTEGER_DATE";
	public static final String KEY_CERTIFICATE_NUMBER         ="CERTIFICATE_NUMBER";
	public static final String KEY_PHOTO_AVAILABLE            ="PHOTO_AVAILABLE";
	public static final String KEY_prINTEGER_eligible         ="prINTEGER_eligible";
	public static final String KEY_Applicant_Type             ="Applicant_Type";
	public static final String KEY_Training_From              ="Training_From";
	public static final String KEY_training_to                ="training_to";
	public static final String KEY_APPLICANT_STATUS           ="APPLICANT_STATUS";
	public static final String KEY_IS_EDITED                  ="IS_EDITED";
	public static final String KEY_EX_OFFICIO_ID              ="EX_OFFICIO_ID";
	public static final String KEY_IsContract_Terminated      ="IsContract_Terminated";


	//	NEW FIELDS
	public static final String KEY_APPLICANT_MASTER_user_email ="user_email";
	public static final String KEY_STATE_ID_DISPLAY ="STATE_ID_DISPLAY";
	public static final String KEY_DISTRICT_ID_APPLCANT_MASTER_DISPLAY ="DDISTRICT_ID_DISPLAY";
	public static final String KEY_TALUKA_ID_APPLCANT_MASTER_DISPLAY ="TALUKA_ID_DISPLAY";
	public static final String KEY_GENDER_DISPLAY ="GENDER_DISPLAY";
	public static final String KEY_CASTE_DISPLAY ="CASTE_DISPLAY";
	public static final String KEY_LATTITUDE      ="LATTITUDE";
	public static final String KEY_LONGITUDE      ="LONGITUDE";



	// Table Names TABLE_COUNTRY_MASTER DataBase.

	public static final String TABLE_COUNTRY_MASTER  ="COUNTRY_MASTER";
	public static final String KEY_COUNTRY_ID      ="COUNTRY_ID";
	public static final String KEY_COUNTRY_NAME_E  ="COUNTRY_NAME_E";
	public static final String KEY_COUNTRY_NAME_R  ="COUNTRY_NAME_R";
	public static final String KEY_IS_DELETED_COUNTRY_MASTER  ="IS_DELETED";
	public static final String KEY_CREATED_ON_COUNTRY_MASTER  ="CREATED_ON";
	public static final String KEY_CREATED_BY_COUNTRY_MASTER="CREATED_BY";
	public static final String KEY_MODIFIED_ON_COUNTRY_MASTER="MODIFIED_ON";
	public static final String KEY_MODIFIED_BY_COUNTRY_MASTER ="MODIFIED_BY";



	// Table Names TABLE_COURSE_MASTER DataBase.
	public static final String TABLE_COURSE_MASTER  ="COURSE_MASTER";
	public static final String KEY_REF_ID_COURSE_MASTER           ="REF_ID";
	public static final String KEY_COURSE_CODE      ="COURSE_CODE";
	public static final String KEY_COURSE_NAME      ="COURSE_NAME";
	public static final String KEY_COURSE_NAME_R    ="COURSE_NAME_R";
	public static final String KEY_DETAILS          ="DETAILS";
	public static final String KEY_DURATION         ="DURATION";
	public static final String KEY_SCHEME_IDS       ="SCHEME_IDS";
	public static final String KEY_IS_DELETED_COURSE_MASTER       ="IS_DELETED";
	public static final String KEY_IS_ACTIV_COURSE_MASTERE        ="IS_ACTIVE";
	public static final String KEY_CREATED_BY_COURSE_MASTER       ="CREATED_BY";
	public static final String KEY_CREATED_ON_COURSE_MASTER       ="CREATED_ON";
	public static final String KEY_MODIFIED_BY_COURSE_MASTER      ="MODIFIED_BY";
	public static final String KEY_MODIFIED_ON_COURSE_MASTER      ="MODIFIED_ON";
	public static final String KEY_batch_size       ="batch_size";




	// Table Names TABLE_ESTABLISHMENT_COURSE_MAPPING DataBase.

	public static final String TABLE_ESTABLISHMENT_COURSE_MAPPING  ="ESTABLISHMENT_COURSE_MAPPING";
	public static final String KEY_REF_ID_ESTABLISHMENT_COURSE_MAPPING                ="REF_ID";
	public static final String KEY_COURSE_ID_ESTABLISHMENT_COURSE_MAPPING="COURSE_ID";
	public static final String KEY_ESTABLISHMENT_ID_ESTABLISHMENT_COURSE_MAPPING      ="ESTABLISHMENT_ID";
	public static final String KEY_NO_OF_BATCHES         ="NO_OF_BATCHES";
	public static final String KEY_STRENGTH_PER_BATCH_ESTABLISHMENT_COURSE_MAPPING    ="STRENGTH_PER_BATCH";
	public static final String KEY_SHIFTS_ESTABLISHMENT_COURSE_MAPPING                ="SHIFTS";
	public static final String KEY_IS_ACTIVE_ESTABLISHMENT_COURSE_MAPPING             ="IS_ACTIVE";
	public static final String KEY_IS_DELETED_ESTABLISHMENT_COURSE_MAPPING            ="IS_DELETED";
	public static final String KEY_CREATED_BY_ESTABLISHMENT_COURSE_MAPPING            ="CREATED_BY";
	public static final String KEY_CREATED_ON_ESTABLISHMENT_COURSE_MAPPING            ="CREATED_ON";
	public static final String KEY_MODIFIED_BY_ESTABLISHMENT_COURSE_MAPPING           ="MODIFIED_BY";
	public static final String KEY_MODIFIED_ON_ESTABLISHMENT_COURSE_MAPPING           ="MODIFIED_ON";
	public static final String KEY_NO_OF_HOURS_ESTABLISHMENT_COURSE_MAPPING           ="NO_OF_HOURS";
	public static final String KEY_FRESHER_STRENGTH_ESTABLISHMENT_COURSE_MAPPING      ="FRESHER_STRENGTH";
	public static final String KEY_INHOUSE_STRENGTH_ESTABLISHMENT_COURSE_MAPPING      ="INHOUSE_STRENGTH";



	// Table Names TABLE_ESTABLISHMENT_MASTER DataBase.

	public static final String TABLE_ESTABLISHMENT_MASTER  ="ESTABLISHMENT_MASTER";

	public static final String KEY_REF_ID_ESTABLISHMENT_MASTER                        =  "REF_ID" ;
	public static final String KEY_ESTABLISHMENT_NO              =  "ESTABLISHMENT_NO" ;
	public static final String KEY_ESTABLISHMENT_CODE            =  "ESTABLISHMENT_CODE" ;
	public static final String KEY_ESTABLISHMENT_NAME_E          =  "ESTABLISHMENT_NAME_E" ;
	public static final String KEY_ESTABLISHMENT_NAME_R          =  "ESTABLISHMENT_NAME_R" ;
	public static final String KEY_ADDRESS_E_ESTABLISHMENT_MASTER      =  "ADDRESS_E" ;
	public static final String KEY_ADDRESS_R_ESTABLISHMENT_MASTER      =  "ADDRESS_R" ;
	public static final String KEY_CONTACT_PERSON_ESTABLISHMENT_MASTER =  "CONTACT_PERSON" ;
	public static final String KEY_CITY_ESTABLISHMENT_MASTER           =  "CITY" ;
	public static final String KEY_TALUKA_ID_ESTABLISHMENT_MASTER      =  "TALUKA_ID" ;
	public static final String KEY_DISTRICT_ID_ESTABLISHMENT_MASTER    =  "DISTRICT_ID" ;
	public static final String KEY_STATE_ID_ESTABLISHMENT_MASTER       =  "STATE_ID" ;
	public static final String KEY_REGION_ID_ESTABLISHMENT_MASTER      =  "REGION_ID" ;
	public static final String KEY_PIN_CODE_ESTABLISHMENT_MASTER       =  "PIN_CODE" ;
	public static final String KEY_MOBILE_ESTABLISHMENT_MASTER         =  "MOBILE" ;
	public static final String KEY_LANDLINE_ESTABLISHMENT_MASTER       =  "LANDLINE" ;
	public static final String KEY_EMAIL_ID_ESTABLISHMENT_MASTER       =  "EMAIL_ID" ;
	public static final String KEY_SECTORE_ID_ESTABLISHMENT_MASTER     =  "SECTORE_ID" ;
	public static final String KEY_ACTIVITY                      =  "ACTIVITY" ;
	public static final String KEY_MAN_POWER                     =  "MAN_POWER" ;
	public static final String KEY_IS_ACTIVE_ESTABLISHMENT_MASTER                     =  "IS_ACTIVE" ;
	public static final String KEY_Fax_no                        =  "Fax_no" ;
	public static final String KEY_HOD_DESIGNATION               =  "HOD_DESIGNATION" ;
	public static final String KEY_STATUS_ID                     =  "STATUS_ID" ;
	public static final String KEY_Establishment_Type            =  "Establishment_Type" ;
	public static final String KEY_EST_TAN_NO                    =  "EST_TAN_NO" ;
	public static final String KEY_EST_PF_NO                     =  "EST_PF_NO" ;
	public static final String KEY_EST_PAN_NO                    =  "EST_PAN_NO" ;
	public static final String KEY_EST_ESI_NO                    =  "EST_ESI_NO" ;
	public static final String KEY_Major_Code                    =  "Major_Code" ;
	public static final String KEY_Minor_Code                    =  "Minor_Code" ;
	public static final String KEY_Working_Days                  =  "Working_Days" ;
	public static final String KEY_MINISTRY_NAME                 =  "MINISTRY_NAME" ;
	public static final String KEY_DEPARTMENT_NAME               =  "DEPARTMENT_NAME" ;
	public static final String KEY_HOD_NAME                      =  "HOD_NAME" ;
	public static final String KEY_HOD_PHONE                     =  "HOD_PHONE" ;
	public static final String KEY_HOD_EMAIL                     =  "HOD_EMAIL" ;
	public static final String KEY_IOT_NAME                      =  "IOT_NAME" ;
	public static final String KEY_IOT_DESIGNATION               =  "IOT_DESIGNATION" ;
	public static final String KEY_IOT_PHONE                     =  "IOT_PHONE" ;
	public static final String KEY_IOT_EMAIL                     =  "IOT_EMAIL" ;
	public static final String KEY_NO_OF_OFFICERS                =  "NO_OF_OFFICERS" ;
	public static final String KEY_NO_OF_WORKERS                 =  "NO_OF_WORKERS" ;
	public static final String KEY_IS_DELETED_ESTABLISHMENT_MASTER                    =  "IS_DELETED" ;
	public static final String KEY_IS_CONVERTED_INDUSTRY         =  "IS_CONVERTED_INDUSTRY" ;
	public static final String KEY_CREATED_BY_ESTABLISHMENT_MASTER                    =  "CREATED_BY" ;
	public static final String KEY_CREATED_ON_ESTABLISHMENT_MASTER                    =  "CREATED_ON" ;
	public static final String KEY_MODIFIED_BY_ESTABLISHMENT_MASTER                   =  "MODIFIED_BY" ;
	public static final String KEY_MODIFIED_ON_ESTABLISHMENT_MASTER                   =  "MODIFIED_ON" ;
	public static final String KEY_Assessing_Bodies              =  "Assessing_Bodies" ;
	public static final String KEY_Allow_Apprentice              =  "Allow_Apprentice" ;
	public static final String KEY_Allow_iKVK                    =  "Allow_iKVK" ;
	public static final String KEY_Allow_Skill_Ceritification    =  "Allow_Skill_Ceritification" ;
	public static final String KEY_ALLOTED_TOTAL                 =  "ALLOTED_TOTAL" ;
	public static final String KEY_FILLED_TOTAL                  =  "FILLED_TOTAL" ;
	public static final String KEY_VACANCY_TOTAL                 =  "VACANCY_TOTAL" ;
	public static final String KEY_EX_OFFICIO_ID_ESTABLISHMENT_MASTER                 =  "EX_OFFICIO_ID" ;
	public static final String KEY_Company_Logo                  =  "Company_Logo" ;
	public static final String KEY_Allotmemt_Issue               =  "Allotmemt_Issue" ;
	public static final String KEY_Allotment_Upload              =  "Allotment_Upload" ;
	public static final String KEY_Allotment_Date                =  "Allotment_Date" ;
	public static final String KEY_Survey_Type                   =  "Survey_Type" ;
	public static final String KEY_Date_Of_Survey                =  "Date_Of_Survey" ;
	public static final String KEY_Survey_File                   =  "Survey_File" ;
	public static final String KEY_Allotment_Letter_No           =  "Allotment_Letter_No" ;
	public static final String KEY_Product_1                     =  "Product_1" ;
	public static final String KEY_Product_2                     =  "Product_2" ;
	public static final String KEY_Product_3                     =  "Product_3" ;
	public static final String KEY_PART_OF                       =  "PART_OF" ;
	public static final String KEY_PART_OF_VALUE                 =  "PART_OF_VALUE" ;
	public static final String KEY_NEARER_NODAL_ITI              =  "NEARER_NODAL_ITI" ;
	public static final String KEY_MEMBER_OF                     =  "MEMBER_OF" ;
	public static final String KEY_MEMBER_OF_VALUE               =  "MEMBER_OF_VALUE" ;
	public static final String KEY_PPP_PARTNER                   =  "PPP_PARTNER" ;
	public static final String KEY_PPP_PARTNER_VALUE             =  "PPP_PARTNER_VALUE" ;
	public static final String KEY_website                       =  "website" ;
	public static final String KEY_EDITED                        =  "EDITED" ;
	public static final String KEY_GBIFR_BIFR_Ref_No             =  "GBIFR_BIFR_Ref_No" ;
	public static final String KEY_CLOSED_FROM                   =  "CLOSED_FROM" ;
	public static final String KEY_TOTAL_ALLOTED_SEAT            =  "TOTAL_ALLOTED_SEAT" ;
	public static final String KEY_IS_SKILESTABLISHMENT          =  "IS_SKILESTABLISHMENT" ;
	public static final String KEY_IS_iKVKESTABLISHMENT          =  "IS_iKVKESTABLISHMENT" ;
	public static final String KEY_NATURE_PRODUCT                =  "NATURE_PRODUCT" ;
	public static final String KEY_COVERED_UNDER_APPRENTICE_ACT	=	"COVERED_UNDER_APPRENTICE_ACT"	;																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																						


	// Table Names TABLE_ITI_MASTER DataBase.

	public static final String TABLE_ITI_MASTER  ="ITI_MASTER";

	public static final String KEY_ITI_ID_ITI_MASTER                    ="ITI_ID";
	public static final String KEY_ITI_CODE                  ="ITI_CODE";
	public static final String KEY_ITI_NAME_E                ="ITI_NAME_E";
	public static final String KEY_ITI_NAME_R                ="ITI_NAME_R";    
	public static final String KEY_IS_NODAL_ITI              ="IS_NODAL_ITI";
	public static final String KEY_PARENT_ID                 ="PARENT_ID";
	public static final String KEY_ITI_L                     ="ITI_L";
	public static final String KEY_REGION_ID_ITI_MASTER                 ="REGION_ID";
	public static final String KEY_ITI_TYPE                  ="ITI_TYPE";
	public static final String KEY_DISTRICT_ID_ITI_MASTER               ="DISTRICT_ID";
	public static final String KEY_PRINTEGERED_NAME_E        ="PRINTEGERED_NAME_E";
	public static final String KEY_PRINTEGERED_NAME_R        ="PRINTEGERED_NAME_R";
	public static final String KEY_PLACE                     ="PLACE";
	public static final String KEY_ADDRESS_E_ITI_MASTER                 ="ADDRESS_E";
	public static final String KEY_ADDRESS_R_ITI_MASTER                 ="ADDRESS_R";
	public static final String KEY_PRINCIPAL                 ="PRINCIPAL";
	public static final String KEY_VICEPRIN                  ="VICEPRIN";
	public static final String KEY_PINCODE_ITI_MASTER                   ="PINCODE";
	public static final String KEY_PHONE                     ="PHONE";
	public static final String KEY_MOBILE_NO_ITI_MASTER                 ="MOBILE_NO";
	public static final String KEY_HOUSE_NAME                ="HOUSE_NAME";
	public static final String KEY_TALUKA                    ="TALUKA";
	public static final String KEY_VILLAGE                   ="VILLAGE";
	public static final String KEY_FALIYU                    ="FALIYU";
	public static final String KEY_LANDMARK                  ="LANDMARK";
	public static final String KEY_IS_ISO                    ="IS_ISO";
	public static final String KEY_ISO_NO                    ="ISO_NO";
	public static final String KEY_IS_COE                    ="IS_COE";
	public static final String KEY_IS_VTIP                   ="IS_VTIP";
	public static final String KEY_IS_TRIBLE                 ="IS_TRIBLE";
	public static final String KEY_IS_ACTIVE_ITI_MASTER                 ="IS_ACTIVE";
	public static final String KEY_CREATED_ON_ITI_MASTER                ="CREATED_ON";
	public static final String KEY_MODIFIED_BY_ITI_MASTER               ="MODIFIED_BY";
	public static final String KEY_CREATED_BY_ITI_MASTER                ="CREATED_BY";
	public static final String KEY_MODIFIED_ON_ITI_MASTER               ="MODIFIED_ON";
	public static final String KEY_IS_DELETED_ITI_MASTER                ="IS_DELETED";
	public static final String KEY_ADDRESS_TYPE              ="ADDRESS_TYPE";
	public static final String KEY_STATE_ID_ITI_MASTER                  ="STATE_ID";
	public static final String KEY_EMAIL_ID_ITI_MASTER                  ="EMAIL_ID";
	public static final String KEY_IS_RI                     ="IS_RI";
	public static final String KEY_IS_PPP                    ="IS_PPP";
	public static final String KEY_taluka_id_ITI_MASTER                 ="taluka_id";


	/**
	 * Batches Table Construction	
	 */
	public static final String TABLE_BATCH ="batches";
	public static final String KEY_BATCH_NAME = "batch_name";
	public static final String KEY_BATCH_VALUES = "batch_value";



	// Table Names TABLE_Preferredshift DataBase.

	public static final String TABLE_Preferredshift  ="Preferredshift";

	public static final String KEY_REF_ID_Preferredshift				= "REF_ID";
	public static final String KEY_PREFERRED_SHIFT       ="PREFERRED_SHIFT";



	// Table Names TABLE_Sector_Master DataBase.
	public static final String TABLE_Sector_Master  ="Sector_Master";
	public static final String KEY_REF_ID_Sector_Master                  ="REF_ID";
	public static final String KEY_COURSE_CODE_Sector_Master             ="COURSE_CODE";
	public static final String KEY_SECTOR_NAME             ="SECTOR_NAME";
	public static final String KEY_MIN_EDU_COURSE_CODE     ="MIN_EDU_COURSE_CODE";
	public static final String KEY_IS_DELETED_Sector_Master              ="IS_DELETED";
	public static final String KEY_CREATED_BY_Sector_Master              ="CREATED_BY";
	public static final String KEY_CREATED_ON_Sector_Master              ="CREATED_ON";
	public static final String KEY_MODIFIED_BY_Sector_Master             ="MODIFIED_BY";
	public static final String KEY_MODIFIED_ON_Sector_Master            ="MODIFIED_ON";


	// Table Names TABLE_Skill_Master DataBase.
	public static final String TABLE_Skill_Master  ="Skill_Master";
	public static final String KEY_REF_ID_Skill_Master                 ="REF_ID";
	public static final String KEY_SECTOR_ID              ="SECTOR_ID";
	public static final String KEY_SKILL_CODE             ="SKILL_CODE";
	public static final String KEY_SKILL_NAME             ="SKILL_NAME";
	public static final String KEY_MIN_EDU_COURSE_CODE_Skill_Master    ="MIN_EDU_COURSE_CODE";
	public static final String KEY_DURATION_Skill_Master               ="DURATION";
	public static final String KEY_TEST_FEE               ="TEST_FEE";
	public static final String KEY_TRAINING_CATEGORY      ="TRAINING_CATEGORY";
	public static final String KEY_IS_DELETED_Skill_Master             ="IS_DELETED";
	public static final String KEY_CREATED_BY_Skill_Master             ="CREATED_BY";
	public static final String KEY_CREATED_ON_Skill_Master             ="CREATED_ON";
	public static final String KEY_MODIFIED_BY_Skill_Master            ="MODIFIED_BY";
	public static final String KEY_MODIFIED_ON_Skill_Master            ="MODIFIED_ON";



	// Table Names TABLE_TRADE_MASTER DataBase.
	public static final String TABLE_TRADE_MASTER ="TRADE_MASTER";

	public static final String KEY_TRADE_ID_TRADE_MASTER                ="TRADE_ID";
	public static final String KEY_TRADE_NAME_E            ="TRADE_NAME_E";
	public static final String KEY_TRADE_NAME_R            ="TRADE_NAME_R";
	public static final String KEY_RATIO                   ="RATIO";
	public static final String KEY_NCO_CODE                ="NCO_CODE";
	public static final String KEY_DURATION_TRADE_MASTER                ="DURATION";
	public static final String KEY_SHORT_NAME              ="SHORT_NAME";
	public static final String KEY_TRADE_GROUP_ID          ="TRADE_GROUP_ID";
	public static final String KEY_TRADE_SUB_GROUP_ID      ="TRADE_SUB_GROUP_ID";
	public static final String KEY_TRADE_CODE              ="TRADE_CODE";
	public static final String KEY_TRADE_CLASSIFICATION    ="TRADE_CLASSIFICATION";
	public static final String KEY_IS_ACTIVE_TRADE_MASTER               ="IS_ACTIVE";
	public static final String KEY_CREATED_ON_TRADE_MASTER              ="CREATED_ON";
	public static final String KEY_MODIFIED_BY_TRADE_MASTER             ="MODIFIED_BY";
	public static final String KEY_CREATED_BY_TRADE_MASTER              ="CREATED_BY";
	public static final String KEY_MODIFIED_ON_TRADE_MASTER             ="MODIFIED_ON";
	public static final String KEY_IS_DELETED_TRADE_MASTER              ="IS_DELETED";
	public static final String KEY_IS_BBBT                 ="IS_BBBT";
	public static final String KEY_PARENT_ID_TRADE_MASTER               ="PARENT_ID";
	public static final String KEY_TRADE_SYLLABUS          ="TRADE_SYLLABUS";



	// Table Names candidate_skillcerti DataBase.
	public static final String TABLE_candidate_skillcerti = "candidate_skillcerti";
	public static final String KEY_rsc_candidate_id = "candidate_id";
	public static final String KEY_rsc_email  = "email ";


	public Context context;
	static SQLiteDatabase sqliteDataBase;

	private static DataBaseHelper mInstance = null;

	public static DataBaseHelper getInstance(Context ctx) {

		// Use the application context, which will ensure that you
		// don't accidentally leak an Activity's context.
		// See this article for more information: http://bit.ly/6LRzfx
		if (mInstance == null) {
			mInstance = new DataBaseHelper(ctx.getApplicationContext());
		}
		return mInstance;
	}

	public DataBaseHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
		this.context = context;
		System.out.println("testdb: DataBaseHelper ");
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {
		System.out.println("testdb: onCreate ");
	}

	// check if the database exists
	public void createDataBase() throws IOException {
		boolean databaseExist = checkDataBase();

		if (databaseExist) {
			// Do Nothing.
			System.out.println("testdb: createDataBase- Do Nothing");
		} else {
			this.getWritableDatabase();
			// this.getReadableDatabase();

			// copyDataBase();
			System.out.println("testdb: createDataBase - copy Database");
			copytestDataBase();

			System.out.println("DBPATH" + DB_PATH);
			// copyDatabaseToSdCard();

			// TODO Auto-generated catch block

		}
	}// end if else dbExist
	// end createDataBase().

	/*
	 * public boolean checkDataBase(){ File databaseFile = new File(DB_PATH +
	 * DATABASE_NAME); return databaseFile.exists(); }
	 */
	private boolean checkDataBase() 
	{
		SQLiteDatabase checkDB = null;
		try 
		{
			System.out.println("testdb: checkDataBase");

			String myPath = DB_PATH + DATABASE_NAME;
			checkDB = SQLiteDatabase.openDatabase(myPath, null,	SQLiteDatabase.OPEN_READWRITE);
		} catch (SQLiteException e) 
		{
			// database does't exist yet.
		}

		if (checkDB != null) {
			checkDB.close();
		}

		return checkDB != null ? true : false;
	}

	private void copytestDataBase() throws IOException {

		System.out.println("testdb: copytestDataBase");
		// Open your local db as the input stream
		InputStream myInput = context.getAssets().open(DATABASE_NAME);

		// Path to the just created empty db
		String outFileName = DB_PATH + DATABASE_NAME;

		// Open the empty db as the output stream
		OutputStream myOutput = new FileOutputStream(outFileName);

		// transfer bytes from the inputfile to the outputfile
		byte[] buffer = new byte[1024];
		int length;
		while ((length = myInput.read(buffer)) > 0) {
			myOutput.write(buffer, 0, length);
		}

		// Close the streams
		myOutput.flush();
		myOutput.close();
		myInput.close();

	}

	public void copyDatabaseToSdCard() {
		Log.e("Databasehelper", "********************************");
		try {
			/*
			 * File f1 = new File("file:///android_asset/" + "webopac.sqlite");
			 * if (f1.exists()) {
			 * 
			 * File f2 = new
			 * File(Environment.getExternalStorageDirectory().getAbsoluteFile()+
			 * "/webopac.sqlite"); System.out.println(f2); f2.createNewFile();
			 * InputStream in = new FileInputStream(f1); OutputStream out = new
			 * FileOutputStream(f2); byte[] buf = new byte[1024]; int len; while
			 * ((len = in.read(buf)) > 0) { out.write(buf, 0, len); }
			 * in.close(); out.close(); } } catch (FileNotFoundException ex) {
			 * System.out.println(ex.getMessage() +
			 * " in the specified directory."); System.exit(0); } catch
			 * (IOException e) { e.printStackTrace();
			 * System.out.println(e.getMessage()); } Log.e("Databasehealper",
			 * "********************************");
			 */
			// *Open your local db as the input stream*/
			InputStream myInput = context.getAssets().open(DATABASE_NAME);

			// Path to the just created empty db
			String outFileName = DB_PATH + DATABASE_NAME;

			// Open the empty db as the output stream
			OutputStream myOutput = new FileOutputStream(outFileName);

			// transfer bytes from the inputfile to the outputfile
			byte[] buffer = new byte[1024];
			int length;
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}

			// Close the streams
			myOutput.flush();
			myOutput.close();
			myInput.close();

			// copyDBToSDCard();
		}

		catch (IOException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	public void copyDBToSDCard() {
		try {
			InputStream myInput = new FileInputStream(DB_PATH + DATABASE_NAME);

			File file = new File(Environment.getExternalStorageDirectory()
					.getPath() + "/" + DATABASE_NAME);
			if (!file.exists()) {
				try {
					file.createNewFile();
				} catch (IOException e) {
					Log.i("FO", "File creation failed for " + file);
				}
			}

			OutputStream myOutput = new FileOutputStream(Environment
					.getExternalStorageDirectory().getPath()
					+ "/"
					+ DATABASE_NAME);

			byte[] buffer = new byte[1024];
			int length;
			while ((length = myInput.read(buffer)) > 0) {
				myOutput.write(buffer, 0, length);
			}

			// Close the streams
			myOutput.flush();
			myOutput.close();
			myInput.close();
			Log.i("FO", "copied");

		} catch (Exception e) {
			Log.i("FO", "exception=" + e);
		}

	}

	/*
	 * private void copyDataBase() throws IOException{ //Open your local db as
	 * the input stream InputStream myInput =
	 * context.getAssets().open(DATABASE_NAME); // Path to the just created
	 * empty db String outFileName = DB_PATH + DATABASE_NAME; //Open the empty
	 * db as the output stream OutputStream myOutput = new
	 * FileOutputStream(outFileName); //transfer bytes from the input file to
	 * the output file byte[] buffer = new byte[1024]; int length; while
	 * ((length = myInput.read(buffer))>0){ myOutput.write(buffer, 0, length); }
	 * 
	 * //Close the streams myOutput.flush(); myOutput.close(); myInput.close();
	 * }
	 */

	/**
	 * This method opens the data base connection. First it create the path up
	 * till data base of the device. Then create connection with data base.
	 */
	public void openDataBase() throws SQLException {
		// Open the database

		try {
			createDataBase();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String myPath = DB_PATH + DATABASE_NAME;

		sqliteDataBase = SQLiteDatabase.openDatabase(myPath, null,
				SQLiteDatabase.OPEN_READWRITE);

	}

	/**
	 * This Method is used to close the data base connection.
	 */
	@Override
	public synchronized void close() {
		if (sqliteDataBase != null)
			sqliteDataBase.close();
		super.close();
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		/*
		 * Log.w(DataBaseHelper.class.getName(),
		 * "Upgrading database from version " + oldVersion + " to " + newVersion
		 * + ", which will destroy all old data");
		 * sqliteDataBase.execSQL("DROP TABLE IF EXISTS " + DATABASE_NAME);
		 * onCreate(db);
		 */
		Log.d("adas", "dasd");
		System.out.println("testdb: Upgrading database from version "
				+ oldVersion + " to " + newVersion
				+ ", which will destroy all old data");

		if (newVersion > oldVersion) {
			String myPath = DB_PATH + DATABASE_NAME;
			this.context.deleteDatabase(myPath);
			try {
				this.copytestDataBase();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}