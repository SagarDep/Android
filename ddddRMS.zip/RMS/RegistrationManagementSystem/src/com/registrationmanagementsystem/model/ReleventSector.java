package com.registrationmanagementsystem.model;

public class ReleventSector {
	String REF_ID;
	String COURSE_CODE;
	String SECTOR_NAME;
	
	public String getREF_ID() {
		return REF_ID;
	}
	public void setREF_ID(String rEF_ID) {
		REF_ID = rEF_ID;
	}
	public String getCOURSE_CODE() {
		return COURSE_CODE;
	}
	public void setCOURSE_CODE(String cOURSE_CODE) {
		COURSE_CODE = cOURSE_CODE;
	}
	public String getSECTOR_NAME() {
		return SECTOR_NAME;
	}
	public void setSECTOR_NAME(String sECTOR_NAME) {
		SECTOR_NAME = sECTOR_NAME;
	}
}
