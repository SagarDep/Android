package com.registrationmanagementsystem;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;

public class SignInActivity extends Activity {

	private static final String TAG = SignInActivity.class.getName();
	EditText etxUserName, etxPass;

	Button btnLogin, btnAdmin, btnCandidateReg, btnIndustryReg;

	DataBaseHelper mDbHelper;

	CheckBox chkCandidate, chkindustry, chkassessing_body, chksurvay_user;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.actvity_signin);

		/*
		 * save default location for first time or until it get it
		 */
		Global.saveDefaultLatLng(SignInActivity.this);
		
		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());

		etxUserName = (EditText) findViewById(R.id.txtUsername);
		etxPass = (EditText) findViewById(R.id.txtPassword);

		chkCandidate = (CheckBox) findViewById(R.id.chkCandidate);
		chkindustry = (CheckBox) findViewById(R.id.chkindustry);
		chkassessing_body = (CheckBox) findViewById(R.id.chkassessing_body);
		chksurvay_user = (CheckBox) findViewById(R.id.chksurvay_user);

		chkCandidate.setOnCheckedChangeListener(checkListener);
		chkindustry.setOnCheckedChangeListener(checkListener);
		chkassessing_body.setOnCheckedChangeListener(checkListener);
		chksurvay_user.setOnCheckedChangeListener(checkListener);

		btnLogin = (Button) findViewById(R.id.btnLogin);
		btnAdmin = (Button) findViewById(R.id.btnSigninAdmin);
		btnCandidateReg = (Button) findViewById(R.id.btnCandidateReg);
		btnIndustryReg = (Button) findViewById(R.id.btnIndustryReg);

		btnLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				//				if(validationSingIn()) {
				//					
				//				}
				//				validationSingIn();

				if(validationSingIn()) {
					/*Intent m_intent = new Intent(SignInActivity.this,
							NavMainActivity.class);*/
//					Intent m_intent = new Intent(SignInActivity.this,
//							NavMainActivity.class);
					Intent m_intent = new Intent(SignInActivity.this,
							MainHomeActivity.class);
					startActivity(m_intent);
					finish();
				} else if(adminValidationSingIn()){
					Intent m_intent = new Intent(SignInActivity.this,
							MainHomeActivity.class);
					startActivity(m_intent);
					finish();					
				} else {
					etxUserName.setText("");
					etxPass.setText("");
					Global.showAlertDialog(SignInActivity.this, "Login", getResources().getString(R.string.err_msg_not_valid), false);
				}
			}
		});

		btnAdmin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

			}
		});

		btnCandidateReg.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent m_intent = new Intent(SignInActivity.this,
						RegistrationDetailActivity.class);
				startActivity(m_intent);
			}
		});

		btnIndustryReg.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent m_intent = new Intent(SignInActivity.this,
						IndustryRegistration.class);
				startActivity(m_intent);
			}
		});

	}

	private OnCheckedChangeListener checkListener = new OnCheckedChangeListener() {

		@Override
		public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
			// TODO Auto-generated method stub

			if(isChecked) {
				switch (buttonView.getId()) {
				case R.id.chkCandidate:
					chkCandidate.setChecked(true);
					chkindustry.setChecked(false);
					chkassessing_body.setChecked(false);
					chksurvay_user.setChecked(false);
					break;

				case R.id.chkindustry:
					chkCandidate.setChecked(false);
					chkindustry.setChecked(true);
					chkassessing_body.setChecked(false);
					chksurvay_user.setChecked(false);
					break;

				case R.id.chkassessing_body:
					chkCandidate.setChecked(false);
					chkindustry.setChecked(false);
					chkassessing_body.setChecked(true);
					chksurvay_user.setChecked(false);
					break;

				case R.id.chksurvay_user:
					chkCandidate.setChecked(false);
					chkindustry.setChecked(false);
					chkassessing_body.setChecked(false);
					chksurvay_user.setChecked(true);
					break;
				}
			}
		}
	};
	
	

	/*	private boolean validationSingIn() {
		boolean isValid = true;
		if(!chkCandidate.isChecked() && !chkindustry.isChecked() &&	!chkassessing_body.isChecked() && !chksurvay_user.isChecked()) {
			isValid = false;
			Global.showAlertDialog(SignInActivity.this, "SignIn", "Please select check box.", false);
		} else {

			if(chkCandidate.isChecked()) {
				Intent m_intent = new Intent(SignInActivity.this,
						UserListing.class);
				startActivity(m_intent);

			} else if(chkindustry.isChecked()) {
				Intent m_intent = new Intent(SignInActivity.this,
						IndustryListing.class);
				startActivity(m_intent);
			}
		}
		return isValid;
	}*/

	private boolean validationSingIn() {
		boolean isValid = false;

		if(etxUserName.getText().toString().equalsIgnoreCase("")) {
			etxUserName.setError(getResources().getString(R.string.err_msg_username));
		} else if (etxPass.getText().toString().equalsIgnoreCase("")) {
			etxPass.setError(getResources().getString(R.string.err_msg_password));
		} else {	
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			long table_length = DatabaseUtils.queryNumEntries(db, DataBaseHelper.TABLE_user_credentails);

			if(table_length > 0) {
				
				System.out.println("TESTDB: validationSingIn if - read from table table_length = " + table_length);
				//				Cursor result = db.rawQuery("select * from " +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from " +DataBaseHelper.TABLE_user_credentails, null);
				result.moveToFirst();
				while(result.isAfterLast() == false) {
					String user_email = result.getString(result.getColumnIndex(DataBaseHelper.KEY_uc_user_email));
					Log.i(TAG,"registrar_id = " + user_email);
					if(user_email.equalsIgnoreCase(etxUserName.getText().toString())) {
						Log.e(TAG,"registrar_id matched = " + user_email);
						String registrar_pass = result.getString(result.getColumnIndex(DataBaseHelper.KEY_uc_user_pass));
						if(registrar_pass.equalsIgnoreCase(etxPass.getText().toString())) {
							isValid = true;
							Global.userAdminLogin(SignInActivity.this, "user", user_email);
							break;
						}
					}
					result.moveToNext();
				}
				if(!result.isClosed()) {
					result.close();				
				}
			} else {
				System.out.println("TESTDB: validationSingIn else async call  table_length = " + table_length);

			}
		}
		
		return isValid;
	}

	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.exit, menu);
		/*		if (member_id != null) {
			menu.add(Menu.NONE, MENU_ITEM5, Menu.NONE, "Logout");
		}*/
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		
		case R.id.exit:
			finish();
			return true;    
		}
	return false;
}

	private boolean adminValidationSingIn() {
		boolean isValid = false;

		if(etxUserName.getText().toString().equalsIgnoreCase("")) {
			etxUserName.setError(getResources().getString(R.string.err_msg_username));
		} else if (etxPass.getText().toString().equalsIgnoreCase("")) {
			etxPass.setError(getResources().getString(R.string.err_msg_password));
		} else {	
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			long table_length = DatabaseUtils.queryNumEntries(db, DataBaseHelper.TABLE_admin_credentials);

			if(table_length > 0) {
				
				System.out.println("TESTDB: adminValidationSingIn if - read from table table_length = " + table_length);
				//				Cursor result = db.rawQuery("select * from " +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from " +DataBaseHelper.TABLE_admin_credentials, null);
				result.moveToFirst();
				while(result.isAfterLast() == false) {
					String admin_email = result.getString(result.getColumnIndex(DataBaseHelper.KEY_ac_admin_email));
					Log.i(TAG,"admin_name = " + admin_email);
					if(admin_email.equalsIgnoreCase(etxUserName.getText().toString())) {
						Log.e(TAG,"registrar_id matched = " + admin_email);
						String admin_pass = result.getString(result.getColumnIndex(DataBaseHelper.KEY_ac_admin_pass));
						if(admin_pass.equalsIgnoreCase(etxPass.getText().toString())) {
							isValid = true;
							Global.userAdminLogin(SignInActivity.this, "admmin", admin_email);
							break;
						} 
					}
					result.moveToNext();
				}
				
				if(!result.isClosed()) {
					result.close();				
				}
			} else {
				System.out.println("TESTDB: validationSingIn else async call  table_length = " + table_length);

			}
		}
		
		return isValid;
	}

}