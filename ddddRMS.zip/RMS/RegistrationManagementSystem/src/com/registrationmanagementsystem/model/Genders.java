package com.registrationmanagementsystem.model;

public class Genders {
	String gender_name;
	String gender_value;

	public void setGenderName(String gender_name) {
		this.gender_name = gender_name;
	}

	public String getGenderName() {
		return gender_name;
	}

	public void setGenderValue(String gender_value) {
		this.gender_value = gender_value;
	}

	public String getGenderValue() {
		return gender_value;
	}
}