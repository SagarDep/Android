package com.registrationmanagementsystem;

public class NavObjectDrawerItem {
    public int icon;
    public String name;
 
    // Constructor.
    public NavObjectDrawerItem(int icon, String name) {
 
        this.icon = icon;
        this.name = name;
    }
}