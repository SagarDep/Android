package com.registrationmanagementsystem.model;

public class Region {
	String region_name;
	String region_values;
	
	public String getRegion_name() {
		return region_name;
	}
	public void setRegion_name(String region_name) {
		this.region_name = region_name;
	}
	public String getRegion_values() {
		return region_values;
	}
	public void setRegion_values(String region_values) {
		this.region_values = region_values;
	}
	

}
