package com.registrationmanagementsystem;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.registrationmanagementsystem.adapter.IndustryAdapter;
import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.IndustryDetails;

public class IndustryListingFragment extends Fragment {
	String TAG = IndustryListingFragment.class.getName();
	
	DataBaseHelper mDbHelper;

	ListView mIndustryListView;
	IndustryAdapter mIndustryAdapter;
	ArrayList<IndustryDetails> mInsutryArrayList = new ArrayList<IndustryDetails>();

	Context context;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View m_rootView = inflater.inflate(R.layout.industry_listing,
				container, false);


		mDbHelper = DataBaseHelper.getInstance(getActivity());

		context = getActivity();

		mIndustryListView = (ListView)m_rootView.findViewById(R.id.industrylist);

		new IndustryListingAsyncTask().execute();

		return m_rootView;
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			getActivity().finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public class IndustryListingAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(mInsutryArrayList!=null) {
				mInsutryArrayList.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_register_industry);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IndustryListingAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = null;
				if(Global.UASER_TYPE.equalsIgnoreCase("user")) {
					Log.i(TAG, "for user");
					result = db.rawQuery("select * from "
							+ DataBaseHelper.TABLE_register_industry + " where " +  DataBaseHelper.KEY_ri_user_email+" = '" + Global.USER_EMAIL +"'", null);
					result.moveToFirst();
					while (result.isAfterLast() == false) {
						IndustryDetails industryDetails = new IndustryDetails();
						industryDetails.setIndustryName(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_org_name)));
						industryDetails.setId((result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_industry_id))));
						industryDetails.setIndustryCode((result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_org_code))));
						
						mInsutryArrayList.add(industryDetails);
						result.moveToNext();
					}
				} else {
					Log.i(TAG, "for admin");
					result = db.rawQuery("select * from "
							+ DataBaseHelper.TABLE_register_industry, null);
					result.moveToFirst();
					while (result.isAfterLast() == false) {
						IndustryDetails industryDetails = new IndustryDetails();
						industryDetails.setIndustryName(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_org_name)));
						industryDetails.setId((result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_industry_id))));
						industryDetails.setIndustryCode((result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_org_code))));
						mInsutryArrayList.add(industryDetails);
						result.moveToNext();
					}
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			mIndustryAdapter = new IndustryAdapter(context, mInsutryArrayList);
			mIndustryListView.setAdapter(mIndustryAdapter);
		}
	}

}