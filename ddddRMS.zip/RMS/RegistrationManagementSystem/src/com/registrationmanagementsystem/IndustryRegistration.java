package com.registrationmanagementsystem;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.District;
import com.registrationmanagementsystem.model.Region;
import com.registrationmanagementsystem.model.Sector;
import com.registrationmanagementsystem.model.States;
import com.registrationmanagementsystem.model.Taluka;

public class IndustryRegistration extends ActionBarActivity{

	private static final String TAG = IndustryRegistration.class.getName();
	ImageView img_gallery;
	public static final int REQUEST_CODE_GALLERY = 0x1;
	public static final int CROP_PIC = 0x4;
	private boolean doSavePicUri = false;
	private Uri picUri;
	Uri mImageCaptureUri = null;
	private File mFileTemp;
	CompressImage compressImage;
	Context context;
	EditText etxOrgName, etxContactPerson, etxAddress, etxCity, etxPincode, etxMobile, etxLline, etxEmail,
	etxWebsite, etxNatureProd, etxManPower, etxCmpnyHelpers, etxCmpnyContWorker, etxNameLbrCont, etxAddressLbrCont,
	etxTotalManager, etxSupervisor, etxSkillWorker, etxSemiSkillWorker, etxUnskillWorker, etxTotalRequireSC;

	Spinner spState, spDistrict, spRegion, spTaluka, spSector, spEstablishment;
	String stateValue, districtValue, regionValue, talukaValue, sectorValue, establishmentValue;

	CheckBox chkActive;

	Switch swtApprentice, swtLicence, swtEstablishment;

	Button btnSubmit;

	ActionBar actionBar;

	private ArrayList<String> m_StateDisplay = new ArrayList<String>();
	private ArrayList<States> m_State = new ArrayList<States>();
	private ArrayList<String> m_DistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_District = new ArrayList<District>();
	private ArrayList<String> m_RegionDisplay = new ArrayList<String>();
	private ArrayList<Region> m_Region = new ArrayList<Region>();
	private ArrayList<String> m_TalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_Taluka = new ArrayList<Taluka>();
	private ArrayList<String> m_SectorDisplay = new ArrayList<String>();
	private ArrayList<Sector> m_Sector = new ArrayList<Sector>();

	DataBaseHelper mDbHelper;

	/*
	 * To show gujarat as defualt state in spinner
	 */
	int spinnerSetGuj;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_industryregistration);
		context = IndustryRegistration.this;
		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());

		// get action bar
		actionBar = getSupportActionBar();

		// running platform is at least Honeycomb
		actionBar.setDisplayHomeAsUpEnabled(true);

		etxOrgName = (EditText) findViewById(R.id.txtOrganizationName);
		etxContactPerson = (EditText) findViewById(R.id.txtContact);
		etxAddress = (EditText) findViewById(R.id.txtAddress);
		etxCity = (EditText) findViewById(R.id.txtcityname);
		etxPincode = (EditText) findViewById(R.id.txtpincodename);
		etxMobile = (EditText) findViewById(R.id.txtMobname);
		etxLline = (EditText) findViewById(R.id.txtlandlinename);
		etxEmail = (EditText) findViewById(R.id.txtEmail);
		etxWebsite = (EditText) findViewById(R.id.txtWebsite);
		etxManPower = (EditText) findViewById(R.id.txtManPower);

		img_gallery = (ImageView)findViewById(R.id.list_image);
		spState = (Spinner) findViewById(R.id.spsname);
		spDistrict = (Spinner) findViewById(R.id.spdname);
		spRegion = (Spinner) findViewById(R.id.sprname);
		spTaluka = (Spinner) findViewById(R.id.sptalukaname);
		spSector = (Spinner) findViewById(R.id.spSector);

		btnSubmit = (Button) findViewById(R.id.btnSubmit);


		/***
		 * Newly Added parameters
		 */
		etxWebsite= (EditText) findViewById(R.id.txtWebsite);
		etxNatureProd = (EditText) findViewById(R.id.txtNatureofProduct);
		etxCmpnyHelpers= (EditText) findViewById(R.id.txtCompanyHelpers);
		etxCmpnyContWorker= (EditText) findViewById(R.id.txtCompanycontractual);
		etxNameLbrCont= (EditText) findViewById(R.id.txtLabourContractor);
		etxAddressLbrCont= (EditText) findViewById(R.id.txtAddressLabour);
		etxTotalManager= (EditText) findViewById(R.id.txttotalmanager);
		etxSupervisor= (EditText) findViewById(R.id.txtsupervisor);
		etxSkillWorker= (EditText) findViewById(R.id.txtskilledworkers);
		etxSemiSkillWorker= (EditText) findViewById(R.id.txtsemiskilledworkers);
		etxUnskillWorker= (EditText) findViewById(R.id.txtunskilledworkersSS);
		etxTotalRequireSC= (EditText) findViewById(R.id.txttotalnosofpersonskillcertification);
		spEstablishment = (Spinner) findViewById(R.id.spEstablishment);
		chkActive = (CheckBox) findViewById(R.id.ch_Activity);

		swtApprentice = (Switch) findViewById(R.id.ch_Apprentice);
		swtLicence = (Switch) findViewById(R.id.ch_havinglicense);
		swtEstablishment= (Switch) findViewById(R.id.ch_establishmentskillcertification);


		new StateAsyncTask().execute();
		new SectorAsyncTask().execute();

		spState.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Log.e(TAG, "spState onItemSelected");
				setDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Log.e(TAG, "spDistrict onItemSelected");
				setTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				insertIndustryData();
			}
		});


		img_gallery.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				selectImage();

			}
		});

	}


	/*
	 * For image
	 */

	private void selectImage() {

		doSavePicUri = false;
		setImageFile();

		// final CharSequence[] options = { "Take Photo",
		// "Choose from Gallery","Cancel" };
		final CharSequence[] options = { "Take Photo From Gallery","File Explorer", "Cancel" };
		final String dir = Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)+ "/picFolder/";
		File newdir = new File(dir);
		newdir.mkdirs();
		AlertDialog.Builder builder = new AlertDialog.Builder(
				IndustryRegistration.this);
		if(builder !=null)
		{

			builder.setTitle("Add Photo!");
			builder.setItems(options, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int item) {
					if (options[item].equals("Take Photo From Gallery")) {
						takePicture();
						
					} 
					else if (options[item].equals("File Explorer")) {
						takefromexplorer();
						
					} else if (options[item].equals("Cancel")) {
						mFileTemp = null;
						dialog.dismiss();
					}
				}
			});

			builder.show();
		}
		else
		{
			builder =  null;
		}
	}


	public void setImageFile() {
		/*
		 * // Store image in dcim // File file = new
		 * File(Environment.getExternalStorageDirectory() + "/DCIM/", "image" +
		 * new Date().getTime() + ".jpg"); File file = new
		 * File(Environment.getExternalStoragePublicDirectory
		 * (Environment.DIRECTORY_DCIM) + "/picFolder/"+ new Date().getTime() +
		 * ".jpg"); Uri imgUri = Uri.fromFile(file); this.ImagePath =
		 * file.getAbsolutePath();
		 * 
		 * System.out.println("ImagePath"+ImagePath); return imgUri;
		 */

		this.mFileTemp = new File(
				Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)	+ "/picFolder/" + new Date().getTime() + ".jpg");
		System.out.println("mFileTemp = " + mFileTemp);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK) {
			return;
		}
		Bitmap bitmap;
		doSavePicUri = true;
		switch (requestCode) {

		case REQUEST_CODE_GALLERY:
			try {
				picUri = data.getData();
				InputStream inputStream = getContentResolver().openInputStream(
						data.getData());

				FileOutputStream fileOutputStream = new FileOutputStream(
						mFileTemp);
				copyStream(inputStream, fileOutputStream);
				fileOutputStream.close();
				inputStream.close();
				compressImage = new CompressImage(context, mFileTemp);
				bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
				img_gallery.setImageBitmap(bitmap);
				// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
//				performCrop();

				/*compressImage = new CompressImage(context, mFileTemp);

				bitmap = compressImage.compressImage(mFileTemp.getPath());

				img_gallery.setImageBitmap(bitmap);*/

				/*	// Getting LocationManager object from System Service LOCATION_SERVICE
				LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

				// Creating a criteria object to retrieve provider
				Criteria criteria = new Criteria();

				// Getting the name of the best provider
				String provider = locationManager.getBestProvider(criteria, true);

				// Getting Current Location
				location = locationManager.getLastKnownLocation(provider);

				if(location!=null){
					if(gps.canGetLocation()){
				if(location!=null)
				{
					if(gps.canGetLocation())
					{
						getExif();
					}
					else
					{
						gps.showSettingsAlert();
					}
				}
				 */


			} catch (Exception e) {

				Log.e(TAG, "Error while creating temp file", e);
			}

			break;
		case CROP_PIC:
			// get the returned data
			// get the cropped bitmap
			Bundle extras = data.getExtras();
			// get the cropped bitmap
			Bitmap thePic = extras.getParcelable("data");
			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			img_gallery.setImageBitmap(thePic);
			break;
			/*case REQUEST_CODE_TAKE_PICTURE:
			// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
			picUri = Uri.fromFile(mFileTemp);
			getExif();
			performCrop();
			//			 picUri = data.getData();

			 *//**
			 * Commented of compress image
			 *//*
			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(bitmap);

			break;
		case REQUEST_CODE_CROP_IMAGE:


			  * String path = data.getStringExtra(CropImage.IMAGE_PATH); if (path
			  * == null) {
			  * 
			  * return; }

			// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());

			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(bitmap);
			break;

		case CROP_PIC:
			// get the returned data
			// get the cropped bitmap
			Bundle extras = data.getExtras();
			// get the cropped bitmap
			Bitmap thePic = extras.getParcelable("data");
				compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(thePic);
			break;*/
			
			
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * this function does the crop operation.
	 */
	private void performCrop() {
		// take care of exceptions
		try {
			// call the standard crop action intent (the user device may not
			// support it)
			Intent cropIntent = new Intent("com.android.camera.action.CROP");
			// indicate image type and Uri
			cropIntent.setDataAndType(picUri, "image/*");
			// set crop properties
			cropIntent.putExtra("crop", "true");
			// indicate aspect of desired crop
			/*	cropIntent.putExtra("aspectX", 2);
			cropIntent.putExtra("aspectY", 1);*/
			// indicate output X and Y
			cropIntent.putExtra("outputX", 200);
			cropIntent.putExtra("outputY", 150);
			// retrieve data on return
			cropIntent.putExtra("return-data", true);
			// start the activity - we handle returning in onActivityResult

			cropIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			cropIntent.putExtra("return-data", true);

			startActivityForResult(cropIntent, CROP_PIC);
		}

		// respond to users whose devices do not support the crop action
		catch (ActivityNotFoundException anfe) {
			Toast toast = Toast
					.makeText(this, "This device doesn't support the crop action!", Toast.LENGTH_SHORT);
			toast.show();
		}
	}
	public static void copyStream(InputStream input, OutputStream output)
			throws IOException {

		byte[] buffer = new byte[1024];
		int bytesRead;
		while ((bytesRead = input.read(buffer)) != -1) {
			output.write(buffer, 0, bytesRead);
		}
	}

	private void takePicture() {

		Intent intent = new Intent(Intent.ACTION_PICK);

		try {
			//			Uri mImageCaptureUri = null;
			String state = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				mImageCaptureUri = Uri.fromFile(mFileTemp);
			} else {
				/*
				 * The solution is taken from here:
				 * http://stackoverflow.com/questions
				 * /10042695/how-to-get-camera-result-as-a-uri-in-data-folder
				 */
				mImageCaptureUri = InternalStorageContentProvider.CONTENT_URI;
			}
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			intent.setType("image/*");
			intent.putExtra("return-data", true);
			startActivityForResult(intent, REQUEST_CODE_GALLERY);
		} catch (ActivityNotFoundException e) {

			Log.d(TAG, "cannot take picture", e);
		}
	}
	
	

	private void takefromexplorer() {

		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

		try {
			//			Uri mImageCaptureUri = null;
			String state = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				mImageCaptureUri = Uri.fromFile(mFileTemp);
			} else {
				/*
				 * The solution is taken from here:
				 * http://stackoverflow.com/questions
				 * /10042695/how-to-get-camera-result-as-a-uri-in-data-folder
				 */
				mImageCaptureUri = InternalStorageContentProvider.CONTENT_URI;
			}
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			intent.setType("gagt/sdf");
			intent.putExtra("return-data", true);
//			startActivityForResult(intent, REQUEST_CODE_GALLERY);
		} catch (ActivityNotFoundException e) {

			Log.d(TAG, "cannot take picture", e);
		}
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public class StateAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_State);
			if (table_length > 0) {
				System.out
				.println("TESTDB: StateAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_State, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					States states = new States();
					states.setStateName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					states.setStateValues(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_value)));
					m_StateDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					m_State.add(states);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}
			//
			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> stateAdapter = new ArrayAdapter<String>(
					IndustryRegistration.this,
					android.R.layout.simple_spinner_item, m_StateDisplay);
			// set the view for the Drop down list
			stateAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spState.setAdapter(stateAdapter);

			spinnerSetGuj = stateAdapter.getPosition("Gujarat");
			spState.setSelection(spinnerSetGuj);
		}
	}

	public class DistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DistrictAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_DistrictDisplay!=null) {
					m_DistrictDisplay.clear();
				}
				if(m_District!=null) {
					m_District.clear();
				}

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_state_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_state_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_DistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_District.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					IndustryRegistration.this,
					android.R.layout.simple_spinner_item, m_DistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDistrict.setAdapter(districtAdapter);
		}
	}


	public class TalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: TalukaAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_TalukaDisplay!=null) {
					m_TalukaDisplay.clear();
				}
				if(m_Taluka!=null) {
					m_Taluka.clear();
				}
				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_TalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_Taluka.add(taluka);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					IndustryRegistration.this,
					android.R.layout.simple_spinner_item, m_TalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spTaluka.setAdapter(talukaAdapter);
		}
	}

	public class RegionAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Region);
			if (table_length > 0) {
				System.out
				.println("TESTDB: RegionAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_RegionDisplay!=null) {
					m_RegionDisplay.clear();
				}
				if(m_Region!=null) {
					m_Region.clear();
				}
				Log.e(TAG, "arg0[0] = " + arg0[0]);
				//				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Region, null);
				//				Cursor result = db.rawQuery("select * from "
				//						+ DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_value + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_value + " = '" + arg0[0]+"'", null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Region region = new Region();
					region.setRegion_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value)));
					region.setRegion_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_RegionDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_Region.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> regionAdapter = new ArrayAdapter<String>(
					IndustryRegistration.this,
					android.R.layout.simple_spinner_item, m_RegionDisplay);
			// set the view for the Drop down list
			regionAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spRegion.setAdapter(regionAdapter);
		}
	}

	public class SectorAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Sector);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SectorAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_SectorDisplay!=null) {
					m_SectorDisplay.clear();
				}
				if(m_Sector!=null) {
					m_Sector.clear();
				}
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Sector, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Sector region = new Sector();
					region.setSector_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_value)));
					region.setSector_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_name)));
					m_SectorDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_name)));
					m_Sector.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> sectorAdapter = new ArrayAdapter<String>(
					IndustryRegistration.this,
					android.R.layout.simple_spinner_item, m_SectorDisplay);
			// set the view for the Drop down list
			sectorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSector.setAdapter(sectorAdapter);
		}
	}

	private void setDistrict() {
		String tmpSataeName = spState.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_State + " where " + DataBaseHelper.KEY_state_name + " = '" + tmpSataeName +"'" , null);
		result.moveToFirst();
		String tmpStateId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_state_value));

		if(!result.isClosed()) {
			result.close();				
		}
		new DistrictAsyncTask().execute(tmpStateId); 			
	}

	private void setTaluka() {
		String tmpDistrictName = spDistrict.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
		result.moveToFirst();
		String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));
		String regionId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_region_id));

		if(!result.isClosed()) {
			result.close();				
		}
		new RegionAsyncTask().execute(regionId); 			
		new TalukaAsyncTask().execute(tmpDistrictId); 			
	}

	/*
	 * Insert data of industry
	 */
	private void insertIndustryData() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		/*
		 * mandatory fields
		 */
		if (etxOrgName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_org_name);
			isInsertInDb = false;
		}
		if (etxContactPerson.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_person);
			isInsertInDb = false;
		}
		if (etxAddress.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_address);
			isInsertInDb = false;
		}
		if (spState.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_state);
			isInsertInDb = false;
		}
		if (spDistrict.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_district);
			isInsertInDb = false;
		}
		if (spRegion.getSelectedItem().toString().equalsIgnoreCase("Please Select")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_region);
			isInsertInDb = false;
		}
		if (spTaluka.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_taluka);
			isInsertInDb = false;
		}
		if (etxCity.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_city);
			isInsertInDb = false;
		}
		if (etxMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mobno);
			isInsertInDb = false;
		} else if(etxMobile.getText().toString().length()<10) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_mobno);
			isInsertInDb = false;			
		}
		/*		if (spSector.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_sector);
			isInsertInDb = false;
		}*/
		if (etxPincode.getText().toString().equalsIgnoreCase("") == false && etxPincode.getText().toString().length()<6) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_pinno);
			isInsertInDb = false;			
		}
		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_email);
			isInsertInDb = false;			
		}
		if (etxManPower.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_manpower);
			isInsertInDb = false;
		}

		/*
		 * Non-mandatory fields
		 */
		if (isInsertInDb) {
			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// db.beginTransaction();
			System.out.println("Insert in db");
			// Insert in db
			ContentValues contentValues = new ContentValues();

			/*
			 * Mandatory fields
			 */
			contentValues.put(DataBaseHelper.KEY_ri_org_name, etxOrgName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_address, etxAddress
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_city, etxCity.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ri_pincode, etxPincode.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ri_mobileno, etxMobile.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ri_lline, etxLline.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ri_email, etxEmail.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ri_city, etxCity.getText()
					.toString());

			getSpinnerIds();

			contentValues.put(DataBaseHelper.KEY_ri_state_name, spState.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_state_value, stateValue);
			contentValues.put(DataBaseHelper.KEY_ri_district_name, spDistrict.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_district_value, districtValue);
			contentValues.put(DataBaseHelper.KEY_ri_region_name, spRegion.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_region_value, regionValue);
			contentValues.put(DataBaseHelper.KEY_ri_taluka_name, spTaluka.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_taluka_value, talukaValue);
			contentValues.put(DataBaseHelper.KEY_ri_sector_name, spSector.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_sector_value, sectorValue);


			/***
			 * TODO
			 */
			//			if (mFileTemp != null) {
			//				contentValues.put(DataBaseHelper.KEY_image_path,
			//						mFileTemp.toString());
			//			}


			db.insert(DataBaseHelper.TABLE_register_industry, null, contentValues);

			etxOrgName.setText("");
			etxContactPerson.setText("");
			etxAddress.setText("");
			etxCity.setText("");
			etxPincode.setText("");
			etxMobile.setText("");
			etxLline.setText("");
			etxEmail.setText("");
			etxManPower.setText("");

			Global.showAlertDialog(IndustryRegistration.this, "Profile :",
					"Inserted Successfully", false);

			spState.setSelection(0);
			spSector.setSelection(0);
		} else {
			System.out.println("alert");
			Global.showAlertDialog(IndustryRegistration.this,
					"Mandatory fields", errorMessage, false);
		}
	}


	private void getSpinnerIds() {
		stateValue = m_State.get(spState.getSelectedItemPosition()).getStateValues();
		districtValue = m_District.get(spDistrict.getSelectedItemPosition()).getDistrictValue();
		regionValue = m_Region.get(spRegion.getSelectedItemPosition()).getRegion_values();
		talukaValue = m_Taluka.get(spTaluka.getSelectedItemPosition()).getTaluka_values();
		sectorValue = m_Sector.get(spSector.getSelectedItemPosition()).getSector_values();
	}
}
