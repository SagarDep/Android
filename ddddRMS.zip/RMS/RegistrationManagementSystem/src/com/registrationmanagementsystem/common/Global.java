package com.registrationmanagementsystem.common;

import java.util.regex.Pattern;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.util.Log;

import com.registrationmanagementsystem.GPSTracker;
import com.registrationmanagementsystem.MainHomeActivity;
import com.registrationmanagementsystem.SignInActivity;
import com.registrationmanagementsystem.SplashScreenActivity;

public class Global {

	private static final String TAG = Global.class.getName();

	public static final String RMS_Pref = "RMSPref";

	public static boolean isRegistrar;
	public static String UASER_TYPE = null;
	public static String USER_EMAIL = null;

	static SharedPreferences pref;
	static GPSTracker gps;


	public Global(Context context) {
		pref = context.getApplicationContext().getSharedPreferences(RMS_Pref, 0); // 0 - for private mode
		UASER_TYPE = pref.getString("userType", null);
		USER_EMAIL = pref.getString("userEmail", null);
	}

	/**
	 * Function to display simple Alert Dialog
	 * @param context - application context
	 * @param title - alert dialog title
	 * @param message - alert message
	 * @param status - success/failure (used to set icon)
	 * */
	public static void showAlertDialog(Context context, String title, String message, Boolean status) {
		AlertDialog alertDialog = new AlertDialog.Builder(context).create();

		// Setting Dialog Title
		alertDialog.setTitle(title);

		// Setting Dialog Message
		alertDialog.setMessage(message);

		// Setting alert dialog icon
		//        alertDialog.setIcon((status) ? R.drawable.success : R.drawable.fail);

		// Setting OK Button
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {


			}
		});

		// Showing Alert Message
		alertDialog.show();
	}

	/*	public final static boolean isValidEmail(CharSequence target) {
		if (target == null) {
			return false;
		} else {
			return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
		}
	}*/

	public final static Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
			"^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
					+ "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
					+ "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
					+ "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
					+ "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
					+ "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$");
	//add this method:


	public static boolean checkEmail(String email) 
	{
		return EMAIL_ADDRESS_PATTERN.matcher(email).matches();
	}

	/*
	 * Default value of lat long
	 */

	public static void saveDefaultLatLng(Context context) {
		try {
			pref = context.getApplicationContext().getSharedPreferences(Global.RMS_Pref, 0); // 0 - for private mode
			if(pref.getString("lat", null)== null) { 
				Log.e(TAG, "Need to save");	

				gps = new GPSTracker(context);
				if(gps.canGetLocation())
				{
					Log.e(TAG, "testgps: if gps.canGetLocation()" + gps.canGetLocation());
					Location defaultLocation = gps.getLocation();
					Editor editor = pref.edit();
					Log.e(TAG, "testgps: if defaultLocation.getLatitude(); " + defaultLocation.getLatitude());
					Log.e(TAG, "testgps: if defaultLocation.getLongitude(); " + defaultLocation.getLongitude());
					editor.putString("lat", Double.toString(defaultLocation.getLatitude()));
					editor.putString("lng", Double.toString(defaultLocation.getLongitude()));
					editor.commit();
				} else	{
					Log.e(TAG, "testgps: else gps.canGetLocation()" + gps.canGetLocation());
					gps.showSettingsAlert();
				}
			} else {
				Log.e(TAG, "No need to save");	
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}


	/*
	 * Get latitude
	 */
	public static String getLat(Context context) {
		String Lat = null;
		try {
			pref = context.getApplicationContext().getSharedPreferences(Global.RMS_Pref, 0); // 0 - for private mode
			Lat = pref.getString("lat", null);
			Log.e(TAG, "Lat = " + Lat);	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return Lat;
	}

	/*
	 * Get Longitude
	 */
	public static String getLng(Context context) {
		String Lng = null;
		try {
			pref = context.getApplicationContext().getSharedPreferences(Global.RMS_Pref, 0); // 0 - for private mode
			Lng = pref.getString("lng", null);
			Log.e(TAG, "Lng = " + Lng);	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return Lng;
	}

	/*
	 * Registrar login logic
	 */
	public static void userAdminLogin(Context context, String userType, String userEmail) {
		try {
			UASER_TYPE = userType;
			USER_EMAIL = userEmail;
			pref = context.getApplicationContext().getSharedPreferences(RMS_Pref, 0); // 0 - for private mode
			Editor editor = pref.edit();
			editor.putString("userType", userType);
			editor.putString("userEmail", userEmail);
			editor.commit();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public static void logOut(Context context){
		SharedPreferences preferences = context.getApplicationContext().getSharedPreferences(Global.RMS_Pref,
				Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.clear();
		editor.commit();
		Intent m_intent = new Intent(context,
				SignInActivity.class);
		m_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
		Activity mActivity = (Activity) context;
		mActivity.startActivity(m_intent);
		mActivity.finish();

		/*			SharedPreferences preferences = getSharedPreferences(Global.RMS_Pref,
							Context.MODE_PRIVATE);
					SharedPreferences.Editor editor = preferences.edit();
					editor.clear();
					editor.commit();
					Intent m_intent = new Intent(MainHomeActivity.this,
							SignInActivity.class);
					m_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(m_intent);
					finish();*/
	}
}
