package com.registrationmanagementsystem;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.Dialog;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.registrationmanagementsystem.database.DataBaseHelper;

public class GPSLocationActivity extends FragmentActivity implements LocationListener {

	GoogleMap googleMap;
	GPSTracker gps;
	String address,city,country;
	MarkerOptions markerOptions;
	double latitude;
	double longitude;
	LocationManager locationManager;
	public Bundle getBundle = null;
	public String position;
	String _id;
	DataBaseHelper mDbHelper;
	Location location;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);


		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());
		getBundle = this.getIntent().getExtras();
		// Getting Google Play availability status
		int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getBaseContext());
		gps = new GPSTracker(GPSLocationActivity.this);

		if (getBundle != null) {
			position = getBundle.getString("position");

			_id = getBundle.getString(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID);
			System.out.println("PositionLocation"+position);
			System.out.println("_idLocation"+_id);

		}
		SQLiteDatabase db = mDbHelper.getReadableDatabase();
		Cursor result = null;
		long table_length = DatabaseUtils.queryNumEntries(db,
				DataBaseHelper.TABLE_APPLICANT_MASTER);
		if (table_length > 0) {
			System.out
			.println("TESTDB: CasteAsyncTask if - read from table table_length = "
					+ table_length);
			// Cursor result = db.rawQuery("select * from "
			// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
			result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_APPLICANT_MASTER + " where REF_ID = "+ _id, null);
			if (result != null) {
				result.moveToFirst();

				if(latitude !=0.0 && longitude != 0.0)
				{
				latitude = Double.valueOf(result.getString(result.getColumnIndex(DataBaseHelper.KEY_LATTITUDE)));
				longitude = Double.valueOf(result.getString(result.getColumnIndex(DataBaseHelper.KEY_LONGITUDE)));
				System.out.println("latitude"+latitude);
				System.out.println("longitude"+longitude);
				}
				else
				{
					/*23.0100944,72.5094841*/
					latitude = 23.0100944;
					longitude = 72.5094841;
					
				}
			}

		}


		// Showing status
		if(status!=ConnectionResult.SUCCESS)
		{ // Google Play Services are not available
			int requestCode = 10;
			Dialog dialog = GooglePlayServicesUtil.getErrorDialog(status, this, requestCode);
			dialog.show();

		}

		else 
		{	// Google Play Services are available	

			// Getting reference to the SupportMapFragment of activity_main.xml
			SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

			// Getting GoogleMap object from the fragment
			googleMap = fm.getMap();
			// Enabling MyLocation Layer of Google Map
			googleMap.setMyLocationEnabled(true);				
			googleMap.setBuildingsEnabled(true);

			// Getting LocationManager object from System Service LOCATION_SERVICE
			locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

			// Creating a criteria object to retrieve provider
			Criteria criteria = new Criteria();

			// Getting the name of the best provider
			String provider = locationManager.getBestProvider(criteria, true);

			// Getting Current Location
			location = locationManager.getLastKnownLocation(provider);

			if(location!=null)
			{
				if(gps.canGetLocation())
				{
					//					onLocationChanged(location);
					googleMap.setOnMyLocationChangeListener(myLocationChangeListener);
				}
				else
				{
					gps.showSettingsAlert();
				}
			}

			//			locationManager.requestLocationUpdates(provider, 20000, 0, this);
		}

	}


	@Override
	protected void onResume() {

		if(location!=null)
		{

			//				onLocationChanged(location);
			System.out.println(("Latitude:" +  latitude  + ", Longitude:"+ longitude ));		
			googleMap.setOnMyLocationChangeListener(myLocationChangeListener);
		}
		else
		{
			gps.showSettingsAlert();
			System.out.println("OnResume");
		}


		super.onResume();
	}





	@Override
	public void onLocationChanged(Location location) {

		TextView tvLocation = (TextView) findViewById(R.id.tv_location);

		// Getting latitude of the current location
		//		latitude = location.getLatitude();
		//				latitude =  23.010602409;
		//		latitude = Double.valueOf(mUserList.get(Integer.valueOf(_id)).getLattitude().toString());

		// Getting longitude of the current location
		//		longitude = location.getLongitude();
		//				longitude = 72.5042675;
		//		longitude = Double.valueOf(mUserList.get(Integer.valueOf(_id)).getLongitude().toString());



		// Creating a LatLng object for the current location
		//		LatLng latLng = new LatLng(latitude, longitude);
		LatLng latLng = new LatLng(latitude, longitude);
		// Showing the current location in Google Map
		googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

		// Zoom in the Google Map
		googleMap.animateCamera(CameraUpdateFactory.zoomTo(15));		

		// Setting latitude and longitude in the TextView tv_location
		tvLocation.setText("Latitude:" +  latitude  + ", Longitude:"+ longitude );		
		//		LatLng coordinate = new LatLng(latitude, longitude);
		//		LatLng coordinate = new LatLng(23.010602409, 72.5042675);

		//		Toast.makeText(this, "Location " + latLng.latitude+","+latLng.longitude,Toast.LENGTH_LONG).show();
		// Creating a marker
		markerOptions = new MarkerOptions();

		/**
		 * Geocoder to find address country city name from the given lattitude and longitude 
		 */
		Geocoder geocoder = new Geocoder(GPSLocationActivity.this, Locale.getDefault());
		try {
			if(latitude == 0.0 && longitude == 0.0 )
			{
				// Creating a criteria object to retrieve provider
				Criteria criteria = new Criteria();

				// Getting the name of the best provider
				String provider = locationManager.getBestProvider(criteria, true);

				// Getting Current Location
				location = locationManager.getLastKnownLocation(provider);
				
				System.out.println("location.getLatitude()"+location.getLatitude());
				System.out.println("location.getLongitude()"+location.getLongitude());
				latitude =location.getLatitude();
				longitude =location.getLongitude();

			}
			if(latitude != 0.0 && longitude != 0.0 )
			{
			//						List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
			List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
			address = addresses.get(0).getAddressLine(0);
			city = addresses.get(0).getAddressLine(1);
			country = addresses.get(0).getAddressLine(2);

			System.out.println("address"+address);
			System.out.println("city"+city);
			System.out.println("country"+country);
			System.out.println(addresses);
			markerOptions.title("Location");
			markerOptions.snippet(address + city + country);
			}
			else
			{
			
					/*23.0100944,72.5094841*/
					latitude = 23.0100944;
					longitude = 72.5094841;
					List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
					address = addresses.get(0).getAddressLine(0);
					city = addresses.get(0).getAddressLine(1);
					country = addresses.get(0).getAddressLine(2);

					System.out.println("address"+address);
					System.out.println("city"+city);
					System.out.println("country"+country);
					System.out.println(addresses);
					markerOptions.title("Location");
					markerOptions.snippet(address + city + country);
					
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Setting the position for the marker
		markerOptions.position(latLng);
		// Placing a marker on the touched position
		googleMap.addMarker(markerOptions);

		//	googleMap.addMarker(new MarkerOptions().position(coordinate).title("Location").snippet(address+city+country).icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_marker)));*/
	}


	private GoogleMap.OnMyLocationChangeListener myLocationChangeListener = new GoogleMap.OnMyLocationChangeListener() {
		@Override
		public void onMyLocationChange(Location location) {
			LatLng loc = new LatLng(latitude, longitude);
			TextView tvLocation = (TextView) findViewById(R.id.tv_location);
			tvLocation.setText("Latitude:" +  latitude  + ", Longitude:"+ longitude );		
			markerOptions = new MarkerOptions();
			// Setting the position for the marker
			//			markerOptions.anchor(0.0f, 1.0f);
			markerOptions.position(loc);


			if(googleMap != null){
				googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 16.0f));

				/**
				 * Geocoder to find address country city name from the given lattitude and longitude 
				 */
				Geocoder geocoder = new Geocoder(GPSLocationActivity.this, Locale.getDefault());
				try {
					
					if(latitude != 0.0 && longitude != 0.0 )
					{
					//						List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
					List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
					address = addresses.get(0).getAddressLine(0);
					city = addresses.get(0).getAddressLine(1);
					country = addresses.get(0).getAddressLine(2);

					System.out.println("address"+address);
					System.out.println("city"+city);
					System.out.println("country"+country);
					System.out.println(addresses);

					markerOptions.title("Location");
					markerOptions.snippet(address + city + country);
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			googleMap.addMarker(markerOptions);
		}
	};
	@Override
	public void onProviderDisabled(String provider) {
	}

	@Override
	public void onProviderEnabled(String provider) {
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}