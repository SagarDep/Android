package com.registrationmanagementsystem.model;

public class IkvkBatch {
	String batch_name;
	String batch_value;
	
	public String getBatch_name() {
		return batch_name;
	}
	public void setBatch_name(String batch_name) {
		this.batch_name = batch_name;
	}
	public String getBatch_value() {
		return batch_value;
	}
	public void setBatch_value(String batch_value) {
		this.batch_value = batch_value;
	}
}
