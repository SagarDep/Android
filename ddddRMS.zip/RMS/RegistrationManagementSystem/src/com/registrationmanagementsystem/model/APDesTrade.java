package com.registrationmanagementsystem.model;

public class APDesTrade {
	String TRADE_ID;
	String TRADE_NAME_E;
	
	public String getTRADE_ID() {
		return TRADE_ID;
	}
	public void setTRADE_ID(String tRADE_ID) {
		TRADE_ID = tRADE_ID;
	}
	public String getTRADE_NAME_E() {
		return TRADE_NAME_E;
	}
	public void setTRADE_NAME_E(String tRADE_NAME_E) {
		TRADE_NAME_E = tRADE_NAME_E;
	}
	
	
}
