package com.registrationmanagementsystem;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.Designation;
import com.registrationmanagementsystem.model.District;
import com.registrationmanagementsystem.model.Establishment;
import com.registrationmanagementsystem.model.Region;
import com.registrationmanagementsystem.model.Sector;
import com.registrationmanagementsystem.model.States;
import com.registrationmanagementsystem.model.Taluka;

public class IndustryRegistrationFragment extends Fragment {

	private static final String TAG = IndustryRegistrationFragment.class.getName();

	ImageView img_gallery;
	public static final int REQUEST_CODE_GALLERY = 0x1;
	public static final int CROP_PIC = 0x4;
	private boolean doSavePicUri = false;
	private Uri picUri;
	Uri mImageCaptureUri = null;
	private File mFileTemp;
	CompressImage compressImage;
	Context context;
	TextView txtTotalRequireSC;

	EditText etxOrgCode, etxOrgName, etxAddress, etxCity, etxPincode, etxMobile, etxLline, etxEmail,
	etxWebsite, etxNatureProd, etxContactName, etxContactMobile, etxContactEmail, etxCmpnyHelpers, etxCmpnyContWorker, etxNameLbrCont, etxAddressLbrCont,
	etxTotalManager, etxSupervisor, etxSkillWorker, etxSemiSkillWorker, etxUnskillWorker, etxTotalRequireSC;

	Spinner spState, spDistrict, spRegion, spTaluka, spSector, spEstablishment, spContactDesignation;
	String stateValue, districtValue, regionValue, talukaValue, sectorValue, establishmentValue, contactDesignationVale;

	CheckBox chkActive;

	Switch swtApprentice, swtLicence, swtEstablishment;

	Button btnSubmit;

	ActionBar actionBar;

	private ArrayList<String> m_StateDisplay = new ArrayList<String>();
	private ArrayList<States> m_State = new ArrayList<States>();
	private ArrayList<String> m_DistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_District = new ArrayList<District>();
	private ArrayList<String> m_RegionDisplay = new ArrayList<String>();
	private ArrayList<Region> m_Region = new ArrayList<Region>();
	private ArrayList<String> m_TalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_Taluka = new ArrayList<Taluka>();
	private ArrayList<String> m_SectorDisplay = new ArrayList<String>();
	private ArrayList<Sector> m_Sector = new ArrayList<Sector>();
	private ArrayList<String> m_EstablishmentDisplay = new ArrayList<String>();
	private ArrayList<Establishment> m_Establishment = new ArrayList<Establishment>();
	private ArrayList<String> m_DesignationDisplay = new ArrayList<String>();
	private ArrayList<Designation> m_Designation = new ArrayList<Designation>();

	DataBaseHelper mDbHelper;
	/*
	 * To show gujarat as defualt state in spinner
	 */
	int spinnerSetGuj;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View m_rootView = inflater.inflate(R.layout.activity_industryregistration,
				container, false);

		doSavePicUri = false;

		context = getActivity();
		mDbHelper = DataBaseHelper.getInstance(getActivity());

		etxOrgCode = (EditText)m_rootView.findViewById(R.id.txtOrganizationCode);
		etxOrgName = (EditText)m_rootView.findViewById(R.id.txtOrganizationName);
		etxAddress = (EditText)m_rootView.findViewById(R.id.txtAddress);
		etxAddress.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (v.getId() == R.id.txtAddress) {
					v.getParent().requestDisallowInterceptTouchEvent(true);
					switch (event.getAction() & MotionEvent.ACTION_MASK) {
					case MotionEvent.ACTION_UP:
						v.getParent().requestDisallowInterceptTouchEvent(false);
						break;
					}
				}
				return false;
			}
		});

		etxCity = (EditText)m_rootView.findViewById(R.id.txtcityname);
		etxPincode = (EditText)m_rootView. findViewById(R.id.txtpincodename);
		etxMobile = (EditText)m_rootView. findViewById(R.id.txtMobname);
		etxLline = (EditText)m_rootView. findViewById(R.id.txtlandlinename);
		etxEmail = (EditText)m_rootView. findViewById(R.id.txtEmail);

		img_gallery = (ImageView)m_rootView.findViewById(R.id.list_image);
		spState = (Spinner)m_rootView. findViewById(R.id.spsname);
		spDistrict = (Spinner)m_rootView. findViewById(R.id.spdname);
		spRegion = (Spinner)m_rootView. findViewById(R.id.sprname);
		spTaluka = (Spinner)m_rootView. findViewById(R.id.sptalukaname);
		spSector = (Spinner)m_rootView. findViewById(R.id.spSector);
		spEstablishment = (Spinner)m_rootView. findViewById(R.id.spEstablishment);
//		spDesignation = (Spinner) m_rootView. findViewById(R.id.spDesignation);
		spContactDesignation = (Spinner) m_rootView. findViewById(R.id.spODesignation);

		btnSubmit = (Button)m_rootView. findViewById(R.id.btnSubmit);


		/***
		 * Newly Added parameters
		 */
		etxWebsite= (EditText)m_rootView.findViewById(R.id.txtWebsite);
		etxNatureProd = (EditText)m_rootView.findViewById(R.id.txtNatureofProduct);
		etxContactName = (EditText)m_rootView.findViewById(R.id.txtOContact);
		etxContactMobile = (EditText)m_rootView.findViewById(R.id.txtOMobname);
		etxContactEmail = (EditText)m_rootView.findViewById(R.id.txtOEmail);
		etxCmpnyHelpers= (EditText)m_rootView.findViewById(R.id.txtCompanyHelpers);
		etxCmpnyContWorker= (EditText)m_rootView. findViewById(R.id.txtCompanycontractual);
		etxNameLbrCont= (EditText)m_rootView.findViewById(R.id.txtLabourContractor);
		etxAddressLbrCont= (EditText)m_rootView.findViewById(R.id.txtAddressLabour);
		etxTotalManager= (EditText)m_rootView.findViewById(R.id.txttotalmanager);
		etxSupervisor= (EditText)m_rootView.findViewById(R.id.txtsupervisor);
		etxSkillWorker= (EditText)m_rootView. findViewById(R.id.txtskilledworkers);
		etxSemiSkillWorker= (EditText)m_rootView. findViewById(R.id.txtsemiskilledworkers);
		etxUnskillWorker= (EditText)m_rootView.findViewById(R.id.txtunskilledworkersSS);
		etxTotalRequireSC= (EditText)m_rootView.findViewById(R.id.txttotalnosofpersonskillcertification);
		txtTotalRequireSC= (TextView)m_rootView.findViewById(R.id.tvtotalnosofpersonskillcertification);

		chkActive = (CheckBox)m_rootView. findViewById(R.id.ch_Activity);

		swtApprentice = (Switch)m_rootView.findViewById(R.id.ch_Apprentice);
		swtLicence = (Switch)m_rootView.findViewById(R.id.ch_havinglicense);
		swtEstablishment= (Switch)m_rootView.findViewById(R.id.ch_establishmentskillcertification);


		new StateAsyncTask().execute();
		new SectorAsyncTask().execute();
		new EstablishmentAsyncTask().execute();
		new DesignationAsyncTask().execute();

		spState.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spDistrict onItemSelected");
				setTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				insertIndustryData();
			}
		});


		img_gallery.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				selectImage();

			}
		});

		swtEstablishment.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked) {
					etxTotalRequireSC.setVisibility(View.VISIBLE);
					txtTotalRequireSC.setVisibility(View.VISIBLE);
				} else {
					etxTotalRequireSC.setVisibility(View.GONE);
					txtTotalRequireSC.setVisibility(View.GONE);
				}
			}
		});

		return m_rootView;
	}



	/*
	 * For image
	 */

	private void selectImage() {

		doSavePicUri = false;
		setImageFile();

		// final CharSequence[] options = { "Take Photo",
		// "Choose from Gallery","Cancel" };
		final CharSequence[] options = { "Take Photo From Gallery"/*,"File Explorer",*/, "Cancel" };
		final String dir = Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)+ "/picFolder/";
		File newdir = new File(dir);
		newdir.mkdirs();
		AlertDialog.Builder builder = new AlertDialog.Builder(
				getActivity());
		if(builder !=null)
		{

			builder.setTitle("Add Photo!");
			builder.setItems(options, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int item) {
					if (options[item].equals("Take Photo From Gallery")) {
						takePicture();

					} 
					else if (options[item].equals("File Explorer")) {
						takefromexplorer();

					} else if (options[item].equals("Cancel")) {
						mFileTemp = null;
						dialog.dismiss();
					}
				}
			});

			builder.show();
		}
		else
		{
			builder =  null;
		}
	}


	public void setImageFile() {
		/*
		 * // Store image in dcim // File file = new
		 * File(Environment.getExternalStorageDirectory() + "/DCIM/", "image" +
		 * new Date().getTime() + ".jpg"); File file = new
		 * File(Environment.getExternalStoragePublicDirectory
		 * (Environment.DIRECTORY_DCIM) + "/picFolder/"+ new Date().getTime() +
		 * ".jpg"); Uri imgUri = Uri.fromFile(file); this.ImagePath =
		 * file.getAbsolutePath();
		 * 
		 * System.out.println("ImagePath"+ImagePath); return imgUri;
		 */

		this.mFileTemp = new File(
				Environment
				.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)	+ "/picFolder/" + new Date().getTime() + ".jpg");
		System.out.println("mFileTemp = " + mFileTemp);
	}

	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != getActivity().RESULT_OK) {
			return;
		}
		Bitmap bitmap;
		doSavePicUri = true;
		switch (requestCode) {

		case REQUEST_CODE_GALLERY:
			try {
				picUri = data.getData();
				InputStream inputStream = getActivity().getContentResolver().openInputStream(
						data.getData());

				FileOutputStream fileOutputStream = new FileOutputStream(
						mFileTemp);
				copyStream(inputStream, fileOutputStream);
				fileOutputStream.close();
				inputStream.close();
				compressImage = new CompressImage(context, mFileTemp);
				bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
				img_gallery.setImageBitmap(bitmap);
				// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
				//				performCrop();

				/*compressImage = new CompressImage(context, mFileTemp);

				bitmap = compressImage.compressImage(mFileTemp.getPath());

				img_gallery.setImageBitmap(bitmap);*/

				/*	// Getting LocationManager object from System Service LOCATION_SERVICE
				LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

				// Creating a criteria object to retrieve provider
				Criteria criteria = new Criteria();

				// Getting the name of the best provider
				String provider = locationManager.getBestProvider(criteria, true);

				// Getting Current Location
				location = locationManager.getLastKnownLocation(provider);

				if(location!=null){
					if(gps.canGetLocation()){
				if(location!=null)
				{
					if(gps.canGetLocation())
					{
						getExif();
					}
					else
					{
						gps.showSettingsAlert();
					}
				}
				 */


			} catch (Exception e) {

				//				Log.e(TAG, "Error while creating temp file", e);
			}

			break;
		case CROP_PIC:
			// get the returned data
			// get the cropped bitmap
			Bundle extras = data.getExtras();
			// get the cropped bitmap
			Bitmap thePic = extras.getParcelable("data");
			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			img_gallery.setImageBitmap(thePic);
			break;
			/*case REQUEST_CODE_TAKE_PICTURE:
			// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());
			picUri = Uri.fromFile(mFileTemp);
			getExif();
			performCrop();
			//			 picUri = data.getData();

			 *//**
			 * Commented of compress image
			 *//*
			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(bitmap);

			break;
		case REQUEST_CODE_CROP_IMAGE:


			  * String path = data.getStringExtra(CropImage.IMAGE_PATH); if (path
			  * == null) {
			  * 
			  * return; }

			// bitmap = BitmapFactory.decodeFile(mFileTemp.getPath());

			compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(bitmap);
			break;

		case CROP_PIC:
			// get the returned data
			// get the cropped bitmap
			Bundle extras = data.getExtras();
			// get the cropped bitmap
			Bitmap thePic = extras.getParcelable("data");
				compressImage = new CompressImage(context, mFileTemp);
			bitmap = compressImage.compressImage(mFileTemp.getPath());
			imgUserPic.setImageBitmap(thePic);
			break;*/


		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * this function does the crop operation.
	 */
	private void performCrop() {
		// take care of exceptions
		try {
			// call the standard crop action intent (the user device may not
			// support it)
			Intent cropIntent = new Intent("com.android.camera.action.CROP");
			// indicate image type and Uri
			cropIntent.setDataAndType(picUri, "image/*");
			// set crop properties
			cropIntent.putExtra("crop", "true");
			// indicate aspect of desired crop
			/*	cropIntent.putExtra("aspectX", 2);
			cropIntent.putExtra("aspectY", 1);*/
			// indicate output X and Y
			cropIntent.putExtra("outputX", 200);
			cropIntent.putExtra("outputY", 150);
			// retrieve data on return
			cropIntent.putExtra("return-data", true);
			// start the activity - we handle returning in onActivityResult

			cropIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			cropIntent.putExtra("return-data", true);

			startActivityForResult(cropIntent, CROP_PIC);
		}

		// respond to users whose devices do not support the crop action
		catch (ActivityNotFoundException anfe) {
			Toast toast = Toast
					.makeText(getActivity(), "This device doesn't support the crop action!", Toast.LENGTH_SHORT);
			toast.show();
		}
	}
	public static void copyStream(InputStream input, OutputStream output)
			throws IOException {

		byte[] buffer = new byte[1024];
		int bytesRead;
		while ((bytesRead = input.read(buffer)) != -1) {
			output.write(buffer, 0, bytesRead);
		}
	}

	private void takePicture() {

		Intent intent = new Intent(Intent.ACTION_PICK);

		try {
			//			Uri mImageCaptureUri = null;
			String state = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				mImageCaptureUri = Uri.fromFile(mFileTemp);
			} else {
				/*
				 * The solution is taken from here:
				 * http://stackoverflow.com/questions
				 * /10042695/how-to-get-camera-result-as-a-uri-in-data-folder
				 */
				mImageCaptureUri = InternalStorageContentProvider.CONTENT_URI;
			}
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			intent.setType("image/*");
			intent.putExtra("return-data", true);
			startActivityForResult(intent, REQUEST_CODE_GALLERY);
		} catch (ActivityNotFoundException e) {

			//			Log.d(TAG, "cannot take picture", e);
		}
	}



	private void takefromexplorer() {

		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

		try {
			//			Uri mImageCaptureUri = null;
			String state = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				mImageCaptureUri = Uri.fromFile(mFileTemp);
			} else {
				/*
				 * The solution is taken from here:
				 * http://stackoverflow.com/questions
				 * /10042695/how-to-get-camera-result-as-a-uri-in-data-folder
				 */
				mImageCaptureUri = InternalStorageContentProvider.CONTENT_URI;
			}
			intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
					mImageCaptureUri);
			intent.setType("gagt/sdf");
			intent.putExtra("return-data", true);
			//			startActivityForResult(intent, REQUEST_CODE_GALLERY);
		} catch (ActivityNotFoundException e) {

			//			Log.d(TAG, "cannot take picture", e);
		}
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			getActivity().finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public class StateAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_StateDisplay!=null) {
				Log.e(TAG, "m_StateDisplay.clear()");
				m_StateDisplay.clear();
			}
			if(m_State!=null) {
				Log.e(TAG, "m_State.clear()");
				m_State.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_State);
			if (table_length > 0) {
				System.out
				.println("TESTDB: StateAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_State, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					States states = new States();
					states.setStateName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					states.setStateValues(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_value)));
					m_StateDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					m_State.add(states);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}
			//
			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> stateAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_StateDisplay);
			// set the view for the Drop down list
			stateAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spState.setAdapter(stateAdapter);

			spinnerSetGuj = stateAdapter.getPosition("Gujarat");
			if(m_StateDisplay.size()>0) {
				spState.setSelection(spinnerSetGuj);
			}
			
			else if((m_StateDisplay.size()<=0))
			{
				spState.setSelection(spinnerSetGuj);
			}
		}
	}

	public class DistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */

			if(m_DistrictDisplay!=null) {
				Log.e(TAG, "m_DistrictDisplay.clear()");
				m_DistrictDisplay.clear();
			}
			if(m_District!=null) {
				Log.e(TAG, "m_District.clear()");
				m_District.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DistrictAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_state_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_state_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_DistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_District.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_DistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDistrict.setAdapter(districtAdapter);
		}
	}


	public class TalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_TalukaDisplay!=null) {
				Log.e(TAG, "m_TalukaDisplay.clear()");
				m_TalukaDisplay.clear();
			}
			if(m_Taluka!=null) {
				Log.e(TAG, "m_Taluka.clear()");
				m_Taluka.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: TalukaAsyncTask if - read from table table_length = "
						+ table_length);
				//				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_TalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_Taluka.add(taluka);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_TalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spTaluka.setAdapter(talukaAdapter);
		}
	}

	public class RegionAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_RegionDisplay!=null) {
				Log.e(TAG, "m_RegionDisplay.clear()");
				m_RegionDisplay.clear();
			}
			if(m_Region!=null) {
				Log.e(TAG, "m_Region.clear()");
				m_Region.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Region);
			if (table_length > 0) {
				System.out
				.println("TESTDB: RegionAsyncTask if - read from table table_length = "
						+ table_length);
				//				Log.e(TAG, "arg0[0] = " + arg0[0]);
				//				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Region, null);
				//				Cursor result = db.rawQuery("select * from "
				//						+ DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_value + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_value + " = '" + arg0[0]+"'", null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Region region = new Region();
					region.setRegion_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value)));
					region.setRegion_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_RegionDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_Region.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> regionAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_RegionDisplay);
			// set the view for the Drop down list
			regionAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spRegion.setAdapter(regionAdapter);
		}
	}

	public class SectorAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SectorDisplay!=null) {
				Log.e(TAG, "m_SectorDisplay.clear()");
				m_SectorDisplay.clear();
			}
			if(m_Sector!=null) {
				Log.e(TAG, "m_Sector.clear()");
				m_Sector.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Sector);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SectorAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Sector, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Sector sector = new Sector();
					sector.setSector_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_value)));
					sector.setSector_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_name)));
					m_SectorDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_name)));
					m_Sector.add(sector);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> sectorAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_SectorDisplay);
			// set the view for the Drop down list
			sectorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSector.setAdapter(sectorAdapter);
		}
	}


	public class EstablishmentAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_EstablishmentDisplay!=null) {
				Log.e(TAG, "m_SectorDisplay.clear()");
				m_EstablishmentDisplay.clear();
			}
			if(m_Establishment!=null) {
				Log.e(TAG, "m_Sector.clear()");
				m_Establishment.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_est_type);
			if (table_length > 0) {
				System.out
				.println("TESTDB: EstablishmentAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_est_type, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Establishment establishment = new Establishment();
					establishment.setEstablishment_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_est_value)));
					establishment.setEstablishment_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_est_name)));
					m_EstablishmentDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_est_name)));
					m_Establishment.add(establishment);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> establishmentAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_EstablishmentDisplay);
			// set the view for the Drop down list
			establishmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spEstablishment.setAdapter(establishmentAdapter);
		}
	}


	public class DesignationAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_DesignationDisplay!=null) {
				Log.e(TAG, "m_DesignationDisplay.clear()");
				m_DesignationDisplay.clear();
			}
			if(m_Designation!=null) {
				Log.e(TAG, "m_Designation.clear()");
				m_Designation.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Designation);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DesignationAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Designation, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Designation designation = new Designation();
					designation.setDesignation_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_value)));
					designation.setDesignation_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_DesignationDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_Designation.add(designation);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> designationAdapter = new ArrayAdapter<String>(
					getActivity(),
					android.R.layout.simple_spinner_item, m_DesignationDisplay);
			// set the view for the Drop down list
			designationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
//			spDesignation.setAdapter(designationAdapter);
			spContactDesignation.setAdapter(designationAdapter);
		}
	}


	private void setDistrict() {
		String tmpSataeName = spState.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_State + " where " + DataBaseHelper.KEY_state_name + " = '" + tmpSataeName +"'" , null);
		result.moveToFirst();
		String tmpStateId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_state_value));

		if(!result.isClosed()) {
			result.close();				
		}
		new DistrictAsyncTask().execute(tmpStateId); 			
	}

	private void setTaluka() {
		String tmpDistrictName = spDistrict.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
		result.moveToFirst();
		String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));
		String regionId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_region_id));

		if(!result.isClosed()) {
			result.close();				
		}
		new RegionAsyncTask().execute(regionId); 			
		new TalukaAsyncTask().execute(tmpDistrictId); 			
	}

	/*
	 * Insert data of industry
	 */
	private void insertIndustryData() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		/*
		 * mandatory fields
		 */
		if (doSavePicUri == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_user_pic);
			isInsertInDb = false;
		}
		if (etxOrgCode.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_org_code);
			isInsertInDb = false;
		}
		if (etxOrgName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_org_name);
			isInsertInDb = false;
		}
		if (spState.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_state);
			isInsertInDb = false;
		}
		if (spDistrict.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_district);
			isInsertInDb = false;
		}
		if (spRegion.getSelectedItem().toString().equalsIgnoreCase("Please Select")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_region);
			isInsertInDb = false;
		}
		if (spTaluka.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_taluka);
			isInsertInDb = false;
		}
		if (etxAddress.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_address);
			isInsertInDb = false;
		}
		if (etxCity.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_city);
			isInsertInDb = false;
		}
		if (etxPincode.getText().toString().equalsIgnoreCase("")  || etxPincode.getText().toString().length()<6) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_pinno);
			isInsertInDb = false;			
		}
		if (etxMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mobno);
			isInsertInDb = false;
		} else if(etxMobile.getText().toString().length()<10) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_mobno);
			isInsertInDb = false;			
		}
		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_email);
			isInsertInDb = false;			
		}
		if (spSector.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_sector);
			isInsertInDb = false;
		}
		if (spEstablishment.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_establishment);
			isInsertInDb = false;
		}
		/*if (spDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_designation);
			isInsertInDb = false;
		}*/
		if (etxContactName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_name);
			isInsertInDb = false;			
		}
		if (etxContactMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_mobile);
			isInsertInDb = false;			
		}
		if (spContactDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_designation);
			isInsertInDb = false;
		}
		if (etxContactEmail.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_email);
			isInsertInDb = false;			
		}
		if (etxCmpnyHelpers.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_CmpnyHelpers);
			isInsertInDb = false;			
		}
		if (etxCmpnyContWorker.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_CmpnyContWorker);
			isInsertInDb = false;			
		}
		if (etxNameLbrCont.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_NameLbrCont);
			isInsertInDb = false;			
		}
		if (etxAddressLbrCont.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_AddressLbrCont);
			isInsertInDb = false;			
		}		
		/*
		 * Non-mandatory fields
		 */
		if (isInsertInDb) {
			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// db.beginTransaction();
			System.out.println("Insert in db");
			// Insert in db

			getSpinnerIds();

			ContentValues contentValues = new ContentValues();
			
			
			contentValues.put(DataBaseHelper.KEY_ri_user_email, Global.USER_EMAIL);
			
			contentValues.put(DataBaseHelper.KEY_ri_org_code, etxOrgCode.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_org_name, etxOrgName.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_state_name, spState.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_state_value, stateValue);
			contentValues.put(DataBaseHelper.KEY_ri_district_name, spDistrict.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_district_value, districtValue);
			contentValues.put(DataBaseHelper.KEY_ri_region_name, spRegion.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_region_value, regionValue);
			contentValues.put(DataBaseHelper.KEY_ri_taluka_name, spTaluka.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_taluka_value, talukaValue);
			contentValues.put(DataBaseHelper.KEY_ri_address, etxAddress.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_city, etxCity.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_pincode, etxPincode.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_mobileno, etxMobile.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_lline, etxLline.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_email, etxEmail.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_website, etxWebsite.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_sector_name, spSector.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_sector_value, sectorValue);
			contentValues.put(DataBaseHelper.KEY_ri_nature_product, etxNatureProd.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_establishment_name, spEstablishment.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_establishment_value, establishmentValue);
			if(chkActive.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_active, "1");				
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_active, "0");
			}
			if(swtApprentice.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_apprentice_act, "1");
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_apprentice_act, "0");				
			}
		/*	contentValues.put(DataBaseHelper.KEY_ri_designation_name, spDesignation.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_designation_value, designationValue);*/
			contentValues.put(DataBaseHelper.KEY_ri_contact_name, etxContactName.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_contact_mobile, etxContactMobile.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_contact_des_name, spContactDesignation.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_contact_des_val, contactDesignationVale);
			contentValues.put(DataBaseHelper.KEY_ri_contact_email, etxContactEmail.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_compHelpers, etxCmpnyHelpers.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_cmp_cntct_worker, etxCmpnyContWorker.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_lbr_cntct_name, etxNameLbrCont.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_lbr_cntct_add, etxAddressLbrCont.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_manager, etxTotalManager.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_supervisor, etxSupervisor.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_skilled_worker, etxSkillWorker.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_semi_skilled_worker, etxSemiSkillWorker.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_unskilled_worker, etxUnskillWorker.getText().toString());
			if(swtLicence.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_licence_lbr_cntct, "1");				
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_licence_lbr_cntct, "0");
			}
			if(swtEstablishment.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_agree_skill_certi, "1");
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_agree_skill_certi, "0");				
			}
			contentValues.put(DataBaseHelper.KEY_ri_total_no_req, etxTotalRequireSC.getText().toString());


			if (mFileTemp != null) {
				contentValues.put(DataBaseHelper.KEY_ri_image_path, mFileTemp.toString());
			}


			db.insert(DataBaseHelper.TABLE_register_industry, null, contentValues);

			etxOrgCode.setText("");
			etxOrgName.setText("");
			etxAddress.setText("");
			etxCity.setText("");
			etxPincode.setText("");
			etxMobile.setText("");
			etxLline.setText("");
			etxEmail.setText("");
			
			etxWebsite.setText("");
			etxNatureProd.setText("");
			etxContactName.setText("");
			etxContactMobile.setText("");
			etxContactEmail.setText("");
			etxCmpnyHelpers.setText("");
			etxCmpnyContWorker.setText("");
			etxNameLbrCont.setText("");
			etxAddressLbrCont.setText("");
			etxTotalManager.setText("");
			etxSupervisor.setText("");
			etxSkillWorker.setText("");
			etxSemiSkillWorker.setText("");
			etxUnskillWorker.setText("");
			etxTotalRequireSC.setText("");
			
			Global.showAlertDialog(getActivity(), "Industry Profile :",
					"Inserted Successfully", false);

			spState.setSelection(0);
			spSector.setSelection(0);
			spContactDesignation.setSelection(0);
			spEstablishment.setSelection(0);

			img_gallery.setImageResource(R.drawable.ic_add_user_image);
			
			chkActive.setChecked(true);
			swtApprentice.setChecked(true);
			swtLicence.setChecked(true);
			swtEstablishment.setChecked(true);
			
		} else {
			System.out.println("alert");
			Global.showAlertDialog(getActivity(),
					"Mandatory fields", errorMessage, false);
		}
	}


	private void getSpinnerIds() {
		stateValue = m_State.get(spState.getSelectedItemPosition()).getStateValues();
		districtValue = m_District.get(spDistrict.getSelectedItemPosition()).getDistrictValue();
		regionValue = m_Region.get(spRegion.getSelectedItemPosition()).getRegion_values();
		talukaValue = m_Taluka.get(spTaluka.getSelectedItemPosition()).getTaluka_values();
		sectorValue = m_Sector.get(spSector.getSelectedItemPosition()).getSector_values();
		establishmentValue = m_Establishment.get(spEstablishment.getSelectedItemPosition()).getEstablishment_values();
//		designationValue = m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_values();
		contactDesignationVale = m_Designation.get(spContactDesignation.getSelectedItemPosition()).getDesignation_values();
	}

}