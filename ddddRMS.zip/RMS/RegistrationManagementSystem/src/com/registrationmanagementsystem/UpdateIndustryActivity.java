package com.registrationmanagementsystem;

import java.io.File;
import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.registrationmanagementsystem.IndustryRegistrationFragment.EstablishmentAsyncTask;
import com.registrationmanagementsystem.UpdateDetailActivity.DesignationAsyncTask;
import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.Designation;
import com.registrationmanagementsystem.model.District;
import com.registrationmanagementsystem.model.Establishment;
import com.registrationmanagementsystem.model.Region;
import com.registrationmanagementsystem.model.Sector;
import com.registrationmanagementsystem.model.States;
import com.registrationmanagementsystem.model.Taluka;

public class UpdateIndustryActivity extends ActionBarActivity{

	private static final String TAG = UpdateIndustryActivity.class.getName();


	TextView txtTitle;

	EditText etxOrgName,etxOrgCode, etxContactPerson, etxAddress, etxCity, etxPincode, etxMobile, etxLline, etxEmail, etxActivity, etxManPower;

	Spinner spState, spDistrict, spRegion, spTaluka, spSector;
	String stateValue, districtValue, regionValue, talukaValue, sectorValue;

	Button btnSubmit;

	ActionBar actionBar;
	
	ImageView img_gallery;
	
	/**
	 * New parameters to be update 
	 */
	TextView txtTotalRequireSC;

	EditText etxWebsite, etxNatureProd, etxContactName, etxContactMobile, etxContactEmail, etxCmpnyHelpers, etxCmpnyContWorker, etxNameLbrCont, etxAddressLbrCont,
	etxTotalManager, etxSupervisor, etxSkillWorker, etxSemiSkillWorker, etxUnskillWorker, etxTotalRequireSC;

	Spinner spEstablishment, spDesignation;
	String  establishmentValue, contactDesignationVale;
	String designationValue;
	CheckBox chkActive;

	Switch swtApprentice, swtLicence, swtEstablishment;

	private ArrayList<String> m_StateDisplay = new ArrayList<String>();
	private ArrayList<States> m_State = new ArrayList<States>();
	private ArrayList<String> m_DistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_District = new ArrayList<District>();
	private ArrayList<String> m_RegionDisplay = new ArrayList<String>();
	private ArrayList<Region> m_Region = new ArrayList<Region>();
	private ArrayList<String> m_TalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_Taluka = new ArrayList<Taluka>();
	private ArrayList<String> m_SectorDisplay = new ArrayList<String>();
	private ArrayList<Sector> m_Sector = new ArrayList<Sector>();
	private ArrayList<String> m_EstablishmentDisplay = new ArrayList<String>();
	private ArrayList<Establishment> m_Establishment = new ArrayList<Establishment>();
	private ArrayList<String> m_DesignationDisplay = new ArrayList<String>();
	private ArrayList<Designation> m_Designation = new ArrayList<Designation>();
	

	DataBaseHelper mDbHelper;
	String _id;
	Context context;

	boolean isStateClicked = false;
	boolean isDistrictClicked = false;
	String toSetDistrictDisplay;
	String toSetTalukaDisplay;
	String toSetRegionDisplay;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_industryregistration);

		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());
		Bundle getBundle = this.getIntent().getExtras();
		if (getBundle != null) {
			_id = getBundle.getString(DataBaseHelper.KEY_ri_industry_id);

		}

		// get action bar
		actionBar = getSupportActionBar();

		// running platform is at least Honeycomb
		actionBar.setDisplayHomeAsUpEnabled(true);


		txtTitle = (TextView) findViewById(R.id.tv_establishment);
		txtTitle.setText(R.string.industry_edit_registration);
		etxOrgName = (EditText) findViewById(R.id.txtOrganizationName);
		etxContactPerson = (EditText) findViewById(R.id.txtContact);
		etxAddress = (EditText) findViewById(R.id.txtAddress);
		etxCity = (EditText) findViewById(R.id.txtcityname);
		etxPincode = (EditText) findViewById(R.id.txtpincodename);
		etxMobile = (EditText) findViewById(R.id.txtMobname);
		etxLline = (EditText) findViewById(R.id.txtlandlinename);
		etxEmail = (EditText) findViewById(R.id.txtEmail);
//		etxActivity = (EditText) findViewById(R.id.txtActivity);
		etxManPower = (EditText) findViewById(R.id.txtManPower);

		spState = (Spinner) findViewById(R.id.spsname);
		spDistrict = (Spinner) findViewById(R.id.spdname);
		spRegion = (Spinner) findViewById(R.id.sprname);
		spTaluka = (Spinner) findViewById(R.id.sptalukaname);
		spSector = (Spinner) findViewById(R.id.spSector);
		spDesignation = (Spinner)findViewById(R.id.spODesignation);
		btnSubmit = (Button) findViewById(R.id.btnSubmit);
		etxOrgCode = (EditText)findViewById(R.id.txtOrganizationCode);
		/***
		 * Newly Added parameters
		 */
		etxWebsite= (EditText)findViewById(R.id.txtWebsite);
		etxNatureProd = (EditText)findViewById(R.id.txtNatureofProduct);
		etxContactName = (EditText)findViewById(R.id.txtOContact);
		etxContactMobile = (EditText)findViewById(R.id.txtOMobname);
		etxContactEmail = (EditText)findViewById(R.id.txtOEmail);
		etxCmpnyHelpers= (EditText)findViewById(R.id.txtCompanyHelpers);
		etxCmpnyContWorker= (EditText) findViewById(R.id.txtCompanycontractual);
		etxNameLbrCont= (EditText)findViewById(R.id.txtLabourContractor);
		etxAddressLbrCont= (EditText)findViewById(R.id.txtAddressLabour);
		etxTotalManager= (EditText)findViewById(R.id.txttotalmanager);
		etxSupervisor= (EditText)findViewById(R.id.txtsupervisor);
		etxSkillWorker= (EditText) findViewById(R.id.txtskilledworkers);
		etxSemiSkillWorker= (EditText) findViewById(R.id.txtsemiskilledworkers);
		etxUnskillWorker= (EditText)findViewById(R.id.txtunskilledworkersSS);
		etxTotalRequireSC= (EditText)findViewById(R.id.txttotalnosofpersonskillcertification);
		txtTotalRequireSC= (TextView)findViewById(R.id.tvtotalnosofpersonskillcertification);

		chkActive = (CheckBox) findViewById(R.id.ch_Activity);

		swtApprentice = (Switch)findViewById(R.id.ch_Apprentice);
		swtLicence = (Switch)findViewById(R.id.ch_havinglicense);
		swtEstablishment= (Switch)findViewById(R.id.ch_establishmentskillcertification);
		spEstablishment = (Spinner) findViewById(R.id.spEstablishment);
		
		img_gallery = (ImageView)findViewById(R.id.list_image);
		
		new StateAsyncTask().execute();
		new SectorAsyncTask().execute();
		new EstablishmentAsyncTask().execute();
		new DesignationAsyncTask().execute();

		spState.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (event.getAction() == MotionEvent.ACTION_UP) {
					isStateClicked = true;
				}
				return false;
			}
		});

		spState.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Log.e(TAG, "spState onItemSelected");
				setDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spDistrict.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				if (event.getAction() == MotionEvent.ACTION_UP) {
					isDistrictClicked = true;
				}
				return false;
			}
		});

		spDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Log.e(TAG, "spDistrict onItemSelected");
				setTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				updateIndustryData();
			}
		});


	/*	img_gallery.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				selectImage();

			}
		});*/

		swtEstablishment.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked) {
					etxTotalRequireSC.setVisibility(View.VISIBLE);
					txtTotalRequireSC.setVisibility(View.VISIBLE);
				} else {
					etxTotalRequireSC.setVisibility(View.GONE);
					txtTotalRequireSC.setVisibility(View.GONE);
				}
			}
		});
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public class StateAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_State);
			if (table_length > 0) {
				System.out
				.println("TESTDB: StateAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_State, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					States states = new States();
					states.setStateName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					states.setStateValues(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_value)));
					m_StateDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					m_State.add(states);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}
			//
			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> stateAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_StateDisplay);
			// set the view for the Drop down list
			stateAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spState.setAdapter(stateAdapter);
			updateAsyncCallback.onTaskDone("StateAsyncTask");
		}
	}
	
	public class DesignationAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_DesignationDisplay!=null) {
				Log.e(TAG, "m_DesignationDisplay.clear()");
				m_DesignationDisplay.clear();
			}
			if(m_Designation!=null) {
				Log.e(TAG, "m_Designation.clear()");
				m_Designation.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Designation);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DesignationAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Designation, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Designation designation = new Designation();
					designation.setDesignation_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_value)));
					designation.setDesignation_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_DesignationDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_Designation.add(designation);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> designationAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_DesignationDisplay);
			// set the view for the Drop down list
			designationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDesignation.setAdapter(designationAdapter);
			updateAsyncCallback.onTaskDone("DesignationAsyncTask");		
		}
	}


	public class DistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DistrictAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_DistrictDisplay!=null) {
					m_DistrictDisplay.clear();
				}
				if(m_District!=null) {
					m_District.clear();
				}

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_state_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_state_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_DistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_District.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_DistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDistrict.setAdapter(districtAdapter);

			if(isStateClicked == false) {
				Log.e(TAG, "isStateClicked= " + isStateClicked);
				Log.e(TAG, "toSetDistrictDisplay= " + toSetDistrictDisplay);
				spDistrict.setSelection(m_DistrictDisplay
						.indexOf(toSetDistrictDisplay));
			}

			updateAsyncCallback.onTaskDone("DistrictAsyncTask");
		}
	}


	public class TalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: TalukaAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_TalukaDisplay!=null) {
					m_TalukaDisplay.clear();
				}
				if(m_Taluka!=null) {
					m_Taluka.clear();
				}
				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_TalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_Taluka.add(taluka);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_TalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spTaluka.setAdapter(talukaAdapter);

			if(isDistrictClicked == false) {
				Log.e(TAG, "isDistrictClicked= " + isDistrictClicked);
				spTaluka.setSelection(m_TalukaDisplay
						.indexOf(toSetTalukaDisplay));
			}

			updateAsyncCallback.onTaskDone("TalukaAsyncTask");
		}
	}

	public class RegionAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Region);
			if (table_length > 0) {
				System.out
				.println("TESTDB: RegionAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_RegionDisplay!=null) {
					m_RegionDisplay.clear();
				}
				if(m_Region!=null) {
					m_Region.clear();
				}
				Log.e(TAG, "arg0[0] = " + arg0[0]);
				//				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Region, null);
				//				Cursor result = db.rawQuery("select * from "
				//						+ DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_value + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_value + " = '" + arg0[0]+"'", null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Region region = new Region();
					region.setRegion_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value)));
					region.setRegion_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_RegionDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_Region.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> regionAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_RegionDisplay);
			// set the view for the Drop down list
			regionAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spRegion.setAdapter(regionAdapter);

			if(isDistrictClicked == false) {
				Log.e(TAG, "isDistrictClicked= " + isDistrictClicked);
				spRegion.setSelection(m_RegionDisplay
						.indexOf(toSetRegionDisplay));
			}
			updateAsyncCallback.onTaskDone("RegionAsyncTask");
		}
	}

	public class SectorAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Sector);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SectorAsyncTask if - read from table table_length = "
						+ table_length);

				if(m_SectorDisplay!=null) {
					m_SectorDisplay.clear();
				}
				if(m_Sector!=null) {
					m_Sector.clear();
				}
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Sector, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Sector region = new Sector();
					region.setSector_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_value)));
					region.setSector_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_name)));
					m_SectorDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_sector_name)));
					m_Sector.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> sectorAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_SectorDisplay);
			// set the view for the Drop down list
			sectorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSector.setAdapter(sectorAdapter);
			updateAsyncCallback.onTaskDone("SectorAsyncTask");
		}
	}
	
	
	public class EstablishmentAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_EstablishmentDisplay!=null) {
				Log.e(TAG, "m_SectorDisplay.clear()");
				m_EstablishmentDisplay.clear();
			}
			if(m_Establishment!=null) {
				Log.e(TAG, "m_Sector.clear()");
				m_Establishment.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_est_type);
			if (table_length > 0) {
				System.out
				.println("TESTDB: EstablishmentAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_est_type, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Establishment establishment = new Establishment();
					establishment.setEstablishment_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_est_value)));
					establishment.setEstablishment_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_est_name)));
					m_EstablishmentDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_est_name)));
					m_Establishment.add(establishment);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> establishmentAdapter = new ArrayAdapter<String>(
					UpdateIndustryActivity.this,
					android.R.layout.simple_spinner_item, m_EstablishmentDisplay);
			// set the view for the Drop down list
			establishmentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spEstablishment.setAdapter(establishmentAdapter);
			updateAsyncCallback.onTaskDone("EstablishmentAsyncTask");
		}
	}


	private void setDistrict() {
		String tmpSataeName = spState.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_State + " where " + DataBaseHelper.KEY_state_name + " = '" + tmpSataeName +"'" , null);
		result.moveToFirst();
		String tmpStateId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_state_value));

		if(!result.isClosed()) {
			result.close();				
		}
		new DistrictAsyncTask().execute(tmpStateId); 			
	}

	private void setTaluka() {
		String tmpDistrictName = spDistrict.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();
		Log.e(TAG, "setTaluka toSetDistrictDisplay= " + toSetDistrictDisplay);
		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
		result.moveToFirst();
		String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));
		String regionId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_region_id));

		if(!result.isClosed()) {
			result.close();				
		}
		new RegionAsyncTask().execute(regionId); 			
		new TalukaAsyncTask().execute(tmpDistrictId); 			
	}

	/*
	 * Update data of industry
	 */
	private void updateIndustryData() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		/*
		 * mandatory fields
		 */
		/*if (doSavePicUri == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_user_pic);
			isInsertInDb = false;
		}*/
		if (etxOrgCode.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_org_code);
			isInsertInDb = false;
		}
		if (etxOrgName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_org_name);
			isInsertInDb = false;
		}
		if (spState.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_state);
			isInsertInDb = false;
		}
		if (spDistrict.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_district);
			isInsertInDb = false;
		}
		if (spRegion.getSelectedItem().toString().equalsIgnoreCase("Please Select")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_region);
			isInsertInDb = false;
		}
		if (spTaluka.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_taluka);
			isInsertInDb = false;
		}
		if (etxAddress.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_address);
			isInsertInDb = false;
		}
		if (etxCity.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_city);
			isInsertInDb = false;
		}
		if (etxPincode.getText().toString().equalsIgnoreCase("")  || etxPincode.getText().toString().length()<6) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_pinno);
			isInsertInDb = false;			
		}
		if (etxMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mobno);
			isInsertInDb = false;
		} else if(etxMobile.getText().toString().length()<10) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_mobno);
			isInsertInDb = false;			
		}
		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_email);
			isInsertInDb = false;			
		}
		if (spSector.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_sector);
			isInsertInDb = false;
		}
		if (spEstablishment.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_establishment);
			isInsertInDb = false;
		}
		/*if (spDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_designation);
			isInsertInDb = false;
		}*/
		if (etxContactName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_name);
			isInsertInDb = false;			
		}
		if (etxContactMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_mobile);
			isInsertInDb = false;			
		}
		if (spDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_designation);
			isInsertInDb = false;
		}
		if (etxContactEmail.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_contact_email);
			isInsertInDb = false;			
		}
		if (etxCmpnyHelpers.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_CmpnyHelpers);
			isInsertInDb = false;			
		}
		if (etxCmpnyContWorker.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_CmpnyContWorker);
			isInsertInDb = false;			
		}
		if (etxNameLbrCont.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_NameLbrCont);
			isInsertInDb = false;			
		}
		if (etxAddressLbrCont.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_AddressLbrCont);
			isInsertInDb = false;			
		}		
		/*
		 * Non-mandatory fields
		 */
		if (isInsertInDb) {
			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// db.beginTransaction();
			System.out.println("Insert in db");
			// Insert in db

			getSpinnerIds();

			ContentValues contentValues = new ContentValues();
			contentValues.put(DataBaseHelper.KEY_ri_org_code, etxOrgCode.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_org_name, etxOrgName.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_state_name, spState.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_state_value, stateValue);
			contentValues.put(DataBaseHelper.KEY_ri_district_name, spDistrict.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_district_value, districtValue);
			contentValues.put(DataBaseHelper.KEY_ri_region_name, spRegion.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_region_value, regionValue);
			contentValues.put(DataBaseHelper.KEY_ri_taluka_name, spTaluka.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_taluka_value, talukaValue);
			contentValues.put(DataBaseHelper.KEY_ri_address, etxAddress.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_city, etxCity.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_pincode, etxPincode.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_mobileno, etxMobile.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_lline, etxLline.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_email, etxEmail.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_website, etxWebsite.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_sector_name, spSector.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_sector_value, sectorValue);
			contentValues.put(DataBaseHelper.KEY_ri_nature_product, etxNatureProd.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_establishment_name, spEstablishment.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_establishment_value, establishmentValue);
			if(chkActive.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_active, "1");				
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_active, "0");
			}
			if(swtApprentice.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_apprentice_act, "1");
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_apprentice_act, "0");				
			}
			
			contentValues.put(DataBaseHelper.KEY_ri_contact_name, etxContactName.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_contact_mobile, etxContactMobile.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_contact_des_name, spDesignation.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_ri_contact_des_val, contactDesignationVale);
			contentValues.put(DataBaseHelper.KEY_ri_contact_email, etxWebsite.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_compHelpers, etxCmpnyHelpers.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_cmp_cntct_worker, etxCmpnyContWorker.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_lbr_cntct_name, etxNameLbrCont.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_lbr_cntct_add, etxAddressLbrCont.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_manager, etxTotalManager.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_total_supervisor, etxSupervisor.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_skilled_worker, etxSkillWorker.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_semi_skilled_worker, etxSemiSkillWorker.getText().toString());
			contentValues.put(DataBaseHelper.KEY_ri_unskilled_worker, etxUnskillWorker.getText().toString());

			if(swtLicence.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_licence_lbr_cntct, "1");				
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_licence_lbr_cntct, "0");
			}
			if(swtEstablishment.isChecked()) {
				contentValues.put(DataBaseHelper.KEY_ri_agree_skill_certi, "1");
			} else {
				contentValues.put(DataBaseHelper.KEY_ri_agree_skill_certi, "0");				
			}
			contentValues.put(DataBaseHelper.KEY_ri_total_no_req, etxTotalRequireSC.getText().toString());


			/*if (mFileTemp != null) {
				contentValues.put(DataBaseHelper.KEY_ri_image_path, mFileTemp.toString());
			}

*/
			db.update(DataBaseHelper.TABLE_register_industry, contentValues,
					DataBaseHelper.KEY_ri_industry_id +" = '"+ _id +"'",
					null);
			
			Global.showAlertDialog(UpdateIndustryActivity.this, "Industry Profile :",
					"Updated Successfully", false);

			/*spState.setSelection(0);
			spSector.setSelection(0);*/
		} else {
			System.out.println("alert");
			Global.showAlertDialog(UpdateIndustryActivity.this,
					"Mandatory fields", errorMessage, false);
		}
	}


	private void getSpinnerIds() {
		stateValue = m_State.get(spState.getSelectedItemPosition()).getStateValues();
		districtValue = m_District.get(spDistrict.getSelectedItemPosition()).getDistrictValue();
		regionValue = m_Region.get(spRegion.getSelectedItemPosition()).getRegion_values();
		talukaValue = m_Taluka.get(spTaluka.getSelectedItemPosition()).getTaluka_values();
		sectorValue = m_Sector.get(spSector.getSelectedItemPosition()).getSector_values();
		designationValue = m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_values();
	}


	private UpdateAsyncCallback updateAsyncCallback = new UpdateAsyncCallback() {
		boolean isStateLoaded = false;
		boolean isDistrictLoaded = false;
		boolean isTalukaLoaded = false;
		boolean isRegionLoaded = false;
		boolean isSectorLoaded= false;
		boolean isLoadedOnce = false;
		boolean isDesignationLoaded = false;
		boolean isEstablishmentLoaded = false;
		
		@Override
		public void onTaskDone(String asynClassName) {
			// TODO Auto-generated method stub
			/*			updateCount = updateCount + count;
			if (updateCount == 5) {
				System.out.println("updateCount if = " + updateCount);
				new SetUserDetailAsyncTask().execute();
			} else {
				System.out.println("updateCount else  = " + updateCount);
			}*/

			if(asynClassName.equalsIgnoreCase("StateAsyncTask")) {
				isStateLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("DistrictAsyncTask")) {
				isDistrictLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("TalukaAsyncTask")) {
				isTalukaLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("RegionAsyncTask")) {
				isRegionLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("SectorAsyncTask")) {
				isSectorLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("DesignationAsyncTask")) {
				isDesignationLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("EstablishmentAsyncTask")) {
				isEstablishmentLoaded = true;
			}

			if(isLoadedOnce == false) {
				if(isStateLoaded && isDistrictLoaded &&  isTalukaLoaded && isRegionLoaded && isSectorLoaded
						&& isDesignationLoaded && isEstablishmentLoaded) {
					Log.e(TAG, "call set data");
					new SetIndustryDetailAsyncTask().execute();
					isLoadedOnce = true;
				} else {
					Log.e(TAG, "do not call set data");
					Log.i(TAG, "isStateLoaded = " + isStateLoaded);
					Log.i(TAG, "isDistrictLoaded = " + isDistrictLoaded);
					Log.i(TAG, "isTalukaLoaded = " + isTalukaLoaded);
					Log.i(TAG, "isGenderLoaded = " + isRegionLoaded);
					Log.i(TAG, "isCastLoaded = " + isSectorLoaded);
				}
			}
		}
	};

	public class SetIndustryDetailAsyncTask extends AsyncTask<Void, Void, Cursor> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Cursor doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			Cursor result = null;
			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_register_industry);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SetIndustryDetailAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_register_industry + " where id = "
						+ _id, null);

			}

			return result;
		}

		@Override
		protected void onPostExecute(Cursor result) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			setIndustryDetail(result);
		}
	}

	private void setIndustryDetail(Cursor result) {
		if (result != null) {
			result.moveToFirst();
			while (result.isAfterLast() == false) {

				etxOrgCode.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_org_code)));
				etxOrgName.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_org_name)));
				etxAddress.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_address)));
				etxCity.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_city)));
				etxPincode.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_pincode)));
				etxMobile.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_mobileno)));
				etxLline.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_lline)));
				etxEmail.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_email)));
				etxWebsite .setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_website)));
				etxNatureProd.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_nature_product)));
				etxContactName.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_contact_name)));
				etxContactMobile.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_contact_mobile)));
				etxContactEmail.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_contact_email)));
				etxCmpnyHelpers.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_total_compHelpers)));
				etxCmpnyContWorker.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_total_cmp_cntct_worker)));
				etxNameLbrCont.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_lbr_cntct_name)));
				etxAddressLbrCont.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_lbr_cntct_add)));
				etxTotalManager.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_total_manager)));
				etxSupervisor.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_total_supervisor)));
				etxSkillWorker.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_skilled_worker)));
				etxSemiSkillWorker.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_semi_skilled_worker)));
				etxUnskillWorker.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_unskilled_worker)));
				etxTotalRequireSC.setText(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ri_total_no_req)));
				
			 
				if(result.getInt(result.getColumnIndex(DataBaseHelper.KEY_ri_active))==0) {
					chkActive.setChecked(false);					
				} else {
					chkActive.setChecked(true);
				}

				if(result.getInt(result.getColumnIndex(DataBaseHelper.KEY_ri_apprentice_act))==0) {
					swtApprentice.setChecked(false);					
				} else {
					swtApprentice.setChecked(true);
				}

				if(result.getInt(result.getColumnIndex(DataBaseHelper.KEY_ri_licence_lbr_cntct))==0) {
					swtLicence.setChecked(false);					
				} else {
					swtLicence.setChecked(true);
				}
				
				if(result.getInt(result.getColumnIndex(DataBaseHelper.KEY_ri_agree_skill_certi))==0) {
					swtEstablishment.setChecked(false);					
				} else {
					swtEstablishment.setChecked(true);
				}
				
				String tmpState = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_state_name));
				spState.setSelection(m_StateDisplay.indexOf(tmpState));

				
				String tmpDesignation = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_contact_des_name));
				spDesignation.setSelection(m_DesignationDisplay.indexOf(tmpDesignation));

				String tmpDistrictDisplay = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_district_name));
				spDistrict.setSelection(m_DistrictDisplay
						.indexOf(tmpDistrictDisplay));
				toSetDistrictDisplay = tmpDistrictDisplay;

				String tmpRegionDisplay = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_region_name));
				spRegion.setSelection(m_RegionDisplay 
						.indexOf(tmpRegionDisplay));
				toSetRegionDisplay = tmpRegionDisplay;

				String tmpTalukaDisplay = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_taluka_name));
				spTaluka.setSelection(m_TalukaDisplay 
						.indexOf(tmpTalukaDisplay));
				toSetTalukaDisplay = tmpTalukaDisplay;

				String tmpSectorDisplay = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_sector_name));
				spSector.setSelection(m_SectorDisplay.indexOf(tmpSectorDisplay));
				
				
				String tmpEstablishmentDisplay = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_establishment_name));
				spEstablishment.setSelection(m_EstablishmentDisplay.indexOf(tmpEstablishmentDisplay));

				String tmpImg = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ri_image_path));
				Log.i(TAG, "tmpImg = " + tmpImg);
				if (tmpImg != null) {
					if (tmpImg.equalsIgnoreCase("")) {
					} else {
						Log.i(TAG, "else tmpImg = " + tmpImg);
						File mFileTemp = new java.io.File(tmpImg)
								.getAbsoluteFile();
						Bitmap bitmap = BitmapFactory.decodeFile(mFileTemp
								.getPath());
						img_gallery.setImageBitmap(bitmap);
					}
				}
				
				result.moveToNext();
			}

			if (!result.isClosed()) {
				result.close();
			}
		}
	}


}