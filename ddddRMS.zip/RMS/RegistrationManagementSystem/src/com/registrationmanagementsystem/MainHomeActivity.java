package com.registrationmanagementsystem;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.tab.PagerSlidingTabStrip;

public class MainHomeActivity extends FragmentActivity implements
ActionBar.TabListener {

	public ViewPager viewPager;
	public ActionBar actionBar;
	public PagerSlidingTabStrip tabs_pager;
	public UserAdapter mUserAdapter;
	public AdminAdapter mAdminAdapter;
	public Drawable oldBackground = null;

	private static final int MENU_ITEM5 = 5;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home_main);

		tabs_pager = (PagerSlidingTabStrip) findViewById(R.id.tabs);
		// Initialization
		viewPager = (ViewPager) findViewById(R.id.pager);
		viewPager.setOffscreenPageLimit(0);

		actionBar = getActionBar();


		if (Global.UASER_TYPE.equalsIgnoreCase("user")) {
			mUserAdapter = new UserAdapter(getSupportFragmentManager());

			viewPager.setAdapter(mUserAdapter);

			final int pageMargin = (int) TypedValue.applyDimension(
					TypedValue.COMPLEX_UNIT_DIP, 4, getResources()
					.getDisplayMetrics());
			viewPager.setPageMargin(pageMargin);
			tabs_pager.setViewPager(viewPager);
		} else {
			mAdminAdapter = new AdminAdapter(getSupportFragmentManager());
			viewPager.setAdapter(mAdminAdapter);
			final int pageMargin = (int) TypedValue.applyDimension(
					TypedValue.COMPLEX_UNIT_DIP, 4, getResources()
					.getDisplayMetrics());
			viewPager.setPageMargin(pageMargin);
			tabs_pager.setViewPager(viewPager);
		}

		tabs_pager.setOnPageChangeListener(new OnPageChangeListener() {

			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				if(Global.UASER_TYPE.equalsIgnoreCase("user")) 
				{
					mUserAdapter.notifyDataSetChanged();				
				} else {
					mAdminAdapter.notifyDataSetChanged();
				}
			}

			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// TODO Auto-generated method stub

			}

			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});

	}

	public void onTabSelected(Tab tab, android.app.FragmentTransaction ft) {
		System.out.println("test: tab.getPosition()= " + tab.getPosition());

		viewPager.setCurrentItem(tab.getPosition()-1);

		System.out.println("test: View Pager" + viewPager);

	}

	public void onTabUnselected(Tab tab, android.app.FragmentTransaction ft) {

	}

	public void onTabReselected(Tab tab, android.app.FragmentTransaction ft) {

	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		/*		if (member_id != null) {
			menu.add(Menu.NONE, MENU_ITEM5, Menu.NONE, "Logout");
		}*/
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		
		
		case R.id.exit:
			finish();
			return true;    
		/*		case R.id.action_back:
			finish();

			return true;
		case R.id.action_info:
			Intent intent = new Intent(MainHomeActivity.this,
					InformationActivity.class);
			startActivity(intent);
			return true;
		case R.id.search:
			Intent intent_search = new Intent(MainHomeActivity.this,
					AdvanceSearchActivity.class);
			startActivity(intent_search);
			return true;

		case R.id.changepassword:
			Intent intent_changepassword = new Intent(MainHomeActivity.this,
					ChangePasswordActivity.class);
			startActivity(intent_changepassword);
			return true;
		case MENU_ITEM5:
			SharedPreferences preferences = getSharedPreferences("MyPref",
					Context.MODE_PRIVATE);
			SharedPreferences.Editor editor = preferences.edit();
			editor.clear();
			editor.commit();
			Intent m_intent = new Intent(MainHomeActivity.this,
					SignInActivity.class);
			m_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(m_intent);
			finish();
			return true;
		case R.id.settings:
			Intent m_settings = new Intent(MainHomeActivity.this,
					SettingsActivityScreen.class);
			startActivity(m_settings);*/
		case R.id.logout:
			Global.logOut(MainHomeActivity.this);
			return true;
		}
		return false;
	}

	public class UserAdapter extends FragmentPagerAdapter {
		private final String[] TITLES = {"HOME", "CANDIDATE REGISTRATION","INDUSTRY REGISTRATION","CANDIDATE LISTING",
		"INDUSTRY LISTING"};

		public UserAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public CharSequence getPageTitle(int position) {
			return TITLES[position];
		}

		@Override
		public int getCount() {
			return TITLES.length;
		}

		@Override
		public int getItemPosition(Object object) {
			//don't return POSITION_NONE, avoid fragment recreation. 
			return super.getItemPosition(object);
		}

		@Override
		public Fragment getItem(int position) {

			Fragment mFragment = null;

			System.out.println("test: position = " + position);
			switch (position) {

			case 0:
				// Home fragment
				System.out.println("test: position0 = " + position);
				// return new HomeFragment();
				mFragment = new HomeFragment();
				break;

			case 1:
				System.out.println("test: position1 = " + position);
				// return new LibraryStatusFragment() ;
				mFragment = new RegistrationDetailFragment();
				break;
			case 2:

				System.out.println("test: position2 = " + position);
				// return new WishListMainFragment() ;
				mFragment = new IndustryRegistrationFragment();
				break;
			case 3:

				// Suggestion fragment
				System.out.println("test: position3 = " + position);
				// return new SuggestionFragment();
				mFragment = new CandidateListingFragment();
				break;
			case 4:
				// Reservation fragment
				System.out.println("test: position4 = " + position);
				// return new ReservationFragment();
				mFragment = new IndustryListingFragment();
				break;
			default:
				System.out.println("test: null position2 = " + position);
				mFragment = null;
				break;
				// return null;

			}
			// return null;
			return mFragment;
		}

	}

	/**
	 * Guest User Tabs
	 * 
	 * @author MW01
	 * 
	 */

	public class AdminAdapter extends FragmentPagerAdapter {
		private final String[] TITLES = {"HOME", "CREATE USER", "CANDIDATE REGISTRATION","INDUSTRY REGISTRATION","CANDIDATE LISTING",
		"INDUSTRY LISTING"};

		public AdminAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public CharSequence getPageTitle(int position) {
			return TITLES[position];
		}

		@Override
		public int getCount() {
			return TITLES.length;
		}

		@Override
		public int getItemPosition(Object object) {
			return super.getItemPosition(object);
		}

		@Override
		public Fragment getItem(int position) {

			switch (position) {
			case 0:

				return new HomeFragment();
			case 1:

				return new CreateUserFragment();
				
			case 2:
				return new RegistrationDetailFragment();

			case 3:
				return new IndustryRegistrationFragment();

			case 4:
				return new CandidateListingFragment();

			case 5:
				return new IndustryListingFragment();
			}

			return null;
		}

	}

}
