package com.registrationmanagementsystem;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.registrationmanagementsystem.adapter.UserAdapter;
import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.UserDetails;

public class CandidateListingFragment extends Fragment{

	String TAG = CandidateListingFragment.class.getName();

	ListView mUserListView;
	UserAdapter mUserAdapter;
	public ArrayList<UserDetails> mUserList = new ArrayList<UserDetails>();
	DataBaseHelper mDbHelper;
	Context context;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View m_rootView = inflater.inflate(R.layout.user_listing,
				container, false);


		context = getActivity();

		mDbHelper = DataBaseHelper.getInstance(getActivity());


		mUserListView = (ListView)m_rootView.findViewById(R.id.userslist);


		/**
		 * Commented for list click
		 */
		/*
		mUserListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				System.out.println("test = " + mUserList.get(position).getId());
				Intent intent = new Intent(UserListing.this,
						UpdateDetailActivity.class);
				intent.putExtra("id", mUserList.get(position).getId()
						.toString());
				startActivity(intent);
			}

		});*/

		new UserListingAsyncTask().execute();
		return m_rootView;
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			getActivity().finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

/*	public class UserListingAsyncTask extends AsyncTask<Void, Void, Void> {
		
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 

		protected void onPreExecute() {
			
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 
			if(mUserList!=null) {
				mUserList.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_register_candidate);
			if (table_length > 0) {
				System.out
				.println("TESTDB: UserListingAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = null;
				if(Global.UASER_TYPE.equalsIgnoreCase("user")) {
					Log.i(TAG, "for user");
					result = db.rawQuery("select * from "
							+ DataBaseHelper.TABLE_register_candidate + " where " +  DataBaseHelper.KEY_rca_user_email+" = '" + Global.USER_EMAIL +"'", null);
					result.moveToFirst();
					while (result.isAfterLast() == false) {
						UserDetails userDetails = new UserDetails();
						userDetails
						.setCandidate_category(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_candidate_category)));
						userDetails.setFirst_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_first_name)));
						userDetails.setMiddle_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_middle_name)));
						userDetails.setLast_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_last_name)));
						userDetails.setImage_path(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_image_path)));
						userDetails
						.setId(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_register_user_id)));
						System.out
						.println("result.getString(result.getColumnIndex(DataBaseHelper.KEY_register_user_id)) = "
								+ result.getString(result
										.getColumnIndex(DataBaseHelper.KEY_rca_register_user_id)));
						mUserList.add(userDetails);
						result.moveToNext();
					}
				} else {
					Log.i(TAG, "for admin");
					result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_register_candidate, null);
					result.moveToFirst();
					while (result.isAfterLast() == false) {
						UserDetails userDetails = new UserDetails();
						userDetails
						.setCandidate_category(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_candidate_category)));
						userDetails.setFirst_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_first_name)));
						userDetails.setMiddle_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_middle_name)));
						userDetails.setLast_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_last_name)));
						userDetails.setImage_path(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_image_path)));
						userDetails
						.setId(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_rca_register_user_id)));
						System.out
						.println("result.getString(result.getColumnIndex(DataBaseHelper.KEY_register_user_id)) = "
								+ result.getString(result
										.getColumnIndex(DataBaseHelper.KEY_rca_register_user_id)));
						mUserList.add(userDetails);
						result.moveToNext();
					}
				}

				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 
			mUserAdapter = new UserAdapter(context, mUserList);
			mUserListView.setAdapter(mUserAdapter);
		}
	}
*/
	
	public class UserListingAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(mUserList!=null) {
				mUserList.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_APPLICANT_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: UserListingAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = null;
				if(Global.UASER_TYPE.equalsIgnoreCase("user")) {
					Log.i(TAG, "for user");
					result = db.rawQuery("select * from "
							+ DataBaseHelper.TABLE_APPLICANT_MASTER + " where " +  DataBaseHelper.KEY_APPLICANT_MASTER_user_email + " = '" + Global.USER_EMAIL +"'", null);
					result.moveToFirst();
					while (result.isAfterLast() == false) {
						UserDetails userDetails = new UserDetails();
						userDetails
						.setCandidate_category(result.getInt(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_CATEGORY_ID)));
						userDetails.setFirst_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_FNAME_E)));
						userDetails.setMiddle_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_MNAME_E)));
						userDetails.setLast_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_LNAME_E)));
						userDetails.setImage_path(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_PHOTO)));
						userDetails
						.setId(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID)));
						mUserList.add(userDetails);
						result.moveToNext();
					}
				} else {
					Log.i(TAG, "for admin");
					result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_APPLICANT_MASTER, null);
					result.moveToFirst();
					while (result.isAfterLast() == false) {
						UserDetails userDetails = new UserDetails();
						userDetails
						.setId(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID)));
						userDetails
						.setCandidate_category(result.getInt(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_CATEGORY_ID)));
						userDetails.setFirst_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_FNAME_E)));
						userDetails.setMiddle_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_MNAME_E)));
						userDetails.setLast_name(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_LNAME_E)));
						userDetails.setImage_path(result.getString(result
								.getColumnIndex(DataBaseHelper.KEY_APPLICANT_PHOTO)));
						mUserList.add(userDetails);
						result.moveToNext();
					}
				}

				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			mUserAdapter = new UserAdapter(context, mUserList);
			mUserListView.setAdapter(mUserAdapter);
		}
	}


}
