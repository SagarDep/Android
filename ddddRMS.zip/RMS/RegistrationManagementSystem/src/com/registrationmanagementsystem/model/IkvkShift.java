package com.registrationmanagementsystem.model;

public class IkvkShift {

	String REF_ID;
	String PREFERRED_SHIFT;
	
	public String getREF_ID() {
		return REF_ID;
	}
	public void setREF_ID(String rEF_ID) {
		REF_ID = rEF_ID;
	}
	public String getPREFERRED_SHIFT() {
		return PREFERRED_SHIFT;
	}
	public void setPREFERRED_SHIFT(String pREFERRED_SHIFT) {
		PREFERRED_SHIFT = pREFERRED_SHIFT;
	}
}
