package com.registrationmanagementsystem;

public interface UpdateAsyncCallback {
    public void onTaskDone(String asynClassName);
}
