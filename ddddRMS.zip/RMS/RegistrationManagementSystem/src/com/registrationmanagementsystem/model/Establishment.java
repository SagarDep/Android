package com.registrationmanagementsystem.model;

public class Establishment {

	String establishment_name;
	String establishment_values;
	
	public String getEstablishment_name() {
		return establishment_name;
	}
	public void setEstablishment_name(String establishment_name) {
		this.establishment_name = establishment_name;
	}
	public String getEstablishment_values() {
		return establishment_values;
	}
	public void setEstablishment_values(String establishment_values) {
		this.establishment_values = establishment_values;
	}
}
