package com.registrationmanagementsystem.model;

public class States {
	String state_name;
	String state_values;

	public void setStateName(String state_name) {
		this.state_name = state_name;
	}

	public String getStateName() {
		return state_name;
	}

	public void setStateValues(String state_values) {
		this.state_values = state_values;
	}

	public String getStateValues() {
		return state_values;
	}
}