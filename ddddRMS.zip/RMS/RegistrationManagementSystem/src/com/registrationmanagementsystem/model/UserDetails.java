package com.registrationmanagementsystem.model;

public class UserDetails {
	String id;
	int candidate_category;
	String first_name;
	String middle_name;
	String last_name;
	String fmh_name;
	String address;
	String district;
	String state;
	String city;
	String taluka;
	String pincode;
	String mobileno;
	String lline;
	String gender;
	String caste;
	String chk_ph;
	String percentage_ph;
	String chk_exarmy;
	String chk_widow;
	String chk_divorcee;
	String chk_minority;
	String chk_bpl;
	String email;
	String birthday;
	String image_path;
	String Lattitude;
	String Longitude;
	
	
	
	
	public String getLattitude() {
		return Lattitude;
	}
	public void setLattitude(String lattitude) {
		Lattitude = lattitude;
	}
	public String getLongitude() {
		return Longitude;
	}
	public void setLongitude(String longitude) {
		Longitude = longitude;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getCandidate_category() {
		return candidate_category;
	}
	public void setCandidate_category(int candidate_category) {
		this.candidate_category = candidate_category;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getFmh_name() {
		return fmh_name;
	}
	public void setFmh_name(String fmh_name) {
		this.fmh_name = fmh_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTaluka() {
		return taluka;
	}
	public void setTaluka(String taluka) {
		this.taluka = taluka;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getLline() {
		return lline;
	}
	public void setLline(String lline) {
		this.lline = lline;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCaste() {
		return caste;
	}
	public void setCaste(String caste) {
		this.caste = caste;
	}
	public String getChk_ph() {
		return chk_ph;
	}
	public void setChk_ph(String chk_ph) {
		this.chk_ph = chk_ph;
	}
	public String getPercentage_ph() {
		return percentage_ph;
	}
	public void setPercentage_ph(String percentage_ph) {
		this.percentage_ph = percentage_ph;
	}
	public String getChk_exarmy() {
		return chk_exarmy;
	}
	public void setChk_exarmy(String chk_exarmy) {
		this.chk_exarmy = chk_exarmy;
	}
	public String getChk_widow() {
		return chk_widow;
	}
	public void setChk_widow(String chk_widow) {
		this.chk_widow = chk_widow;
	}
	public String getChk_divorcee() {
		return chk_divorcee;
	}
	public void setChk_divorcee(String chk_divorcee) {
		this.chk_divorcee = chk_divorcee;
	}
	public String getChk_minority() {
		return chk_minority;
	}
	public void setChk_minority(String chk_minority) {
		this.chk_minority = chk_minority;
	}
	public String getChk_bpl() {
		return chk_bpl;
	}
	public void setChk_bpl(String chk_bpl) {
		this.chk_bpl = chk_bpl;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getImage_path() {
		return image_path;
	}
	public void setImage_path(String image_path) {
		this.image_path = image_path;
	}
	
	
}