package com.registrationmanagementsystem.model;

public class Designation {

	String designation_name;
	String designation_values;
	
	public String getDesignation_name() {
		return designation_name;
	}
	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}
	public String getDesignation_values() {
		return designation_values;
	}
	public void setDesignation_values(String designation_values) {
		this.designation_values = designation_values;
	}
	
	
}
