package com.registrationmanagementsystem.model;

public class Taluka {
	String taluka_name;
	String taluka_values;
	
	public String getTaluka_name() {
		return taluka_name;
	}
	public void setTaluka_name(String taluka_name) {
		this.taluka_name = taluka_name;
	}
	public String getTaluka_values() {
		return taluka_values;
	}
	public void setTaluka_values(String taluka_values) {
		this.taluka_values = taluka_values;
	}
}
