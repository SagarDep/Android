package com.registrationmanagementsystem;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.registrationmanagementsystem.common.Global;

public class DashboardMainActivity extends Activity {

	/*@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.dashboard_main);

		
		 * save default location for first time or until it get it
		 
		Global.saveDefaultLatLng(DashboardMainActivity.this);

	}

	*//**
	 * Button click handler on Main activity
	 * @param v
	 *//*
	public void onButtonClicker(View v)
	{
		Intent intent;

		switch (v.getId()) {
		case R.id.main_btn_creg:
			intent = new Intent(this,RegistrationDetailActivity .class);
			startActivity(intent);
			break;

		case R.id.main_btn_clist:
			intent = new Intent(this,IndustryListing.class);
			startActivity(intent);
			break;

		case R.id.main_btn_reglist:
			intent = new Intent(this,UserListing.class);
			startActivity(intent);
			break;

		case R.id.main_btn_editireg:
			intent = new Intent(this,IndustryRegistration.class);
			startActivity(intent);
			break;


		default:
			break;
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;
		case R.id.logout :
			SharedPreferences preferences = getSharedPreferences(Global.RMS_Pref,
					Context.MODE_PRIVATE);
			SharedPreferences.Editor editor = preferences.edit();
			editor.clear();
			editor.commit();
			Intent m_intent = new Intent(DashboardMainActivity.this,
					SignInActivity.class);
			m_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(m_intent);
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}*/


}
