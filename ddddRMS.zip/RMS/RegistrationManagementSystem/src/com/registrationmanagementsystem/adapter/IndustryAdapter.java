package com.registrationmanagementsystem.adapter;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.registrationmanagementsystem.R;
import com.registrationmanagementsystem.UpdateIndustryActivity;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.IndustryDetails;

public class IndustryAdapter extends BaseAdapter {
	// private static ArrayList<ItemDetailScreen> userArrayList;
	private ArrayList<IndustryDetails> industryArrayList = new ArrayList<IndustryDetails>();
	private LayoutInflater mInflater;
	private Context m_context;
	private Context mActivity;


	public IndustryAdapter(Context context, ArrayList<IndustryDetails> results) {
		m_context = context.getApplicationContext();
		mActivity = (Activity) context;
		industryArrayList = results;
		mInflater = LayoutInflater.from(context);

	}

	// add new
	public IndustryAdapter(Context context) {
		m_context = context.getApplicationContext();
		mInflater = LayoutInflater.from(context);
	}

	public int getCount() {
		return industryArrayList.size();
	}

	public Object getItem(int position) {
		return industryArrayList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	// add new
	/*
	 * public void appendData(ItemDetailScreen itemDetailScreen) {
	 * this.userArrayList.add(itemDetailScreen); }
	 */

	public View getView(final int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = mInflater.inflate(R.layout.industry_item, null);
			holder = new ViewHolder();
			holder.txtIndustryName = (TextView) convertView
					.findViewById(R.id.industry_name);
			
			holder.txtIndustryCode = (TextView) convertView
					.findViewById(R.id.industrycode);
			
			holder.btnDetail = (Button) convertView.findViewById(R.id.btnDetail);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.txtIndustryCode.setText(industryArrayList.get(position).getIndustryCode());
		
		System.out.println("Industry code" +industryArrayList.get(position).getIndustryCode());
		System.out.println("Industry name" +industryArrayList.get(position).getIndustryName());
		
		holder.txtIndustryName.setText(industryArrayList.get(position).getIndustryName());
		
		holder.btnDetail.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

					
				Intent intent = new Intent(m_context,UpdateIndustryActivity.class);
				intent.putExtra(DataBaseHelper.KEY_ri_industry_id, industryArrayList.get(position).getId().toString());
				mActivity.startActivity(intent);
				
			}
		});
		
		return convertView;
	}
	
	class ViewHolder {
		public TextView txtIndustryName,txtIndustryCode;
		public Button btnDetail;
	}
	
	
}