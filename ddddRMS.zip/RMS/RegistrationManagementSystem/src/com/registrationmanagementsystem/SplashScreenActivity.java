package com.registrationmanagementsystem;

import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;

public class SplashScreenActivity extends Activity {
	
	private static final String TAG = SplashScreenActivity.class.getName();

	protected boolean _active = true;
	protected int _splashTime = 3000; // time to display the splash screen in ms
	DataBaseHelper mDbHelper;
	String android_id;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		setContentView(R.layout.splash_screen);

		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());
		try {
			System.out.println("testdb: splash screen");
			mDbHelper.createDataBase();
			mDbHelper.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		new Global(SplashScreenActivity.this);
		
		Thread splashTread = new Thread() {
			@Override
			public void run() {
				try {
					int waited = 0;
					while (_active && (waited < _splashTime)) {
						sleep(100);
						if (_active) {
							waited += 100;
						}
					}
				} catch (Exception e) {

				} finally {
					if(Global.USER_EMAIL!=null) {
//						Intent m_intent = new Intent(SplashScreenActivity.this,
//								NavMainActivity.class);
						Intent m_intent = new Intent(SplashScreenActivity.this,
								MainHomeActivity.class);
						startActivity(m_intent);
					} else {
						Intent m_intent = new Intent(SplashScreenActivity.this,
								SignInActivity.class);
						startActivity(m_intent);
					}
					finish();
				}
			};
		};
		splashTread.start();
	}
}