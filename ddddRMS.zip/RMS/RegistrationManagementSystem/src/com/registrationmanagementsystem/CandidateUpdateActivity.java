package com.registrationmanagementsystem;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.util.SparseArray;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.registrationmanagementsystem.UpdateIndustryActivity.RegionAsyncTask;
import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.APDesTrade;
import com.registrationmanagementsystem.model.APInstitute;
import com.registrationmanagementsystem.model.CandidateCategory;
import com.registrationmanagementsystem.model.Caste;
import com.registrationmanagementsystem.model.Designation;
import com.registrationmanagementsystem.model.District;
import com.registrationmanagementsystem.model.Genders;
import com.registrationmanagementsystem.model.IkvkBatch;
import com.registrationmanagementsystem.model.IkvkCenter;
import com.registrationmanagementsystem.model.IkvkCourse;
import com.registrationmanagementsystem.model.IkvkShift;
import com.registrationmanagementsystem.model.Moduleskill;
import com.registrationmanagementsystem.model.Region;
import com.registrationmanagementsystem.model.ReleventSector;
import com.registrationmanagementsystem.model.States;
import com.registrationmanagementsystem.model.Taluka;

public class CandidateUpdateActivity extends ActionBarActivity{
	private static final String TAG = CandidateUpdateActivity.class.getName();

	public static String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
	public static final int REQUEST_CODE_GALLERY = 0x1;
	public static final int REQUEST_CODE_TAKE_PICTURE = 0x2;
	public static final int REQUEST_CODE_CROP_IMAGE = 0x3;
	public static final int CROP_PIC = 0x4;

	private File mFileTemp;

	private ArrayList<String> m_CandidateCategoryDisplay = new ArrayList<String>();
	private ArrayList<CandidateCategory> m_CandidateCategory = new ArrayList<CandidateCategory>();
	private ArrayList<String> m_StateDisplay = new ArrayList<String>();
	private ArrayList<States> m_State = new ArrayList<States>();
	private ArrayList<String> m_DistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_District = new ArrayList<District>();
	private ArrayList<String> m_TalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_Taluka = new ArrayList<Taluka>();
	
	
	private ArrayList<String> m_GenderDisplay = new ArrayList<String>();
	private ArrayList<Genders> m_Gender = new ArrayList<Genders>();
	private ArrayList<String> m_CasteDisplay = new ArrayList<String>();
	private ArrayList<Caste> m_Caste = new ArrayList<Caste>();
	private ArrayList<String> m_DesignationDisplay = new ArrayList<String>();
	private ArrayList<Designation> m_Designation = new ArrayList<Designation>();

	private boolean doSavePicUri = false;

	RelativeLayout rlvIkvk, rlvSkill, rlvApprentice;
	ImageView imgUserPic;
	EditText etxFirstName, etxMiddleName, etxLastName, etxFmhName, etxAddress,etxCity, etxPincode, etxMobile, etxLline, etxPhysical, etxEmail,etxBday;
	CheckBox chkPhysical, chkExArmy, chkWidow, chkDivorcee, chkMinority,chkBpl;
	Button btnSubmit;
	Spinner spCandidateCategory, spCaste, spGender, spState, spDistrict, spTaluka, spDesignation;
	DataBaseHelper mDbHelper;
	CompressImage compressImage;
	Location location;
	//	double ImcLat;
	//	double ImcLon;
	ActionBar actionBar;

	TextView tvDesignatedTradecolorasterisk,tvDesignatedTrade;
	String designationValue;

	private Uri picUri;
	Uri mImageCaptureUri = null;
	int spinnerSetGuj;

	String datePicker = "";

	/***
	 * New Parameters IKVK Category
	 */
	Switch ch_ikvk_ApplicantType; 
	Spinner spikvk_Course,spiKVKCenter,spPreferredShift,spBatch;
	EditText txtTraining_StartDate,txtTraining_EndDate;

	private ArrayList<String> m_IkvkCourseDisplay = new ArrayList<String>();
	private ArrayList<IkvkCourse> m_IkvkCourse = new ArrayList<IkvkCourse>();
	private ArrayList<String> m_IkvkCentreDisplay = new ArrayList<String>();
	private ArrayList<IkvkCenter> m_IkvkCentre = new ArrayList<IkvkCenter>();
	private ArrayList<String> m_IkvkShiftDisplay = new ArrayList<String>();
	private ArrayList<IkvkShift> m_IKvkShift = new ArrayList<IkvkShift>();

	private ArrayList<String> m_BatchesDisplay = new ArrayList<String>();
	private ArrayList<IkvkBatch> m_Batches = new ArrayList<IkvkBatch>();

	/***
	 * New Parameters Industry Category
	 */
	EditText txtind_Name,txtadname,txtcontact,txtSCEmail,txtPhone;
	Spinner spSCRegion,spSCDistrict,spSCTaluka,spSCRelevantSector,spSCModuleSkill;

	private ArrayList<String> m_SCRegionDisplay = new ArrayList<String>();
	private ArrayList<Region> m_SCRegion = new ArrayList<Region>();
	private ArrayList<String> m_SCDistrictDisplay = new ArrayList<String>();
	private ArrayList<District> m_SCDistricts = new ArrayList<District>();	
	private ArrayList<String> m_SCTalukaDisplay = new ArrayList<String>();
	private ArrayList<Taluka> m_SCTaluka = new ArrayList<Taluka>();
	private ArrayList<String> m_SCRelevantSectorDisplay = new ArrayList<String>();
	private ArrayList<ReleventSector> m_SCRelevantSector = new ArrayList<ReleventSector>();	
	private ArrayList<String> m_SCModuleSkillDisplay = new ArrayList<String>();
	private ArrayList<Moduleskill> m_SCModuleskill= new ArrayList<Moduleskill>();

	/***
	 * New Parameters Apprentice
	 */


	Switch ch_app_ApplicantType;
	EditText txtappSeatNumber,txtJoiningDate,txtCompletionDate,txtRegistrationNumber,txtDateofRegistration;
	Spinner spAPDesignatedTrade, spAPInstitute;

	private ArrayList<String> m_APDesignatedTradeDisplay = new ArrayList<String>();
	private ArrayList<APDesTrade> m_APDesignatedTrade = new ArrayList<APDesTrade>();
	private ArrayList<String> m_APInstituteDisplay = new ArrayList<String>();
	private ArrayList<APInstitute> m_APInstitute = new ArrayList<APInstitute>();

	private int positionCandidateCategory = 0;	

	/*
	 * For update
	 */
	String _id;
	int cateogry_id;

	/*
	 * Logic for showing saved data from spinner of District and Taluka.
	 * 
	 * Else due to setOnItemSelectedListener, values will be lost. 
	 */
	boolean isStateClicked = false;
	boolean isDistrictClicked = false;
	String toSetDistrictDisplay;
	String toSetTalukaDisplay;


	boolean isStateClicked_other = false;
	boolean isDistrictClicked_other = false;
	String toSetDistrictDisplay_other;
	String toSetTalukaDisplay_other;


	boolean isSectorClicked_other = false;
	String toSetSectorDisplay_other;


	TextView tvtitle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//		setContentView(R.layout.activity_update_detail);
		setContentView(R.layout.activity_registration);

		Bundle getBundle = this.getIntent().getExtras();
		if (getBundle != null) {
			_id = getBundle.getString(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID);
			cateogry_id = getBundle.getInt(DataBaseHelper.KEY_APPLICANT_CATEGORY_ID);
			Log.i(TAG, "_id  = " + _id);
			Log.i(TAG, "cateogry_id = " + cateogry_id);
		}

		// get action bar
		ActionBar actionBar = getSupportActionBar();

		// Enabling Up / Back navigation
		actionBar.setDisplayHomeAsUpEnabled(true);

		doSavePicUri = false;

		mDbHelper = DataBaseHelper.getInstance(CandidateUpdateActivity.this);

		tvtitle = (TextView)findViewById(R.id.title);
		tvtitle.setText(getResources().getString(R.string.candidate_edit_registration));

		etxFirstName = (EditText) findViewById(R.id.txtFname);
		etxMiddleName = (EditText)findViewById(R.id.txtMname);
		etxLastName = (EditText)findViewById(R.id.txtLname);
		etxFmhName = (EditText) findViewById(R.id.txtfhname);
		etxAddress = (EditText) findViewById(R.id.txtadname);

		spDesignation = (Spinner)  findViewById(R.id.spDesignation);


		/**
		 * New Initialization
		 */
		/*
		 * IKVK
		 */
		ch_ikvk_ApplicantType  = (Switch) findViewById(R.id.ch_ikvk_ApplicantType);
		spikvk_Course= (Spinner) findViewById(R.id.spikvk_Course);
		spiKVKCenter = (Spinner) findViewById(R.id.spiKVKCenter);
		spPreferredShift = (Spinner) findViewById(R.id.spPreferredShift);
		spBatch = (Spinner) findViewById(R.id.spBatch);
		txtTraining_StartDate= (EditText) findViewById(R.id.txtTraining_StartDate);
		txtTraining_EndDate= (EditText) findViewById(R.id.txtTraining_EndDate);

		/*
		 * Skill Certification
		 */
		txtind_Name= (EditText) findViewById(R.id.txtind_Name);
		txtadname= (EditText) findViewById(R.id.txtadname_sc);
		txtcontact= (EditText) findViewById(R.id.txtcontact);
		txtSCEmail= (EditText) findViewById(R.id.txtSCEmail);
		txtPhone = (EditText) findViewById(R.id.txtPhone);
		spSCRegion = (Spinner) findViewById(R.id.sprname);
		spSCDistrict = (Spinner) findViewById(R.id.spsdname);
		spSCTaluka = (Spinner) findViewById(R.id.spSCtalukaname);
		spSCRelevantSector = (Spinner) findViewById(R.id.spRelevantSector);
		spSCModuleSkill = (Spinner) findViewById(R.id.spModuleSkill);

		/*
		 * Apprentice
		 */
		ch_app_ApplicantType = (Switch) findViewById(R.id.ch_app_ApplicantType);
		txtappSeatNumber= (EditText) findViewById(R.id.txtappSeatNumber);
		txtJoiningDate= (EditText) findViewById(R.id.txtJoiningDate);
		txtCompletionDate= (EditText) findViewById(R.id.txtCompletionDate);
		txtRegistrationNumber= (EditText) findViewById(R.id.txtRegistrationNumber);
		txtDateofRegistration= (EditText) findViewById(R.id.txtDateofRegistration);
		spAPInstitute= (Spinner) findViewById(R.id.spapp_Institute);
		spAPDesignatedTrade  = (Spinner) findViewById(R.id.spDesignatedTrade);
		tvDesignatedTradecolorasterisk  = (TextView) findViewById(R.id.tvDesignatedTradecolorasterisk);
		tvDesignatedTrade  = (TextView) findViewById(R.id.tvDesignatedTrade);


		etxAddress.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (v.getId() == R.id.txtadname) {
					v.getParent().requestDisallowInterceptTouchEvent(true);
					switch (event.getAction() & MotionEvent.ACTION_MASK) {
					case MotionEvent.ACTION_UP:
						v.getParent().requestDisallowInterceptTouchEvent(false);
						break;
					}
				}
				return false;
			}
		});

		etxCity = (EditText) findViewById(R.id.txtcityname);
		etxPincode = (EditText) findViewById(R.id.txtpincodename);
		etxMobile = (EditText) findViewById(R.id.txtMobname);
		etxLline = (EditText) findViewById(R.id.txtlandlinename);
		etxPhysical = (EditText) findViewById(R.id.txtPhysicalname);
		etxEmail = (EditText) findViewById(R.id.txtEmail);
		etxBday = (EditText)findViewById(R.id.txtBirthdate);

		chkPhysical = (CheckBox) findViewById(R.id.chPhysicalname);
		chkExArmy = (CheckBox) findViewById(R.id.chExarmy);
		chkWidow = (CheckBox) findViewById(R.id.chWidow);
		chkDivorcee = (CheckBox) findViewById(R.id.chDivorcee);
		chkMinority = (CheckBox) findViewById(R.id.chMinority);
		chkBpl = (CheckBox) findViewById(R.id.chBpl);

		spCandidateCategory = (Spinner) findViewById(R.id.spCandidateCategory);
		spDistrict = (Spinner) findViewById(R.id.spdname);
		spState = (Spinner) findViewById(R.id.spsname);
		spGender = (Spinner) findViewById(R.id.spGendername);
		spCaste = (Spinner) findViewById(R.id.spCastename);
		spTaluka = (Spinner) findViewById(R.id.sptalukaname);

		rlvIkvk = (RelativeLayout) findViewById(R.id.ikvk);
		rlvSkill = (RelativeLayout) findViewById(R.id.skillcertification);
		rlvApprentice = (RelativeLayout) findViewById(R.id.apprentice);

		new CandidateCategoryAsyncTask().execute();
		new StateAsyncTask().execute();
		new GenderAsyncTask().execute();
		new CasteAsyncTask().execute();
		new DesignationAsyncTask().execute();

		imgUserPic = (ImageView) findViewById(R.id.list_image);
		imgUserPic.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				/*				if(gps.canGetLocation())
				{
					Log.e(TAG, "testgps: imgUserPic if gps.canGetLocation()" + gps.canGetLocation());
					selectImage();
				}
				else
				{
					Log.e(TAG, "testgps: imgUserPic else gps.canGetLocation()" + gps.canGetLocation());
					gps.showSettingsAlert();
				}*/
				//				selectImage();
			}
		});

		btnSubmit = (Button) findViewById(R.id.btnSubmit);
		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				updateUserData();
			}
		});

		spCandidateCategory.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				Log.i("check", "position == " + position);
				positionCandidateCategory = position;
				if(position==1) {
					rlvIkvk.setVisibility(View.VISIBLE);
					rlvSkill.setVisibility(View.GONE);
					rlvApprentice.setVisibility(View.GONE);

					tvDesignatedTradecolorasterisk.setVisibility(View.GONE);
					tvDesignatedTrade.setVisibility(View.GONE);
					spAPDesignatedTrade.setVisibility(View.GONE);

					viewInitIkvk();
				} else if(position == 2) {
					rlvIkvk.setVisibility(View.GONE);
					rlvSkill.setVisibility(View.VISIBLE);
					rlvApprentice.setVisibility(View.GONE);			

					tvDesignatedTradecolorasterisk.setVisibility(View.GONE);
					tvDesignatedTrade.setVisibility(View.GONE);
					spAPDesignatedTrade.setVisibility(View.GONE);
					viewInitSC();
				} else if (position == 3) {
					rlvIkvk.setVisibility(View.GONE);
					rlvSkill.setVisibility(View.GONE);
					rlvApprentice.setVisibility(View.VISIBLE);

					tvDesignatedTradecolorasterisk.setVisibility(View.VISIBLE);
					tvDesignatedTrade.setVisibility(View.VISIBLE);
					spAPDesignatedTrade.setVisibility(View.VISIBLE);
					viewInitAP();
				} else {
					rlvIkvk.setVisibility(View.GONE);
					rlvSkill.setVisibility(View.GONE);
					rlvApprentice.setVisibility(View.GONE);

					tvDesignatedTradecolorasterisk.setVisibility(View.GONE);
					tvDesignatedTrade.setVisibility(View.GONE);
					spAPDesignatedTrade.setVisibility(View.GONE);
				}
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		/*
		 * Requires so that user can not change the value
		 */
		spCandidateCategory.setClickable(false);


		spState.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP) {
					isStateClicked = true;
				}
				return false;
			}
		});

		spState.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		spDistrict.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP) {
					isDistrictClicked = true;
				}
				return false;
			}
		});

		spDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spDistrict onItemSelected");
				setTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});

		etxBday.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "etxBday";
				datePicker();
			}
		});

		txtTraining_StartDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtTraining_StartDate";
				datePicker();
			}
		});

		txtTraining_EndDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtTraining_EndDate";
				datePicker();
			}
		});

		txtJoiningDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtJoiningDate";
				datePicker();
			}
		});

		txtCompletionDate.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtCompletionDate";
				datePicker();
			}
		});

		txtDateofRegistration.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				datePicker = "txtDateofRegistration";
				datePicker();
			}
		});


		spSCRegion.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP) {
					isStateClicked_other = true;
				}
				return false;
			}
		});
		//		 skill certification
		spSCRegion.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setSCDistrict();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});


		spSCDistrict.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP) {
					isDistrictClicked_other = true;
				}
				return false;
			}
		});
		spSCDistrict.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setSCTaluka();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});


		spSCRelevantSector.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if (event.getAction() == MotionEvent.ACTION_UP) {

					isSectorClicked_other = true;
				}
				return false;
			}
		});
		spSCRelevantSector.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				//				Log.e(TAG, "spState onItemSelected");
				setSCModuleSkill();
			}

			public void onNothingSelected(AdapterView<?> parent) {

			}
		});
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public void datePicker() {
		DialogFragment newFragment = new SelectDateFragment();
		newFragment.show(getSupportFragmentManager(), "DatePicker");
	}

	public class SelectDateFragment extends DialogFragment implements
	DatePickerDialog.OnDateSetListener {
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {
			Calendar calendar = Calendar.getInstance();
			int yy = calendar.get(Calendar.YEAR);
			int mm = calendar.get(Calendar.MONTH);
			int dd = calendar.get(Calendar.DAY_OF_MONTH);
			DatePickerDialog d = new DatePickerDialog(CandidateUpdateActivity.this, this, yy,
					mm, dd);
			calendar.set(yy, mm, dd - 1);
			d.getDatePicker().setMaxDate(calendar.getTimeInMillis());
			return d;
		}

		public void onDateSet(DatePicker view, int yy, int mm, int dd) {
			populateSetDate(yy, mm + 1, dd);
		}
	}

	public void populateSetDate(int year, int month, int day) {
		Log.i(TAG, "datePicker = " + datePicker);
		if(datePicker.equalsIgnoreCase("etxBday")) {
			etxBday.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtTraining_StartDate")) {
			txtTraining_StartDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtTraining_EndDate")) {
			txtTraining_EndDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtJoiningDate")) {
			txtJoiningDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtCompletionDate")) {
			txtCompletionDate.setText(month + "/" + day + "/" + year);
		} else if(datePicker.equalsIgnoreCase("txtDateofRegistration")) {
			txtDateofRegistration.setText(month + "/" + day + "/" + year);
		}
	}



	/*
	 * To get data from database
	 */

	public class CandidateCategoryAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_CandidateCategoryDisplay!=null) {
				m_CandidateCategoryDisplay.clear();
			}
			if(m_CandidateCategory!=null) {
				m_CandidateCategory.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_candidate_category);
			if (table_length > 0) {
				System.out
				.println("TESTDB: CandidateCategoryAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_candidate_category, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					CandidateCategory candidateCategory = new CandidateCategory();
					candidateCategory.setCategoryName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_category_name)));
					candidateCategory
					.setCategoryValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_category_value)));
					m_CandidateCategoryDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_category_name)));
					m_CandidateCategory.add(candidateCategory);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> candidateCategoryAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item,
					m_CandidateCategoryDisplay);
			// set the view for the Drop down list
			candidateCategoryAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spCandidateCategory.setAdapter(candidateCategoryAdapter);
			if(cateogry_id == 49) {
				spCandidateCategory.setSelection(1);				
			} else if(cateogry_id == 50) {
				spCandidateCategory.setSelection(2);
			} else if(cateogry_id == 51) {
				spCandidateCategory.setSelection(3);
			} 
			updateAsyncCallback.onTaskDone("CandidateCategoryAsyncTask");
		}
	}

	public class StateAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_StateDisplay!=null) {
				m_StateDisplay.clear();
			}
			if(m_State!=null) {
				m_State.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_State);
			if (table_length > 0) {
				System.out
				.println("TESTDB: StateAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_State, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					States states = new States();
					states.setStateName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					states.setStateValues(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_value)));
					m_StateDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_state_name)));
					m_State.add(states);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}
			//
			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> stateAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_StateDisplay);
			// set the view for the Drop down list
			stateAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spState.setAdapter(stateAdapter);
			updateAsyncCallback.onTaskDone("StateAsyncTask");
		}
	}

	public class DistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_DistrictDisplay!=null) {
				m_DistrictDisplay.clear();
			}
			if(m_District!=null) {
				m_District.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DistrictAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_state_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_state_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_DistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_District.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_DistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDistrict.setAdapter(districtAdapter);

			if(isStateClicked == false) {
				Log.e(TAG, "isStateClicked= " + isStateClicked);
				Log.e(TAG, "toSetDistrictDisplay = " + toSetDistrictDisplay);

				spDistrict.setSelection(m_DistrictDisplay
						.indexOf(toSetDistrictDisplay));
			}

			updateAsyncCallback.onTaskDone("DistrictAsyncTask");
		}
	}

	public class TalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_TalukaDisplay!=null) {
				m_TalukaDisplay.clear();
			}
			if(m_Taluka!=null) {
				m_Taluka.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: TalukaAsyncTask if - read from table table_length = "
						+ table_length);

				//				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_TalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_Taluka.add(taluka);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_TalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spTaluka.setAdapter(talukaAdapter);

			if(isDistrictClicked == false) {
				Log.e(TAG, "isDistrictClicked= " + isDistrictClicked);
				spTaluka.setSelection(m_TalukaDisplay
						.indexOf(toSetTalukaDisplay));
			}

			updateAsyncCallback.onTaskDone("TalukaAsyncTask");
		}
	}

	public class GenderAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_GenderDisplay!=null) {
				m_GenderDisplay.clear();
			}
			if(m_Gender!=null) {
				m_Gender.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Gender);
			if (table_length > 0) {
				System.out
				.println("TESTDB: GenderAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Gender, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Genders genders = new Genders();
					genders.setGenderName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_gender_name)));
					genders.setGenderValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_gender_value)));
					m_GenderDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_gender_name)));
					m_Gender.add(genders);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> genderAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_GenderDisplay);
			// set the view for the Drop down list
			genderAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spGender.setAdapter(genderAdapter);
			updateAsyncCallback.onTaskDone("GenderAsyncTask");
		}
	}

	public class CasteAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_CasteDisplay!=null) {
				m_CasteDisplay.clear();
			}
			if(m_Caste!=null) {
				m_Caste.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Caste);
			if (table_length > 0) {
				System.out
				.println("TESTDB: CasteAsyncTask if - read from table table_length = "
						+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Caste, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Caste caste = new Caste();
					caste.setCasteName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_caste_name)));
					caste.setCasteValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_caste_value)));
					m_CasteDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_caste_name)));
					m_Caste.add(caste);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> casteAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_CasteDisplay);
			// set the view for the Drop down list
			casteAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spCaste.setAdapter(casteAdapter);
			updateAsyncCallback.onTaskDone("CasteAsyncTask");
		}
	}


	public class DesignationAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_DesignationDisplay!=null) {
				m_DesignationDisplay.clear();
			}
			if(m_Designation!=null) {
				m_Designation.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Designation);
			if (table_length > 0) {
				System.out
				.println("TESTDB: DesignationAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Designation, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Designation designation = new Designation();
					designation.setDesignation_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_value)));
					designation.setDesignation_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_DesignationDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_designation_name)));
					m_Designation.add(designation);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> designationAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_DesignationDisplay);
			// set the view for the Drop down list
			designationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spDesignation.setAdapter(designationAdapter);
			updateAsyncCallback.onTaskDone("DesignationAsyncTask");
		}
	}

	private void setDistrict() {
		try
		{
			String tmpSataeName = spState.getSelectedItem().toString();

			SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

			Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_State + " where " + DataBaseHelper.KEY_state_name + " = '" + tmpSataeName +"'" , null);
			result.moveToFirst();
			String tmpStateId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_state_value));

			if(!result.isClosed()) {
				result.close();				
			}
			new DistrictAsyncTask().execute(tmpStateId);
		}
		catch(Exception e)
		{

		}
	}

	private void setTaluka() {
		try
		{
			String tmpDistrictName = spDistrict.getSelectedItem().toString();

			SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

			Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
			result.moveToFirst();
			String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));



			if(!result.isClosed()) {
				result.close();				
			}
			new TalukaAsyncTask().execute(tmpDistrictId);
		}
		catch(Exception e)
		{

		}
	}

	/*
	 * Ikvk valus set 
	 */
	//	TODO initialization for iIKVK
	private void viewInitIkvk() {
		new IKVKCourseAsyncTask().execute();
		new IKVKCentreAsyncTask().execute();
		new IKVKShiftAsyncTask().execute();
		new BatchesAsyncTask().execute();
	}

	public class IKVKCourseAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_IkvkCourseDisplay!=null) {
				m_IkvkCourseDisplay.clear();
			}
			if(m_IkvkCourse!=null) {
				m_IkvkCourse.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_COURSE_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IKVKCourseAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_COURSE_MASTER, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkCourse ikvkCourse = new IkvkCourse();
					ikvkCourse.setCOURSE_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_CODE)));
					ikvkCourse.setCOURSE_NAME(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_NAME)));
					m_IkvkCourseDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_NAME)));
					m_IkvkCourse.add(ikvkCourse);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> ikvkCouesAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_IkvkCourseDisplay);
			// set the view for the Drop down list
			ikvkCouesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spikvk_Course.setAdapter(ikvkCouesAdapter);
			updateAsyncCallback.onTaskDone("IKVKCourseAsyncTask");
		}
	}


	public class IKVKCentreAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_IkvkCentreDisplay!=null) {
				m_IkvkCentreDisplay.clear();
			}
			if(m_IkvkCentre!=null) {
				m_IkvkCentre.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_ESTABLISHMENT_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IKVKCentreAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkCenter ikvkCenter = new IkvkCenter();
					ikvkCenter.setESTABLISHMENT_NO(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_NO)));
					ikvkCenter.setESTABLISHMENT_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_CODE)));
					ikvkCenter.setESTABLISHMENT_NAME_E(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_NAME_E)));
					m_IkvkCentreDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ESTABLISHMENT_NAME_E)));
					m_IkvkCentre.add(ikvkCenter);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> ikvkCenterAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_IkvkCentreDisplay);
			// set the view for the Drop down list
			ikvkCenterAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spiKVKCenter.setAdapter(ikvkCenterAdapter);
			updateAsyncCallback.onTaskDone("IKVKCentreAsyncTask");
		}
	}

	public class IKVKShiftAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_IkvkShiftDisplay!=null) {
				m_IkvkShiftDisplay.clear();
			}
			if(m_IKvkShift!=null) {
				m_IKvkShift.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Preferredshift);
			if (table_length > 0) {
				System.out
				.println("TESTDB: IKVKShiftAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_Preferredshift, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkShift ikvkShift = new IkvkShift();
					ikvkShift.setREF_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Preferredshift)));
					ikvkShift.setPREFERRED_SHIFT(result.getString(result.getColumnIndex(DataBaseHelper.KEY_PREFERRED_SHIFT)));
					m_IkvkShiftDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_PREFERRED_SHIFT)));
					m_IKvkShift.add(ikvkShift);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> ikvkShiftAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_IkvkShiftDisplay);
			// set the view for the Drop down list
			ikvkShiftAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spPreferredShift.setAdapter(ikvkShiftAdapter);
			updateAsyncCallback.onTaskDone("IKVKShiftAsyncTask");
		}
	}



	/**
	 * 
	 * Newly Added Batches Asynctask
	 *
	 */

	public class BatchesAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_BatchesDisplay!=null) {
				m_BatchesDisplay.clear();
			}
			if(m_Batches!=null) {
				m_Batches.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_BATCH);
			if (table_length > 0) {
				System.out
				.println("TESTDB: BatchAsynctask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "+ DataBaseHelper.TABLE_BATCH, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					IkvkBatch ikvkbatch = new IkvkBatch();
					ikvkbatch.setBatch_value(result.getString(result.getColumnIndex(DataBaseHelper.KEY_BATCH_VALUES)));
					ikvkbatch.setBatch_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_BATCH_NAME)));
					m_BatchesDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_BATCH_NAME)));
					m_Batches.add(ikvkbatch);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> designationAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_BatchesDisplay);
			// set the view for the Drop down list
			designationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spBatch.setAdapter(designationAdapter);

		}
	}

	// TODO initialization for Skill Certification	
	/*
	 * Skill Certification
	 */
	private void viewInitSC() {
		new SCRegionAsyncTask().execute();
		new SCRelevantSectorAsyncTask().execute();
	}
	public class SCRegionAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCRegionDisplay!=null) {
				m_SCRegionDisplay.clear();
			}
			if(m_SCRegion!=null) {
				m_SCRegion.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Region);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCRegionAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Region, null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Region region = new Region();
					region.setRegion_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value)));
					region.setRegion_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_SCRegionDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_name)));
					m_SCRegion.add(region);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> regionAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_SCRegionDisplay);
			// set the view for the Drop down list
			regionAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCRegion.setAdapter(regionAdapter);
			updateAsyncCallback.onTaskDone("SCRegionAsyncTask");
		}
	}

	/**
	 * 
	 * District Skill Certification
	 *
	 */
	public class SCDistrictAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCDistrictDisplay !=null) {
				m_SCDistrictDisplay .clear();
			}
			if(m_SCDistricts !=null) {
				m_SCDistricts.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_District);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCDistrictAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_region_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_district_region_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					District district = new District();
					district.setDistrictName(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					district.setDistrictValue(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_value)));
					m_SCDistrictDisplay.add(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_district_name)));
					m_SCDistricts.add(district);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;	
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> districtAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_SCDistrictDisplay);
			// set the view for the Drop down list
			districtAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCDistrict.setAdapter(districtAdapter);


			if(isStateClicked_other == false) {
				Log.e(TAG, "isStateClicked_other= " + isStateClicked_other);
				Log.e(TAG, "toSetDistrictDisplay_other = " + toSetDistrictDisplay_other);

				spSCDistrict.setSelection(m_SCDistrictDisplay
						.indexOf(toSetDistrictDisplay_other));
			}

			updateAsyncCallback.onTaskDone("SCDistrictAsyncTask");
		}
	}	

	/**
	 * 
	 * Taluka Skill Certification
	 *
	 */
	public class SCTalukaAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCTalukaDisplay!=null) {
				m_SCTalukaDisplay.clear();
			}
			if(m_SCTaluka!=null) {
				m_SCTaluka.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Taluka);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCTalukaAsyncTask if - read from table table_length = "
						+ table_length);

				//				Log.e(TAG, "arg0[0] = " + arg0[0]);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Taluka + " where " + DataBaseHelper.KEY_taluka_district_id + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_taluka_district_id + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Taluka taluka = new Taluka();
					taluka.setTaluka_values(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_id)));
					taluka.setTaluka_name(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_SCTalukaDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_taluka_taluka_name_e)));
					m_SCTaluka.add(taluka);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> talukaAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_SCTalukaDisplay);
			// set the view for the Drop down list
			talukaAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCTaluka.setAdapter(talukaAdapter);
		

			if(isDistrictClicked_other == false) {
				Log.e(TAG, "toSetTalukaDisplay_other set value= " + toSetTalukaDisplay_other);
				spSCTaluka.setSelection(m_SCTalukaDisplay
						.indexOf(toSetTalukaDisplay_other));
			}

			updateAsyncCallback.onTaskDone("SCTalukaAsyncTask");
		}
	}

	public class SCRelevantSectorAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCRelevantSectorDisplay!=null) {
				m_SCRelevantSectorDisplay.clear();
			}
			if(m_SCRelevantSector!=null) {
				m_SCRelevantSector.clear();
			}
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Sector_Master);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCRelevantSectorAsyncTask if - read from table table_length = "
						+ table_length);

				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Sector_Master, null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					ReleventSector releventSector = new ReleventSector();
					releventSector.setREF_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Sector_Master)));
					releventSector.setCOURSE_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_COURSE_CODE_Sector_Master)));
					releventSector.setSECTOR_NAME(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SECTOR_NAME)));

					m_SCRelevantSectorDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SECTOR_NAME)));
					m_SCRelevantSector.add(releventSector);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> relevantSectorAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_SCRelevantSectorDisplay);
			// set the view for the Drop down list
			relevantSectorAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCRelevantSector.setAdapter(relevantSectorAdapter);
			updateAsyncCallback.onTaskDone("SCRelevantSectorAsyncTask");
		}
	}

	public class SCModuleSkillAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_SCModuleSkillDisplay!=null) {
				m_SCModuleSkillDisplay.clear();
			}
			if(m_SCModuleskill!=null) {
				m_SCModuleskill.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_Skill_Master);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SCModuleSkillAsyncTask if - read from table table_length = "
						+ table_length);

				Log.e(TAG, "arg0[0] skilllmODULE= " + arg0[0]);
				
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_Skill_Master + " where " + DataBaseHelper.KEY_SECTOR_ID + " = '" + arg0[0]+"' OR " + DataBaseHelper.KEY_SECTOR_ID + " = '-1'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					Moduleskill moduleskill = new Moduleskill();
					moduleskill.setSECTOR_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SECTOR_ID)));
					moduleskill.setSKILL_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SKILL_CODE)));
					moduleskill.setSKILL_NAME(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SKILL_NAME)));	
					moduleskill.setSKILL_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Skill_Master)));
					m_SCModuleSkillDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_SKILL_NAME)));
					m_SCModuleskill.add(moduleskill);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> moduleAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_SCModuleSkillDisplay);
			// set the view for the Drop down list
			moduleAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spSCModuleSkill.setAdapter(moduleAdapter);


			if(isSectorClicked_other == false) {
				Log.e(TAG, "toSetSectorDisplay_other= " + toSetSectorDisplay_other);
				spSCModuleSkill.setSelection(m_SCModuleSkillDisplay
						.indexOf(toSetSectorDisplay_other));
			}
			updateAsyncCallback.onTaskDone("SCModuleSkillAsyncTask");
		}
	}


	private void setSCDistrict() {
		String tmpRegionName = spSCRegion.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_Region + " where " + DataBaseHelper.KEY_region_name + " = '" + tmpRegionName +"'" , null);
		result.moveToFirst();
		String tmpRegionId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_region_value));


		System.out.println(">>>>>>>>>>>>>>>REGION _ ID"+tmpRegionId);


		if(!result.isClosed()) {
			result.close();				
		}
		new SCDistrictAsyncTask().execute(tmpRegionId); 			
	}

	private void setSCTaluka() {
		try
		{
		String tmpDistrictName = spSCDistrict.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_District + " where " + DataBaseHelper.KEY_district_name + " = '" + tmpDistrictName +"'" , null);
		result.moveToFirst();
		String tmpDistrictId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_district_value));

		
		
		if(!result.isClosed()) {
			result.close();				
		}
		new SCTalukaAsyncTask().execute(tmpDistrictId);
		
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private void setSCModuleSkill() {
		String tmpRelvantSectorName = spSCRelevantSector.getSelectedItem().toString();

		SQLiteDatabase dbR = mDbHelper.getReadableDatabase();

		Cursor result = dbR.rawQuery("select * from " +DataBaseHelper.TABLE_Sector_Master + " where " + DataBaseHelper.KEY_SECTOR_NAME + " = '" + tmpRelvantSectorName +"'" , null);
		result.moveToFirst();
		String tmpRelevantSectorId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Sector_Master));
		//		ADDED String tmpRelevantsKILLId = result.getString(result.getColumnIndex(DataBaseHelper.KEY_REF_ID_Skill_Master));

		if(!result.isClosed()) {
			result.close();				
		}
		new SCModuleSkillAsyncTask().execute(tmpRelevantSectorId); 			
	}

	//	TODO initialization for Apprentice
	private void viewInitAP() {
		new APDesignatedAsyncTask().execute();
		new APInstituteAsyncTask().execute();
	}

	public class APDesignatedAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_APDesignatedTradeDisplay!=null) {
				m_APDesignatedTradeDisplay.clear();
			}
			if(m_APDesignatedTrade!=null) {
				m_APDesignatedTrade.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_TRADE_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: APDesignatedAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_TRADE_MASTER, null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					APDesTrade apDesTrade = new APDesTrade();
					apDesTrade.setTRADE_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_TRADE_ID_TRADE_MASTER)));
					apDesTrade.setTRADE_NAME_E(result.getString(result.getColumnIndex(DataBaseHelper.KEY_TRADE_NAME_E)));
					m_APDesignatedTradeDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_TRADE_NAME_E)));
					m_APDesignatedTrade.add(apDesTrade);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> apDesginatedAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_APDesignatedTradeDisplay);
			// set the view for the Drop down list
			apDesginatedAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spAPDesignatedTrade.setAdapter(apDesginatedAdapter);
			updateAsyncCallback.onTaskDone("APDesignatedAsyncTask");
		}
	}

	public class APInstituteAsyncTask extends AsyncTask<String, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
			if(m_APInstituteDisplay!=null) {
				m_APInstituteDisplay.clear();
			}
			if(m_APInstitute!=null) {
				m_APInstitute.clear();
			}
		}

		@Override
		protected Void doInBackground(String... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_ITI_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: APInstituteAsyncTask if - read from table table_length = "
						+ table_length);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_ITI_MASTER, null);

				result.moveToFirst();
				while (result.isAfterLast() == false) {
					APInstitute apInstitute = new APInstitute();
					apInstitute.setITI_ID(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_ID_ITI_MASTER)));
					apInstitute.setITI_CODE(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_CODE)));
					apInstitute.setITI_NAME_E(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_NAME_E)));
					m_APInstituteDisplay.add(result.getString(result.getColumnIndex(DataBaseHelper.KEY_ITI_NAME_E)));
					m_APInstitute.add(apInstitute);

					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			ArrayAdapter<String> apInstituteAdapter = new ArrayAdapter<String>(
					CandidateUpdateActivity.this,
					android.R.layout.simple_spinner_item, m_APInstituteDisplay);
			// set the view for the Drop down list
			apInstituteAdapter
			.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			// set the ArrayAdapter to the spinner
			spAPInstitute.setAdapter(apInstituteAdapter);
			updateAsyncCallback.onTaskDone("APInstituteAsyncTask");
		}
	}

	// TODO update of data in new table
	private void updateUserData() {
		String errorMessage = "";
		boolean isInsertInDb = true;

		/*
		 * mandatory fields
		 */
		/*if (doSavePicUri == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_user_pic);
			isInsertInDb = false;
		}*/
		if (spCandidateCategory.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_client_cat);
			isInsertInDb = false;
		}
		if (etxFirstName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_fname);
			isInsertInDb = false;
		}
		/*if (etxMiddleName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mname);
			isInsertInDb = false;
		}*/
		if (etxLastName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_lname);
			isInsertInDb = false;
		}
		if (etxFmhName.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_fmhname);
			isInsertInDb = false;
		}
		if (etxAddress.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_address);
			isInsertInDb = false;
		}
		if (spState.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_state);
			isInsertInDb = false;
		}
		if (spDistrict.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_district);
			isInsertInDb = false;
		}
		if (spTaluka.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_taluka);
			isInsertInDb = false;
		}
		if (etxCity.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_city);
			isInsertInDb = false;
		}
		if (etxMobile.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_mobno);
			isInsertInDb = false;
		} else if(etxMobile.getText().toString().length()<10) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_mobno);
			isInsertInDb = false;			
		}
		if (spGender.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_gender);
			isInsertInDb = false;
		}
		if (spCaste.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_cast);
			isInsertInDb = false;
		}
		if (etxBday.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_bdy);
			isInsertInDb = false;
		}
		if (etxPincode.getText().toString().equalsIgnoreCase("") == false && etxPincode.getText().toString().length()<6) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_pinno);
			isInsertInDb = false;			
		}		
		if (etxEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(etxEmail.getText().toString()) == false) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_valid_email);
			isInsertInDb = false;			
		}

		if (spDesignation.getSelectedItemPosition() == 0) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_designation);
			isInsertInDb = false;
		}

		int intChkPhysical = chkPhysical.isChecked() ? 1 : 0;
		if (intChkPhysical == 1
				&& etxPhysical.getText().toString().equalsIgnoreCase("")) {
			errorMessage = errorMessage
					+ getResources().getString(R.string.err_msg_phical_perc);
			isInsertInDb = false;
		}

		int intChkExArmy = chkExArmy.isChecked() ? 1 : 0;
		int intChkWidow = chkWidow.isChecked() ? 1 : 0;
		int intChkDivorcee = chkDivorcee.isChecked() ? 1 : 0;
		int intChkMinority = chkMinority.isChecked() ? 1 : 0;
		int intChkBpl = chkBpl.isChecked() ? 1 : 0;

		// TODO validations for other details		
		if(positionCandidateCategory==1) {

			/*			ch_ikvk_ApplicantType  = (Switch)m_rootView. findViewById(R.id.ch_ikvk_ApplicantType);
					What to do ?
			 */

			if (spikvk_Course.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_courseikvkdetails);
				isInsertInDb = false;
			}
			if (spiKVKCenter.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_ikvkdetails);
				isInsertInDb = false;
			}
			if (spPreferredShift.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_shiftikvkdetails);
				isInsertInDb = false;
			}
			if (spBatch.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_batchesikvkdetails);
				isInsertInDb = false;
			}
			if (txtTraining_StartDate.getText().toString().equalsIgnoreCase(""))  {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_trainingstartdateikvkdetails);
				isInsertInDb = false;
			}
			if (txtTraining_EndDate.getText().toString().equalsIgnoreCase(""))  {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_trainingenddateikvkdetails);
				isInsertInDb = false;
			}

		} else if(positionCandidateCategory==2) {

			if (txtind_Name.getText().toString().equalsIgnoreCase(""))  {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_name);
				isInsertInDb = false;
			}

			if (txtSCEmail.getText().toString().equalsIgnoreCase("") == false && Global.checkEmail(txtSCEmail.getText().toString()) == false) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_email);
				isInsertInDb = false;			
			}

			/*	if(txtPhone.getText().toString().length()<10) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_phone);
				isInsertInDb = false;			
			}*/

			if (spSCRegion.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_region);
				isInsertInDb = false;
			}
			if (spSCDistrict.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_district);
				isInsertInDb = false;
			}
			if (spSCTaluka.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_taluka);
				isInsertInDb = false;
			}
			if (spSCRelevantSector.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_sector);
				isInsertInDb = false;
			}
			if (spSCModuleSkill.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_moduleskill);
				isInsertInDb = false;
			}

		} else if(positionCandidateCategory==3) {

			/*			ch_app_ApplicantType = (Switch)m_rootView. findViewById(R.id.ch_app_ApplicantType);
			 */

			if (spAPDesignatedTrade.getSelectedItemPosition() == 0) {
				errorMessage = errorMessage
						+ getResources().getString(R.string.err_msg_industry_apprentice_designationtrade);
				isInsertInDb = false;
			}

		}

		/*
		 * Non-mandatory fields
		 */
		if (isInsertInDb) {
			SQLiteDatabase db = mDbHelper.getWritableDatabase();
			// db.beginTransaction();
			System.out.println("Update in TABLE_APPLICANT_MASTER");
			// Insert in db
			ContentValues contentValues = new ContentValues();
			//			TODO
			contentValues.put(DataBaseHelper.KEY_APPLICANT_MASTER_user_email, Global.USER_EMAIL);

			/*
			 * Mandatory fields
			 */
			contentValues.put(DataBaseHelper.KEY_APPLICANT_CATEGORY_ID,
					m_CandidateCategory.get(spCandidateCategory.getSelectedItemPosition()).getCategoryValue());

			if (mFileTemp != null) {
				contentValues.put(DataBaseHelper.KEY_APPLICANT_PHOTO,
						mFileTemp.toString());
			}

			contentValues.put(DataBaseHelper.KEY_APPLICANT_FNAME_E, etxFirstName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_APPLICANT_MNAME_E, etxMiddleName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_APPLICANT_LNAME_E, etxLastName
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_APPLICANT_FATHER_NAME_E, etxFmhName.getText()
					.toString());
			contentValues.put(DataBaseHelper.KEY_ADDRESS_E, etxAddress.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_STATE_ID, 
					m_State.get(spState.getSelectedItemPosition()).getStateValues());

			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID_APPLCANT_MASTER,
					m_District.get(spDistrict.getSelectedItemPosition()).getDistrictValue());

			contentValues.put(DataBaseHelper.KEY_TALUKA_ID_APPLCANT_MASTER,
					m_Taluka.get(spTaluka.getSelectedItemPosition()).getTaluka_values());

			/**
			 * New Added Parameters
			 */

			contentValues.put(DataBaseHelper.KEY_STATE_ID_DISPLAY,spState.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID_APPLCANT_MASTER_DISPLAY,spDistrict.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_TALUKA_ID_APPLCANT_MASTER_DISPLAY,spTaluka.getSelectedItem().toString());





			contentValues.put(DataBaseHelper.KEY_CITY, etxCity.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_PINCODE, etxPincode.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_MOBILE_NO, etxMobile.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_LANDLINE_NO, etxLline.getText()
					.toString());
			
			contentValues.put(DataBaseHelper.KEY_GENDER, 
					m_Gender.get(spGender.getSelectedItemPosition()).getGenderValue());

			contentValues.put(DataBaseHelper.KEY_CASTE,
					m_Caste.get(spCaste.getSelectedItemPosition()).getCasteValue());

			contentValues.put(DataBaseHelper.KEY_PHYSICAL_HANDICAP, intChkPhysical);
			if (intChkPhysical == 1) {
				contentValues.put(DataBaseHelper.KEY_PH_VALUE, etxPhysical
						.getText().toString());
			} else {
				contentValues.put(DataBaseHelper.KEY_PH_VALUE, "");
			}

			contentValues.put(DataBaseHelper.KEY_EX_ARMY, intChkExArmy);
			contentValues.put(DataBaseHelper.KEY_WIDOW, intChkWidow);
			contentValues.put(DataBaseHelper.KEY_DIVORCEE, intChkDivorcee);
			contentValues.put(DataBaseHelper.KEY_MINORITY, intChkMinority);
			contentValues.put(DataBaseHelper.KEY_BPL, intChkBpl);

			contentValues.put(DataBaseHelper.KEY_EMAIL_ADDRESS, etxEmail.getText()
					.toString());

			contentValues.put(DataBaseHelper.KEY_BIRTH_DATE, etxBday.getText()
					.toString());



			/*			designationValue = m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_values();

			contentValues.put(DataBaseHelper.KEY_rca_designation_name, spDesignation.getSelectedItem().toString());
			contentValues.put(DataBaseHelper.KEY_rca_designation_value, designationValue);

			if(location!=null) {
				//				Log.i(TAG, "store from current location");
				System.out.println("ImcLatDB"+location.getLatitude());
				System.out.println("ImcLonDB"+location.getLongitude());
				contentValues.put(DataBaseHelper.KEY_rca_lattitude, Double.toString(location.getLatitude()));
				contentValues.put(DataBaseHelper.KEY_rca_longitude, Double.toString(location.getLongitude()));
			} else {
				//				Log.i(TAG, "store from default value");
				contentValues.put(DataBaseHelper.KEY_rca_lattitude, Global.getLat(CandidateUpdateActivity.this));
				contentValues.put(DataBaseHelper.KEY_rca_longitude, Global.getLng(CandidateUpdateActivity.this));
			}

			if(positionCandidateCategory==1) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_ikvk");
				db.insert(DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null, contentValues);
				insertInIkvk();
			} else if(positionCandidateCategory == 2) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_skillcerti");
				db.insert(DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null, contentValues);
				insertInSkill();
			} else if (positionCandidateCategory == 3) {
				contentValues.put(DataBaseHelper.KEY_rca_table_name, "candidate_apprentice");
				db.insert(DataBaseHelper.TABLE_ESTABLISHMENT_MASTER, null, contentValues);
				insertInApprentice();
			}	*/


			/***
			 * TO-Update
			 * Insertion code will not come here need to update
			 */
			//			db.insert(DataBaseHelper.TABLE_APPLICANT_MASTER, null, contentValues);
			db.update(DataBaseHelper.TABLE_APPLICANT_MASTER, contentValues,
					DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID +" = '"+ _id +"'",
					null);

			updateOtherDetails();

			/*etxFirstName.setText("");
			etxMiddleName.setText("");
			etxLastName.setText("");
			etxFmhName.setText("");
			etxAddress.setText("");
			etxCity.setText("");
			etxPincode.setText("");
			etxMobile.setText("");
			etxLline.setText("");
			etxPhysical.setText("");
			etxEmail.setText("");
			etxBday.setText("");

			chkPhysical.setChecked(false);
			chkExArmy.setChecked(false);
			chkWidow.setChecked(false);
			chkDivorcee.setChecked(false);
			chkMinority.setChecked(false);
			chkBpl.setChecked(false);

			spCandidateCategory.setSelection(0);
			spCaste.setSelection(0);
			spDistrict.setSelection(0);
			spGender.setSelection(0);
			spState.setSelection(0);
			
			spState.setSelection(spinnerSetGuj);
			
			imgUserPic.setImageResource(R.drawable.ic_add_user_image);
			 */

			Global.showAlertDialog(CandidateUpdateActivity.this, "Profile :",
					"Updated Successfully", false);


		} else {
			System.out.println("alert");
			Global.showAlertDialog(CandidateUpdateActivity.this,
					"Mandatory fields", errorMessage, false);
		}

	}

	//	TODO Insertation for other deatails

	private void updateOtherDetails() {
		SQLiteDatabase db = mDbHelper.getWritableDatabase();
		// db.beginTransaction();
		System.out.println("Update in TABLE_APPLICANT_REGS_OTHER_DETAILS");

/*		int lastEntered_Id = -1;
		long table_length = DatabaseUtils.queryNumEntries(db,DataBaseHelper.TABLE_APPLICANT_MASTER);
		if (table_length > 0) {
			System.out
			.println("TESTDB: insertInIkvk if - read from table table_length = "
					+ table_length);
			Cursor result = db.rawQuery("select REF_ID from "+ DataBaseHelper.TABLE_APPLICANT_MASTER, null);
			if(result!=null) {
				result.moveToLast();
				lastEntered_Id = result.getInt(result.getColumnIndex(DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID));
				Log.e(TAG, "lastEntered_Id = " + lastEntered_Id);
			}
			if (!result.isClosed()) {
				result.close();
			}
		}

		ContentValues contentValues = new ContentValues();
		contentValues.put(DataBaseHelper.KEY_APPLICANT_ID, lastEntered_Id);*/

		ContentValues contentValues = new ContentValues();
		
		if(positionCandidateCategory==1) {
			//			Switch ch_ikvk_ApplicantType; 
			//			Spinner spikvk_Course,spiKVKCenter,spPreferredShift,spBatch;
			//			EditText txtTraining_StartDate,txtTraining_EndDate;
			//
			//			private ArrayList<String> m_IkvkCourseDisplay = new ArrayList<String>();
			//			private ArrayList<IkvkCourse> m_IkvkCourse = new ArrayList<IkvkCourse>();
			//			private ArrayList<String> m_IkvkCentreDisplay = new ArrayList<String>();
			//			private ArrayList<IkvkCenter> m_IkvkCentre = new ArrayList<IkvkCenter>();
			//			private ArrayList<String> m_IkvkShiftDisplay = new ArrayList<String>();
			//			private ArrayList<IkvkShift> m_IKvkShift = new ArrayList<IkvkShift>();

			contentValues.put(DataBaseHelper.KEY_DESIGNATION, 
					m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_name());

			String str_ikvk_ApplicantType = ch_ikvk_ApplicantType.isChecked() ? getResources().getString(R.string.ikvk_fresher) : getResources().getString(R.string.ikvk_InHouse);
			contentValues.put(DataBaseHelper.KEY_APP_TYPE, str_ikvk_ApplicantType);

			contentValues.put(DataBaseHelper.KEY_COURSE_ID, 
					m_IkvkCourse.get(spikvk_Course.getSelectedItemPosition()).getCOURSE_CODE());
			contentValues.put(DataBaseHelper.KEY_COURSE_ID_DISPLAY, 
					m_IkvkCourse.get(spikvk_Course.getSelectedItemPosition()).getCOURSE_NAME());

			contentValues.put(DataBaseHelper.KEY_IKVK_CENTER_ID, 
					m_IkvkCentre.get(spiKVKCenter.getSelectedItemPosition()).getESTABLISHMENT_CODE());
			contentValues.put(DataBaseHelper.KEY_IKVK_CENTER_ID_DISPLAY, 
					m_IkvkCentre.get(spiKVKCenter.getSelectedItemPosition()).getESTABLISHMENT_NAME_E());

			contentValues.put(DataBaseHelper.KEY_SHIFT, 
					m_IKvkShift.get(spPreferredShift.getSelectedItemPosition()).getREF_ID());
			contentValues.put(DataBaseHelper.KEY_SHIFT_DISPLAY, 
					m_IKvkShift.get(spPreferredShift.getSelectedItemPosition()).getPREFERRED_SHIFT());

			contentValues.put(DataBaseHelper.KEY_BATCH_ID, 
					m_Batches.get(spBatch.getSelectedItemPosition()).getBatch_value());
						
			contentValues.put(DataBaseHelper.KEY_BATCH_ID_DISPLAY, 
					m_Batches.get(spBatch.getSelectedItemPosition()).getBatch_name());

			contentValues.put(DataBaseHelper.KEY_JOINING_DATE, txtTraining_StartDate
					.getText().toString());
			contentValues.put(DataBaseHelper.KEY_COMPLETION_DATE, txtTraining_EndDate.getText()
					.toString());
			
			db.update(DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS, contentValues,
					DataBaseHelper.KEY_APPLICANT_ID +" = '"+ _id +"'",
					null);

		} else if(positionCandidateCategory==2) {

			/***
			 * New Parameters Industry Category
			 */
			//			EditText txtind_Name,txtadname,txtcontact,txtSCEmail,txtPhone;
			//			Spinner spSCRegion,spSCDistrict,spSCTaluka,spSCRelevantSector,spSCModuleSkill;
			//
			//			private ArrayList<String> m_SCRegionDisplay = new ArrayList<String>();
			//			private ArrayList<Region> m_SCRegion = new ArrayList<Region>();
			//			private ArrayList<String> m_SCDistrictDisplay = new ArrayList<String>();
			//			private ArrayList<District> m_SCDistricts = new ArrayList<District>();	
			//			private ArrayList<String> m_SCTalukaDisplay = new ArrayList<String>();
			//			private ArrayList<Taluka> m_SCTaluka = new ArrayList<Taluka>();
			//			private ArrayList<String> m_SCRelevantSectorDisplay = new ArrayList<String>();
			//			private ArrayList<ReleventSector> m_SCRelevantSector = new ArrayList<ReleventSector>();	
			//			private ArrayList<String> m_SCModuleSkillDisplay = new ArrayList<String>();
			//			private ArrayList<Moduleskill> m_SCModuleskill= new ArrayList<Moduleskill>();

			contentValues.put(DataBaseHelper.KEY_DESIGNATION, 
					m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_name());

			contentValues.put(DataBaseHelper.KEY_EST_NAME, 
					txtind_Name.getText().toString());

			contentValues.put(DataBaseHelper.KEY_ADDRESS, 
					txtadname.getText().toString());

			contentValues.put(DataBaseHelper.KEY_CONTACT_PERSON, 
					txtcontact.getText().toString());

			contentValues.put(DataBaseHelper.KEY_EMAIL_ID, 
					txtSCEmail.getText().toString());

			contentValues.put(DataBaseHelper.KEY_PHONE_NO, 
					txtPhone.getText().toString());

			contentValues.put(DataBaseHelper.KEY_REGION_ID, 
					m_SCRegion.get(spSCRegion.getSelectedItemPosition()).getRegion_values());
			contentValues.put(DataBaseHelper.KEY_REGION_ID_DISPLAY, 
					m_SCRegion.get(spSCRegion.getSelectedItemPosition()).getRegion_name());

			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID, 
					m_SCDistricts.get(spSCDistrict.getSelectedItemPosition()).getDistrictValue());
			contentValues.put(DataBaseHelper.KEY_DISTRICT_ID_DISPLAY, 
					m_SCDistricts.get(spSCDistrict.getSelectedItemPosition()).getDistrictName());

			contentValues.put(DataBaseHelper.KEY_TALUKA_ID, 
					m_SCTaluka.get(spSCTaluka.getSelectedItemPosition()).getTaluka_values());
			contentValues.put(DataBaseHelper.KEY_TALUKA_ID_DISPLAY, 
					m_SCTaluka.get(spSCTaluka.getSelectedItemPosition()).getTaluka_name());

			contentValues.put(DataBaseHelper.KEY_RELEVANT_SECTOR, 
					m_SCRelevantSector.get(spSCRelevantSector.getSelectedItemPosition()).getREF_ID());
			contentValues.put(DataBaseHelper.KEY_RELEVANT_SECTOR_DISPLAY, 
					m_SCRelevantSector.get(spSCRelevantSector.getSelectedItemPosition()).getSECTOR_NAME());

			contentValues.put(DataBaseHelper.KEY_MODULE_SKILL, 
					m_SCModuleskill.get(spSCModuleSkill.getSelectedItemPosition()).getSKILL_ID());			
			contentValues.put(DataBaseHelper.KEY_MODULE_SKILL_DISPLAY, 
					m_SCModuleskill.get(spSCModuleSkill.getSelectedItemPosition()).getSKILL_NAME());			

			db.update(DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS, contentValues,
					DataBaseHelper.KEY_APPLICANT_ID +" = '"+ _id +"'",
					null);

		} else if(positionCandidateCategory==3) {
			//			Switch ch_app_ApplicantType;
			//			EditText txtappSeatNumber,txtJoiningDate,txtCompletionDate,txtRegistrationNumber,txtDateofRegistration;
			//			Spinner spAPDesignatedTrade, spAPInstitute;
			//
			//			private ArrayList<String> m_APDesignatedTradeDisplay = new ArrayList<String>();
			//			private ArrayList<APDesTrade> m_APDesignatedTrade = new ArrayList<APDesTrade>();
			//			private ArrayList<String> m_APInstituteDisplay = new ArrayList<String>();
			//			private ArrayList<APInstitute> m_APInstitute = new ArrayList<APInstitute>();

			contentValues.put(DataBaseHelper.KEY_DESIGNATION, 
					m_Designation.get(spDesignation.getSelectedItemPosition()).getDesignation_name());

			String str_app_ApplicantType = ch_app_ApplicantType.isChecked() ? getResources().getString(R.string.app_Fresher): getResources().getString(R.string.app_ITI_Pass);
			contentValues.put(DataBaseHelper.KEY_APP_TYPE, str_app_ApplicantType);

			contentValues.put(DataBaseHelper.KEY_SEAT_NO, 
					txtappSeatNumber.getText().toString());

			contentValues.put(DataBaseHelper.KEY_JOINING_DATE, 
					txtJoiningDate.getText().toString());

			contentValues.put(DataBaseHelper.KEY_COMPLETION_DATE, 
					txtCompletionDate.getText().toString());

			contentValues.put(DataBaseHelper.KEY_REG_NO, 
					txtRegistrationNumber.getText().toString());

			contentValues.put(DataBaseHelper.KEY_REG_DATE, 
					txtDateofRegistration.getText().toString());

			contentValues.put(DataBaseHelper.KEY_TRADE_ID_REG, 
								m_APDesignatedTrade.get(spAPDesignatedTrade.getSelectedItemPosition()).getTRADE_ID());
			contentValues.put(DataBaseHelper.KEY_TRADE_ID_DISPLAY, 
					m_APDesignatedTrade.get(spAPDesignatedTrade.getSelectedItemPosition()).getTRADE_NAME_E());
			
			

			contentValues.put(DataBaseHelper.KEY_ITI_ID, 
					m_APInstitute.get(spAPInstitute.getSelectedItemPosition()).getITI_ID());
			contentValues.put(DataBaseHelper.KEY_ITI_ID_DISPLAY, 
					m_APInstitute.get(spAPInstitute.getSelectedItemPosition()).getITI_NAME_E());

			db.update(DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS, contentValues,
					DataBaseHelper.KEY_APPLICANT_ID +" = '"+ _id +"'",
					null);
		}
	}

	/*
	 * call back to know that all spinner data is filled
	 * and can now set values of it.
	 * 
	 *  or else will get null pointer exception.
	 */
	private UpdateAsyncCallback updateAsyncCallback = new UpdateAsyncCallback() {
		/*
		 * For main deatails
		 */
		boolean isCandidateCategoryAsyncTaskLoaded = false;
		boolean isStateAsyncTaskLoaded = false;
		boolean isDistrictAsyncTaskLoaded = false;
		boolean isTalukaAsyncTaskLoaded = false;
		boolean isGenderAsyncTaskLoaded = false;
		boolean isCasteAsyncTaskLoaded= false;
		boolean isDesignationAsyncTaskLoaded = false;

		/*
		 * For Ikvk
		 */
		boolean isIKVKCourseAsyncTaskLoaded = false;
		boolean isIKVKCentreAsyncTaskLoaded = false;
		boolean isIKVKShiftAsyncTaskLoaded = false;

		/*
		 * For Skill Certification
		 */
		boolean isSCRegionAsyncTaskLoaded = false;
		boolean isSCDistrictAsyncTaskLoaded = false;
		boolean isSCTalukaAsyncTaskLoaded = false;
		boolean isSCRelevantSectorAsyncTaskLoaded = false;
		boolean isSCModuleSkillAsyncTaskLoaded = false;

		/*
		 * For apprentice
		 */
		boolean isAPDesignatedAsyncTaskLoaded = false;
		boolean isAPInstituteAsyncTaskLoaded = false;

		/*
		 * main check of loading data
		 * 
		 * so that can load only one time even after this method calls 
		 */
		boolean isLoadedOnce = false;



		@Override
		public void onTaskDone(String asynClassName) {
			// TODO Auto-generated method stub

			if(asynClassName.equalsIgnoreCase("CandidateCategoryAsyncTask")) {
				isCandidateCategoryAsyncTaskLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("StateAsyncTask")) {
				isStateAsyncTaskLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("DistrictAsyncTask")) {
				isDistrictAsyncTaskLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("TalukaAsyncTask")) {
				isTalukaAsyncTaskLoaded = true;
			} else if(asynClassName.equalsIgnoreCase("GenderAsyncTask")) {
				isGenderAsyncTaskLoaded = true;
			}  else if(asynClassName.equalsIgnoreCase("CasteAsyncTask")) {
				isCasteAsyncTaskLoaded = true;
			}  else if(asynClassName.equalsIgnoreCase("DesignationAsyncTask")) {
				isDesignationAsyncTaskLoaded = true;
			};

			if(cateogry_id == 49) {
				if(asynClassName.equalsIgnoreCase("IKVKCourseAsyncTask")) {
					isIKVKCourseAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("IKVKCentreAsyncTask")) {
					isIKVKCentreAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("IKVKShiftAsyncTask")) {
					isIKVKShiftAsyncTaskLoaded = true;
				}; 
			} else if(cateogry_id == 50) {
				if(asynClassName.equalsIgnoreCase("SCRegionAsyncTask")) {
					isSCRegionAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("SCDistrictAsyncTask")) {
					isSCDistrictAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("SCTalukaAsyncTask")) {
					isSCTalukaAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("SCRelevantSectorAsyncTask")) {
					isSCRelevantSectorAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("SCModuleSkillAsyncTask")) {
					isSCModuleSkillAsyncTaskLoaded = true;
				}; 
			} else if(cateogry_id == 51) {
				if(asynClassName.equalsIgnoreCase("APDesignatedAsyncTask")) {
					isAPDesignatedAsyncTaskLoaded = true;
				} else if(asynClassName.equalsIgnoreCase("APInstituteAsyncTask")) {
					isAPInstituteAsyncTaskLoaded = true;
				};
			}

			/*
			 * load data only once from database
			 */
			if(isLoadedOnce == false) {
				if(cateogry_id == 49) {
					Log.e(TAG, "For Ikvk");
					if(isCandidateCategoryAsyncTaskLoaded && isStateAsyncTaskLoaded && isDistrictAsyncTaskLoaded &&  isTalukaAsyncTaskLoaded && isGenderAsyncTaskLoaded && isCasteAsyncTaskLoaded && isDesignationAsyncTaskLoaded
							&& isIKVKCourseAsyncTaskLoaded && isIKVKCentreAsyncTaskLoaded && isIKVKShiftAsyncTaskLoaded) {
						Log.e(TAG, "eeeeeeeeeeeeeeeeeeeeeeeeeee Load data For Ikvk");
						new SetUserDetailAsyncTask().execute();
						isLoadedOnce = true;
					} 
				} else if(cateogry_id == 50) {
					Log.e(TAG, "For Skil Certification");
					if(isCandidateCategoryAsyncTaskLoaded && isStateAsyncTaskLoaded && isDistrictAsyncTaskLoaded &&  isTalukaAsyncTaskLoaded && isGenderAsyncTaskLoaded && isCasteAsyncTaskLoaded && isDesignationAsyncTaskLoaded
							&& isSCRegionAsyncTaskLoaded && isSCDistrictAsyncTaskLoaded && isSCTalukaAsyncTaskLoaded && isSCRelevantSectorAsyncTaskLoaded 
							&& isSCModuleSkillAsyncTaskLoaded) {
						Log.e(TAG, "eeeeeeeeeeeeeeeeeeeeeeeeeee Load data For Skil Certification");
						new SetUserDetailAsyncTask().execute();
						isLoadedOnce = true;
					}
				} else if(cateogry_id == 51) {
					Log.e(TAG, "For Apprentice");
					if(isCandidateCategoryAsyncTaskLoaded && isStateAsyncTaskLoaded && isDistrictAsyncTaskLoaded &&  isTalukaAsyncTaskLoaded && isGenderAsyncTaskLoaded && isCasteAsyncTaskLoaded && isDesignationAsyncTaskLoaded
							&& isAPDesignatedAsyncTaskLoaded && isAPInstituteAsyncTaskLoaded) {
						Log.e(TAG, "eeeeeeeeeeeeeeeeeeeeeeeeeee Load data For Apprentice");
						new SetUserDetailAsyncTask().execute();
						isLoadedOnce = true;
					}
				}  else {
					Log.e(TAG, "do not call set data");
				}
			}
		}
	};


	/*
	 * set user data from database
	 */

	public class SetUserDetailAsyncTask extends AsyncTask<Void, Void, Cursor> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Cursor doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			Cursor result = null;
			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_APPLICANT_MASTER);
			if (table_length > 0) {
				System.out
				.println("TESTDB: SetUserDetailAsyncTask if - read from table table_length = "
						+ table_length);
				//				result = db.rawQuery("select * from "
				//						+ DataBaseHelper.TABLE_APPLICANT_MASTER + " where " +DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID + " = "
				//						+ _id, null);

				final String query = "select * from "
						+ DataBaseHelper.TABLE_APPLICANT_MASTER + ", "
						+ DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS
						+ " where "
						+ DataBaseHelper.TABLE_APPLICANT_MASTER+"."+DataBaseHelper.KEY_APPLCANT_MASTER_REF_ID + " = "+ _id
						+ " AND "
						+ DataBaseHelper.TABLE_APPLICANT_REGS_OTHER_DETAILS+"."+DataBaseHelper.KEY_APPLICANT_ID + " = " + _id; 


				System.out.println("Query>>>>>>>>>"+query);
				result = db.rawQuery(query, null);

			}

			return result;
		}

		@Override
		protected void onPostExecute(Cursor result) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			setUserDetail(result);
		}
	}

	private void setUserDetail(Cursor result) {
		if (result != null) {
			result.moveToFirst();
			etxFirstName.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_APPLICANT_FNAME_E)));
			etxMiddleName.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_APPLICANT_MNAME_E)));
			etxLastName.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_APPLICANT_LNAME_E)));
			etxFmhName.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_APPLICANT_FATHER_NAME_E)));
			etxAddress.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_ADDRESS_E)));
			etxCity.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_CITY)));
			etxPincode.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_PINCODE)));
			etxMobile.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_MOBILE_NO)));
			etxLline.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_LANDLINE_NO)));
			etxPhysical.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_PH_VALUE)));
			etxEmail.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_EMAIL_ADDRESS)));
			etxBday.setText(result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_BIRTH_DATE)));

			if (result.getInt(result
					.getColumnIndex(DataBaseHelper.KEY_PHYSICAL_HANDICAP)) == 1) {
				chkPhysical.setChecked(true);
			}
			if (result.getInt(result
					.getColumnIndex(DataBaseHelper.KEY_EX_ARMY)) == 1) {
				chkExArmy.setChecked(true);
			}
			if (result.getInt(result
					.getColumnIndex(DataBaseHelper.KEY_WIDOW)) == 1) {
				chkWidow.setChecked(true);
			}
			if (result.getInt(result
					.getColumnIndex(DataBaseHelper.KEY_DIVORCEE)) == 1) {
				chkDivorcee.setChecked(true);
			}
			if (result.getInt(result
					.getColumnIndex(DataBaseHelper.KEY_MINORITY)) == 1) {
				chkMinority.setChecked(true);
			}
			if (result.getInt(result
					.getColumnIndex(DataBaseHelper.KEY_BPL)) == 1) {
				chkBpl.setChecked(true);
			}

			String tmpState = result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_STATE_ID_DISPLAY));
			spState.setSelection(m_StateDisplay.indexOf(tmpState));

			String tmpDistrictDisplay = result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_DISTRICT_ID_APPLCANT_MASTER_DISPLAY));
			spDistrict.setSelection(m_DistrictDisplay
					.indexOf(tmpDistrictDisplay));
			toSetDistrictDisplay = tmpDistrictDisplay;

			Log.e(TAG, "toSetDistrictDisplay= " + toSetDistrictDisplay);

			String tmpTalukaDisplay = result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_TALUKA_ID_APPLCANT_MASTER_DISPLAY));
			spTaluka.setSelection(m_TalukaDisplay 
					.indexOf(tmpTalukaDisplay));
			toSetTalukaDisplay = tmpTalukaDisplay;
			Log.e(TAG, "toSetTalukaDisplay= " + toSetTalukaDisplay);

			String tmpGender = result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_GENDER_DISPLAY));
			spGender.setSelection(m_GenderDisplay.indexOf(tmpGender));

			String tmpCaste = result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_CASTE_DISPLAY));
			spCaste.setSelection(m_CasteDisplay.indexOf(tmpCaste));

			String tmpImg = result.getString(result
					.getColumnIndex(DataBaseHelper.KEY_APPLICANT_PHOTO));
			if (tmpImg != null) {
				if (tmpImg.equalsIgnoreCase("")) {
				} else {
					File mFileTemp = new java.io.File(tmpImg)
					.getAbsoluteFile();
					Bitmap bitmap = BitmapFactory.decodeFile(mFileTemp
							.getPath());
					imgUserPic.setImageBitmap(bitmap);
				}
			}

			/*
			 * Set dynamic fields
			 */

			if(cateogry_id == 49) {

				String tmpDesignation = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_DESIGNATION));
				spDesignation.setSelection(m_DesignationDisplay.indexOf(tmpDesignation));

				String tmpAppType = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_APP_TYPE));
				if(tmpAppType.equalsIgnoreCase(getResources().getString(R.string.ikvk_fresher))) {
					ch_ikvk_ApplicantType.setChecked(true);
				} else {
					ch_ikvk_ApplicantType.setChecked(false);
				}

				txtTraining_StartDate.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_JOINING_DATE)));

				txtTraining_EndDate.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_COMPLETION_DATE)));

				String tmpKEY_COURSE_ID_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_COURSE_ID_DISPLAY));
				spikvk_Course.setSelection(m_IkvkCourseDisplay.indexOf(tmpKEY_COURSE_ID_DISPLAY));

				String tmpKEY_IKVK_CENTER_ID_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_IKVK_CENTER_ID_DISPLAY));
				spiKVKCenter.setSelection(m_IkvkCentreDisplay.indexOf(tmpKEY_IKVK_CENTER_ID_DISPLAY));

				String tmpKEY_SHIFT_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_SHIFT_DISPLAY));
				spPreferredShift.setSelection(m_IkvkShiftDisplay.indexOf(tmpKEY_SHIFT_DISPLAY));


				String tmpKEY_BATCH_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_BATCH_ID_DISPLAY));
				spBatch.setSelection(m_BatchesDisplay.indexOf(tmpKEY_BATCH_DISPLAY));


				


			} else if(cateogry_id == 50) {

				try
				{
				String tmpDesignation = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_DESIGNATION));
				spDesignation.setSelection(m_DesignationDisplay.indexOf(tmpDesignation));

			/*	txtind_Name.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_EST_NAME)));
*/
				txtadname.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ADDRESS)));

				txtind_Name.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_EST_NAME)));

				txtcontact.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_CONTACT_PERSON)));

				txtSCEmail.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_EMAIL_ID)));

				txtPhone.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_PHONE_NO)));

				String tmpKEY_REGION_ID_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_REGION_ID_DISPLAY));
				spSCRegion.setSelection(m_SCRegionDisplay.indexOf(tmpKEY_REGION_ID_DISPLAY));

				String tmpKEY_DISTRICT_ID_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_DISTRICT_ID_DISPLAY));
				spSCDistrict.setSelection(m_SCDistrictDisplay.indexOf(tmpKEY_DISTRICT_ID_DISPLAY));

				toSetDistrictDisplay_other = tmpKEY_DISTRICT_ID_DISPLAY;

				Log.e(TAG, "toSetDistrictDisplay_other= " + toSetDistrictDisplay_other);

				String tmpKEY_TALUKA_ID_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_TALUKA_ID_DISPLAY));
				spSCTaluka.setSelection(m_SCTalukaDisplay.indexOf(tmpKEY_TALUKA_ID_DISPLAY));

				toSetTalukaDisplay_other = tmpKEY_TALUKA_ID_DISPLAY;
				Log.e(TAG, "toSetTalukaDisplay_other= " + toSetTalukaDisplay_other);

				String tmpKEY_RELEVANT_SECTOR_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_RELEVANT_SECTOR_DISPLAY));
				spSCRelevantSector.setSelection(m_SCRelevantSectorDisplay.indexOf(tmpKEY_RELEVANT_SECTOR_DISPLAY));

				String tmpKEY_MODULE_SKILL_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_MODULE_SKILL_DISPLAY));
				spSCModuleSkill.setSelection(m_SCModuleSkillDisplay.indexOf(tmpKEY_MODULE_SKILL_DISPLAY));


				toSetSectorDisplay_other = tmpKEY_MODULE_SKILL_DISPLAY;

				Log.e(TAG, "toSetSectorDisplay_other= " + toSetSectorDisplay_other);
				}
				catch(Exception e)
				{
					
				}
				
			} else if(cateogry_id == 51) {

				String tmpDesignation = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_DESIGNATION));
				spDesignation.setSelection(m_DesignationDisplay.indexOf(tmpDesignation));




				String tmpAppType = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_APP_TYPE));
				if(tmpAppType.equalsIgnoreCase(getResources().getString(R.string.app_Fresher))) {
					ch_app_ApplicantType.setChecked(true);
				} else {
					ch_app_ApplicantType.setChecked(false);
				}

				txtappSeatNumber.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_SEAT_NO)));

				txtJoiningDate.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_JOINING_DATE)));

				txtCompletionDate.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_COMPLETION_DATE)));

				txtRegistrationNumber.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_REG_NO)));

				txtDateofRegistration.setText(result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_REG_DATE)));

				String tmpKEY_ITI_ID_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_ITI_ID_DISPLAY));
				Log.i("tag", "tmpKEY_ITI_ID_DISPLAY = "+ tmpKEY_ITI_ID_DISPLAY);
				spAPInstitute.setSelection(m_APInstituteDisplay.indexOf(tmpKEY_ITI_ID_DISPLAY));
				
				String tmpKEY_DESIGNATED_DISPLAY = result.getString(result
						.getColumnIndex(DataBaseHelper.KEY_TRADE_ID_DISPLAY));
				spAPDesignatedTrade.setSelection(m_APDesignatedTradeDisplay.indexOf(tmpKEY_DESIGNATED_DISPLAY));
			}  else {
				Log.e(TAG, "do not set data");
			}


			if (!result.isClosed()) {
				result.close();
			}

		}
	}


}