package com.registrationmanagementsystem;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.view.MenuItem;
import android.widget.ListView;

import com.registrationmanagementsystem.adapter.UserAdapter;
import com.registrationmanagementsystem.common.Global;
import com.registrationmanagementsystem.database.DataBaseHelper;
import com.registrationmanagementsystem.model.UserDetails;

public class UserListing extends ActionBarActivity {

	ListView mUserListView;
	UserAdapter mUserAdapter;
	public ArrayList<UserDetails> mUserList = new ArrayList<UserDetails>();
	DataBaseHelper mDbHelper;
	Context context;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.user_listing);

		context = this;

		mDbHelper = DataBaseHelper.getInstance(getApplicationContext());
		
		// get action bar
		ActionBar actionBar = getSupportActionBar();

		// Enabling Up / Back navigation
		actionBar.setDisplayHomeAsUpEnabled(true);
		
		mUserListView = (ListView) findViewById(R.id.userslist);
		
		
		/**
		 * Commented for list click
		 */
/*
		mUserListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				System.out.println("test = " + mUserList.get(position).getId());
				Intent intent = new Intent(UserListing.this,
						UpdateDetailActivity.class);
				intent.putExtra("id", mUserList.get(position).getId()
						.toString());
				startActivity(intent);
			}

		});*/

		new UserListingAsyncTask().execute();

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// app icon in action bar clicked; go home
			finish();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	public class UserListingAsyncTask extends AsyncTask<Void, Void, Void> {
		/*
		 * private final ProgressDialog dialog = new
		 * ProgressDialog(AdvanceSearchActivity.this);
		 */

		protected void onPreExecute() {
			/*
			 * this.dialog.setMessage("Loading........."); this.dialog.show();
			 */
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			SQLiteDatabase db = mDbHelper.getReadableDatabase();
			// db.beginTransaction();

			long table_length = DatabaseUtils.queryNumEntries(db,
					DataBaseHelper.TABLE_register_candidate);
			if (table_length > 0) {
				System.out
						.println("TESTDB: UserListingAsyncTask if - read from table table_length = "
								+ table_length);
				// Cursor result = db.rawQuery("select * from "
				// +DataBaseHelper.TABLE_class_descr + " LIMIT 15", null);
				Cursor result = db.rawQuery("select * from "
						+ DataBaseHelper.TABLE_register_candidate + " where " +  DataBaseHelper.KEY_rca_user_email+" = '" + Global.USER_EMAIL +"'", null);
				result.moveToFirst();
				while (result.isAfterLast() == false) {
					UserDetails userDetails = new UserDetails();

					/*
					 * String candidate_category; String first_name; String
					 * middle_name; String last_name; String fmh_name; String
					 * address; String district; String state; String city;
					 * String taluka; String pincode; String mobileno; String
					 * lline; String gender; String caste; String chk_ph; String
					 * percentage_ph; String chk_exarmy; String chk_widow;
					 * String chk_divorcee; String chk_minority; String chk_bpl;
					 * String email; String birthday; String image_path;
					 */
					userDetails
							.setCandidate_category(result.getInt(result
									.getColumnIndex(DataBaseHelper.KEY_rca_candidate_category)));
					userDetails.setFirst_name(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_rca_first_name)));
					userDetails.setMiddle_name(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_rca_middle_name)));
					userDetails.setLast_name(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_rca_last_name)));
					userDetails.setImage_path(result.getString(result
							.getColumnIndex(DataBaseHelper.KEY_rca_image_path)));
					userDetails
							.setId(result.getString(result
									.getColumnIndex(DataBaseHelper.KEY_rca_register_user_id)));
					System.out
							.println("result.getString(result.getColumnIndex(DataBaseHelper.KEY_register_user_id)) = "
									+ result.getString(result
											.getColumnIndex(DataBaseHelper.KEY_rca_register_user_id)));
/*					for(int i=0; i<=100; i++) {
						mUserList.add(userDetails);						
					}*/
					mUserList.add(userDetails);
					result.moveToNext();
				}
				if (!result.isClosed()) {
					result.close();
				}
			}

			// db.setTransactionSuccessful();
			// db.endTransaction();
			return null;
		}

		@Override
		protected void onPostExecute(Void v) {
			/*
			 * if (this.dialog.isShowing()) { this.dialog.dismiss(); }
			 */
			mUserAdapter = new UserAdapter(context, mUserList);
			mUserListView.setAdapter(mUserAdapter);
		}
	}

}
