package com.registrationmanagementsystem.model;

public class APInstitute {

	String ITI_ID;
	String ITI_CODE;
	String ITI_NAME_E;
	
	public String getITI_ID() {
		return ITI_ID;
	}
	public void setITI_ID(String iTI_ID) {
		ITI_ID = iTI_ID;
	}
	public String getITI_CODE() {
		return ITI_CODE;
	}
	public void setITI_CODE(String iTI_CODE) {
		ITI_CODE = iTI_CODE;
	}
	public String getITI_NAME_E() {
		return ITI_NAME_E;
	}
	public void setITI_NAME_E(String iTI_NAME_E) {
		ITI_NAME_E = iTI_NAME_E;
	}
}
